"""Additional independent verification of the 702-law affine-in-y classification.

Tests specified action words using an independent direct, invertible step
implementation and checks rooted and unrooted class sizes exhaustively.
"""
from itertools import product
from collections import Counter
from cyclic_action_simultaneous_conjugacy import System,STATES,find_conjugacy,word_fixed
from cyclic_action_linear_y_classification import params,table,transform,classify
F3=range(3)
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(F3,repeat=2))

def direct_step(s,letter,q):
 u,v,z,y,t=s
 if letter=='A':return ((u+1)%3,v,z,y,t)
 if letter=='a':return ((u-1)%3,v,z,y,t)
 if letter=='B':return (u,(v+u+1)%3,(z+Q0[3*u+v])%3,(y+Q1[3*v+z])%3,(t+q[3*z+y])%3)
 if letter=='b':
  vv=(v-u-1)%3
  zz=(z-Q0[3*u+vv])%3
  yy=(y-Q1[3*vv+zz])%3
  tt=(t-q[3*zz+yy])%3
  return (u,vv,zz,yy,tt)
 raise ValueError('unknown action')

def word_count(q,word):
 count=0
 for state in STATES:
  x=state
  for w in word:x=direct_step(x,w,q)
  count+=(state==x)
 return count

def verify():
 out=classify()
 assert out['unrooted_classes']==39
 assert out['unrooted_class_size_distribution']=={18:39}
 assert out['ordered_positive']==12636
 assert out['ordered_negative']==480168
 ws={p:System.construct(table(p)) for p in params}
 print('ROOTED_EXHAUSTIVE_START')
 positive=0
 classes=[]
 reps=out['class_representatives']
 for r in reps:
  p=(tuple(r['a']),tuple(r['b']))
  targets=[]
  for q in params:
   # Valid necessary invariants:
   if word_fixed(ws[p],'B')!=word_fixed(ws[q],'B') or word_fixed(ws[p],'ABBBabbb')!=word_fixed(ws[q],'ABBBabbb'):
    continue
   m,_=find_conjugacy(ws[p],ws[q])
   if m is not None:targets.append(q)
  assert len(targets)==18
  classes.append(targets)
  for q in targets:
   for src in targets:
    m,_=find_conjugacy(ws[src],ws[q],rooted=True)
    positive+=(m is not None)
 print('ROOTED_EXHAUSTIVE',positive)
 assert positive==1404
 assert len(classes)==39 and len(set(sum(classes,[])))==702
 print('ROOTED_CLASS_UNIQUE_MAPS',702,'individual roots within class',2)
 p=((0,0,0),(1,2,1));q=((0,0,1),(1,2,2))
 print('WORD_ORIGINAL','ABBBabbb',word_count(table(p),'ABBBabbb'),word_count(table(q),'ABBBabbb'))
 print('WORD_NEW','ABBabbbb',word_count(table(p),'ABBabbbb'),word_count(table(q),'ABBabbbb'))
 assert (word_count(table(p),'ABBBabbb'),word_count(table(q),'ABBBabbb'))==(39,39)
 assert (word_count(table(p),'ABBabbbb'),word_count(table(q),'ABBabbbb'))==(21,12)
 print('INDEPENDENT_DIRECT_STEP_AND_ROOTED_PROOFS_PASS')
if __name__=='__main__':verify()
