"""Breadth-first fixed-point distinguishing word search beyond depth nine."""
import numpy as np
from cyclic_action_y_same_short_words import LEFT,RIGHT,w1,w2,identity,D1,D2,inv
from time import perf_counter
visits=0
class Found(Exception):pass

def dfs(depth,word,last,li,ri):
 global visits
 visits+=1
 c1=np.count_nonzero(li==identity); c2=np.count_nonzero(ri==identity)
 if c1!=c2:
  print('FOUND',word,'DEPTH',len(word),'COUNTS',c1,c2,'VISITS',visits)
  raise Found
 if len(word)==depth:return
 for c in 'AaBb':
  if last and inv[last]==c:continue
  dfs(depth,word+c,c,D1[c][li],D2[c][ri])
if __name__=='__main__':
 for maxdepth in (13,):
  t=perf_counter();visits=0
  try:
   dfs(maxdepth,'',None,identity,identity)
  except Found:break
  print('NO_DIFFERENCE_THROUGH',maxdepth,'VISITS',visits,'SECONDS',round(perf_counter()-t,2))
