"""Negative control: same fixed-state counts for every reduced action word <=9."""
from itertools import product
from collections import Counter
import numpy as np
from cyclic_action_simultaneous_conjugacy import System,STATES,find_conjugacy
from cyclic_action_linear_y_classification import table
LEFT=((0,0,0),(1,0,1))
RIGHT=((0,0,1),(0,2,2))
w1=System.construct(table(LEFT));w2=System.construct(table(RIGHT))
identity=np.arange(243,dtype=np.int16)
inv={'A':'a','a':'A','B':'b','b':'B'}
def get_actions(w):
 a=np.asarray(w.A,dtype=np.int16);b=np.asarray(w.B,dtype=np.int16)
 aa=np.empty_like(a);aa[a]=identity
 bb=np.empty_like(b);bb[b]=identity
 return {'A':a,'B':b,'a':aa,'b':bb}
D1,D2=get_actions(w1),get_actions(w2)
counts=Counter();n=0

def traverse(prefix,last,left,right,depth):
 global n
 if depth:
  n+=1;counts[depth]+=1
  c1=np.count_nonzero(left==identity)
  c2=np.count_nonzero(right==identity)
  if c1!=c2:raise AssertionError(('DIFFERING_WORD',prefix,c1,c2))
 if depth==9:return
 for k in 'AaBb':
  if last and inv[last]==k:continue
  traverse(prefix+k,k,D1[k][left],D2[k][right],depth+1)

if __name__=='__main__':
 m,ntrials=find_conjugacy(w1,w2)
 assert m is None and ntrials==243
 n=0;traverse('',None,identity,identity,0)
 assert n==39364
 print('ALL_REDUCED_WORDS_LENGTH_1_TO_9',n,'MATCHED')
 print('DEPTH_COUNTS',dict(counts))
 print('FULL_ACTION_UNROOTED_CONJUGACY', 'NO', 'ORIGIN_IMAGES_EXHAUSTED',ntrials)
