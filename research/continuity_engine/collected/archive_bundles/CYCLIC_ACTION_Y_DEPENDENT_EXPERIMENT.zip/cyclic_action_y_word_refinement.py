"""Find a native finite action-word witness basis for the 39 y-linear classes.
Breadth first over freely reduced words, no change to the mathematical action.
"""
from itertools import product
from collections import Counter
import json
import numpy as np
from cyclic_action_simultaneous_conjugacy import System,word_fixed
from cyclic_action_linear_y_classification import table
R=json.load(open('/mnt/data/CYCLIC_ACTION_LINEAR_Y_RESULTS.json'))
reps=[(tuple(c['a']),tuple(c['b'])) for c in R['class_representatives']]
systems=[System.construct(table(r)) for r in reps]
N=len(reps);I=np.arange(243,dtype=np.uint16)
act={}
for c in 'AB':
 arr=np.stack([np.asarray(getattr(w,c),dtype=np.uint16) for w in systems])
 act[c]=arr
 inv=np.empty_like(arr)
 np.put_along_axis(inv,arr,np.tile(I,(N,1)),axis=1)
 act[c.lower()]=inv
indices=np.arange(N)[:,None]
invletter={'A':'a','a':'A','B':'b','b':'B'}
# Initial observed B and old W8
initial=['B','BBB','BBBBBBBBB','ABBBabbb']
selected=list(initial)
fingerprints=[tuple(word_fixed(w,s) for s in selected) for w in systems]
print('INITIAL_REMAINING',len(set(fingerprints)),'OF',N)
bydepth=Counter();used=[]

def maybe_advance(word,perm):
 global fingerprints
 values=np.count_nonzero(perm==I[None,:],axis=1)
 new=[(*f,int(v)) for f,v in zip(fingerprints,values)]
 if len(set(new))>len(set(fingerprints)):
  old=len(set(fingerprints))
  fingerprints=new;selected.append(word);used.append((word,old,len(set(new))))
  print('REFINEMENT',word,'DEPTH',len(word),'PARTITION',old,'->',len(set(new)))
 return len(set(fingerprints))==N

visits=0

def dfs(word,last,perm,depth,maxdepth):
 global visits
 if word:
  visits+=1
  if maybe_advance(word,perm):return True
 if depth==maxdepth:return False
 for ch in 'AaBb':
  if last and invletter[last]==ch:continue
  nperm=np.take_along_axis(act[ch],perm,axis=1)
  if dfs(word+ch,ch,nperm,depth+1,maxdepth):return True
 return False

for depth in range(1,10):
 print('SCAN_MAX_DEPTH',depth)
 stop=dfs('',None,np.tile(I,(N,1)),0,depth)
 print('DEPTH_REMAINING',depth,'DISTINCT',len(set(fingerprints)),'VISITS',visits)
 if stop:break
print('RESULT',len(set(fingerprints)),'OF',N,'WORDS',selected)
print('SELECTED_NEW',used)
with open('/mnt/data/CYCLIC_ACTION_Y_WORD_REFINEMENT.json','w') as f:json.dump({'classes':N,'separated':len(set(fingerprints)),'max_depth':depth,'words_scanned':visits,'selected_words':selected,'new_split_witnesses':[{'word':w,'before':b,'after':a} for w,b,a in used]},f,indent=2)
