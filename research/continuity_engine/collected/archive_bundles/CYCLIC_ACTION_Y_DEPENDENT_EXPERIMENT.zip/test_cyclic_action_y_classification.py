"""Focused regression tests for the cyclic action q(z,y)=a_z+b_z*y research family."""
import unittest
from itertools import product
from cyclic_action_simultaneous_conjugacy import System,STATES,find_conjugacy,word_fixed,reach_count
from cyclic_action_linear_y_classification import params,table,transform
from cyclic_action_y_rotation_theorem import R,S,law_R,law_S,apply_R,apply_R_law,law_group_orbit
F3=range(3)

class CyclicActionYClassificationTests(unittest.TestCase):
    def test_family_exactly_702(self):
        self.assertEqual(len(params),702)
        self.assertEqual(len({table(p) for p in params}),702)

    def test_all_702_actions_are_transitive(self):
        self.assertEqual({reach_count(System.construct(table(p))) for p in params},{243})

    def test_R_order9_and_S_order2_commute(self):
        for x in STATES:
            self.assertEqual(apply_R(x,9),x)
            self.assertEqual(S(S(x)),x)
            self.assertEqual(R(S(x)),S(R(x)))
        self.assertNotEqual(apply_R(STATES[0],3),STATES[0])

    def test_R_and_S_transport_full_A_and_B(self):
        p=((0,0,0),(0,0,1))
        w=System.construct(table(p))
        for newlaw,F in [(law_R(table(p)),R),(law_S(table(p)),S)]:
            t=System.construct(newlaw)
            from cyclic_action_simultaneous_conjugacy import INDEX
            for i,x in enumerate(STATES):
                j=INDEX[F(x)]
                self.assertEqual(F(STATES[w.A[i]]),STATES[t.A[j]])
                self.assertEqual(F(STATES[w.B[i]]),STATES[t.B[j]])

    def test_complete_39_orbit_census(self):
        alltables={table(p) for p in params};left=set(alltables);count=0
        while left:
            q=min(left); orbit=law_group_orbit(q)
            self.assertEqual(len(orbit),18)
            self.assertTrue(orbit<=left)
            left-=orbit;count+=1
        self.assertEqual(count,39)

    def test_5th_scaling_is_root_preserving_and_cyclic_rotation_is_not(self):
        p=((0,0,0),(0,0,1))
        q=table(p)
        self.assertEqual(S(STATES[0]),STATES[0])
        self.assertNotEqual(R(STATES[0]),STATES[0])
        self.assertEqual(len({law_S(q),q}),2)

    def test_cross_simple_6_law_orbits_positive_unrooted(self):
        p=table(((0,0,0),(0,0,1)))
        r=table(((0,0,0),(0,1,0)))
        self.assertEqual(apply_R_law(p,8),r)
        m,_=find_conjugacy(System.construct(p),System.construct(r))
        self.assertIsNotNone(m)
        self.assertIsNone(find_conjugacy(System.construct(p),System.construct(r),rooted=True)[0])

    def test_short_word_agreement_and_new_obstruction(self):
        p=System.construct(table(((0,0,0),(1,2,1))))
        q=System.construct(table(((0,0,1),(1,2,2))))
        self.assertEqual(tuple(word_fixed(p,w) for w in ['B','BBB','BBBBBBBBB','ABBBabbb']),
                         tuple(word_fixed(q,w) for w in ['B','BBB','BBBBBBBBB','ABBBabbb']))
        self.assertEqual((word_fixed(p,'ABBabbbb'),word_fixed(q,'ABBabbbb')),(21,12))
        m,n=find_conjugacy(p,q)
        self.assertIsNone(m)
        self.assertEqual(n,243)

    def test_positive_rooted_18_member_class_has_two_targets(self):
        p=((0,0,0),(0,0,1));q=table(p)
        ws=System.construct(q)
        count=0
        for r in law_group_orbit(q):
            m,_=find_conjugacy(ws,System.construct(r),rooted=True)
            count+=(m is not None)
        self.assertEqual(count,2)

if __name__=='__main__':unittest.main(verbosity=2)
