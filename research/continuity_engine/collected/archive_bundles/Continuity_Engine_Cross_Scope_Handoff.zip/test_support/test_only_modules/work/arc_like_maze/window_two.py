"""Test-only extraction of WindowProcess triangular generator arithmetic."""
from dataclasses import dataclass
@dataclass(frozen=True)
class WindowProcess:
    gain:int
    stem:tuple
    period:tuple
    def __post_init__(self):
        if type(self.gain) is not int or self.gain not in (1,2) or not self.period:
            raise ValueError('bad law')
        for q in self.stem+self.period:
            if len(q)!=9 or any(type(v)!=int or v not in (0,1,2) for v in q):
                raise ValueError('bad window')
    def rule(self,index):
        return self.stem[index] if index<len(self.stem) else self.period[(index-len(self.stem))%len(self.period)]
    def step(self,s,g):
        a=list(s)
        if g=='A': a[0]=(s[0]+1)%3
        elif g=='B':
            a[1]=(s[1]+self.gain*(s[0]+1))%3
            for i in range(2,len(s)):
                a[i]=(s[i]+self.rule(i-2)[3*s[i-2]+s[i-1]])%3
        else:raise ValueError(g)
        return tuple(a)
    def inverse(self,s,g):
        a=list(s)
        if g=='A':a[0]=(s[0]-1)%3
        elif g=='B':
            a[1]=(s[1]-self.gain*(s[0]+1))%3
            for i in range(2,len(s)):
                a[i]=(s[i]-self.rule(i-2)[3*a[i-2]+a[i-1]])%3
        else:raise ValueError(g)
        return tuple(a)
