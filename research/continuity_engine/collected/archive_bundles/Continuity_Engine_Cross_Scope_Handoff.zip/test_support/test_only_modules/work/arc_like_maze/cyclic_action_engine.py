"""LOCAL TEST DOUBLE for existing CyclicActionEngine.

This is not repository source. Used only where exact real repo imports are
unavailable; finite field arithmetic is reproduced by WindowProcess stub.
It supplies a cryptographically bound, replayable fixture with the same public
contract for tests of the NEW cross-scope relationship.
"""
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from .window_two import WindowProcess


def _wire(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def _data(w):return {'gain':w.gain,'stem':[list(r) for r in w.stem],'period':[list(r) for r in w.period]}
def _restore(x):return WindowProcess(x['gain'],tuple(tuple(r) for r in x['stem']),tuple(tuple(r) for r in x['period']))
def _cycles(w,carrier):
    remain=set(carrier);result=[]
    while remain:
        x=min(remain); cyc=[]
        while x in remain:
            remain.remove(x);cyc.append(x);x=w.step(x,'B')
        if x!=cyc[0]:raise ValueError('permutation carrier failure')
        result.append(tuple(cyc))
    return sorted(result,key=lambda c:(len(c),c[0]))
def _bijection(src,dst,carrier):
    a=_cycles(src,carrier);b=_cycles(dst,carrier)
    if [len(c) for c in a]!=[len(c) for c in b]:raise ValueError('different cycle partition')
    mapping={x:y for cx,cy in zip(a,b) for x,y in zip(cx,cy)}
    if len(mapping)!=len(carrier) or len(set(mapping.values()))!=len(carrier):raise ValueError('invalid permutation')
    if any(mapping[src.step(x,'B')]!=dst.step(mapping[x],'B') for x in carrier):raise ValueError('not intertwined')
    idx={x:i for i,x in enumerate(carrier)}
    return [[idx[x],idx[mapping[x]]] for x in carrier]

@dataclass(frozen=True)
class Result:
    record:dict
    @property
    def status(self):return self.record['status']
    def serialize(self):return _wire(self.record)

class CyclicActionEngine:
    @staticmethod
    def fiber(depth,*,first=0):
        if type(depth)!=int or not 3<=depth<=8:raise ValueError('depth')
        return tuple((first,*t) for t in product(range(3),repeat=depth-1))
    def start(self,source,target,carrier,max_power):
        carrier=tuple(tuple(s) for s in carrier)
        if not carrier or tuple(sorted(set(carrier)))!=carrier:raise ValueError('noncanonical carrier')
        if type(max_power)!=int or max_power<1:raise ValueError('budget')
        cset=set(carrier)
        if any(w.step(s,'B') not in cset for w in (source,target) for s in carrier):raise ValueError('not invariant')
        q={'operation':'B_SUCCESSIVE_COMPOSITION','source':_data(source),'target':_data(target),
           'carrier':[list(s) for s in carrier],'relation':'B_ONLY_ON_DECLARED_INVARIANT_CARRIER'}
        obs=[]; status='UNKNOWN_BUDGET'; witness=[]
        sa=list(carrier);ta=list(carrier)
        for power in range(1,max_power+1):
            sa=[source.step(s,'B') for s in sa];ta=[target.step(s,'B') for s in ta]
            fixed1=[i for i,x in enumerate(sa) if x==carrier[i]]
            fixed2=[i for i,x in enumerate(ta) if x==carrier[i]]
            obs.append({'power':power,'source_fixed':fixed1,'target_fixed':fixed2,'source_anchor_image':list(sa[0]),'target_anchor_image':list(ta[0])})
            if len(fixed1)!=len(fixed2):status='DISTINGUISHED_B_ACTIONS';break
            if len(fixed1)==len(carrier):
                status='B_ONLY_CONJUGACY_WITNESSED'
                witness=_bijection(source,target,carrier);break
        return Result({'schema':1,'question':q,'question_id':sha256(_wire(q).encode()).hexdigest(),
            'status':status,'max_power':max_power,'observations':obs,'B_bijection':witness,
            'simultaneous_A_B':'UNKNOWN_NOT_WATCHED'})
    def resume(self,serialized,max_power,*,expected_question_id=None):
        rec=json.loads(serialized);q=rec['question'];qid=sha256(_wire(q).encode()).hexdigest()
        if qid!=rec['question_id'] or (expected_question_id and expected_question_id!=qid):raise ValueError('changed question')
        if type(max_power)!=int or max_power<len(rec['observations']):raise ValueError('budget decrease')
        src=_restore(q['source']);dst=_restore(q['target']);car=tuple(tuple(s) for s in q['carrier'])
        verified=self.start(src,dst,car,rec['max_power'])
        if verified.serialize()!=serialized:raise ValueError('saved witness failed replay')
        if rec['status']!='UNKNOWN_BUDGET':return verified
        return self.start(src,dst,car,max_power)
