"""Test-only strict projection of source research board, not production."""
from pathlib import Path
import json

def load_research_board(*,checkpoint=None,root=None):
    r=Path(root);idx=json.loads((r/'index.json').read_text())
    assert idx['schema_version']==1
    selected=checkpoint or idx['current']
    assert selected in [x['id'] for x in idx['checkpoints']]
    ent=next(x for x in idx['checkpoints'] if x['id']==selected)
    assert Path(ent['file']).name==ent['file']
    snap=json.loads((r/ent['file']).read_text())
    assert snap['schema_version']==1 and snap['checkpoint_id']==selected
    questions=snap['questions']
    seen=set()
    counts={s:0 for s in ('REVIEW','ANSWERED','PARTIAL','UNKNOWN','OPEN')}
    for q in questions:
        assert q['id'] not in seen;seen.add(q['id'])
        counts[q['status']]+=1
        if q['status'] in ('ANSWERED','PARTIAL'):
            assert q.get('answer') and q.get('scope') and q.get('witnesses')
        if q['status'] in ('UNKNOWN','PARTIAL'):assert q.get('boundary')
    return {'available':True,'checkpoint':{'id':selected},'questions':questions,
            'checkpoints':[{'id':x['id'],'label':x.get('label',x['id'])} for x in idx['checkpoints']],
            'counts':counts}
