# Continuity Engine — question-board checkpoint bridge

**Current state:** tested integration package, not a repository commit. This adds a strict projection of replay-verified Cyclic Action results into **new candidate** question-board checkpoints. The existing question-board renderer and its frozen files are never modified.

## What the bridge admits

The outer `ContinuityEngine` admits both `cyclic_action/B` and separately scoped `finite_action/AB`. Checkpoint history must replay in the existing `WindowProcess` / `CyclicActionEngine` mathematical implementation. Each checkpoint binds an original mathematical question identifier, scope, ordered observation history, and terminal status. Its hashes support accidental-change detection, not external authentication.

`stage_checkpoint(handoff, *, question_id, question, source_board_root, candidate_directory, frozen_date, expected_question_id, witness_url=None, ...)`:

1. Replays every mathematical checkpoint; rejects changes in question, evidence or mathematical scope.
2. Loads the existing registered board checkpoint and validates all registered old freezes.
3. Creates a distinct new question ID with a dedicated evidence link and engine metadata.
4. Writes a **separate staged board directory** with the original immutable snapshots copied intact, plus exactly one new candidate checkpoint.
5. Confirms the staged checkpoint loads using the *actual* `runtime.research_board.load_research_board` module.

The stage function explicitly refuses to write inside the source board directory, overwrite its source, or silently update Q-001...Q-006.

## Status and publication semantics

| Mathematical record | No published witness URL | Published HTTPS witness URL supplied |
| --- | --- | --- |
| `UNKNOWN_BUDGET` | `UNKNOWN` | `UNKNOWN` |
| `DISTINGUISHED_B_ACTIONS` | `REVIEW` | `ANSWERED` for **restricted B only** |
| `B_ONLY_CONJUGACY_WITNESSED` | `REVIEW` | `ANSWERED` for **restricted B only** |
| `UNKNOWN_COLLISION_BUDGET` | `UNKNOWN` | `UNKNOWN` |
| `DISTINGUISHED_FULL_AB` | `REVIEW` | `ANSWERED` for **declared transitive full A/B** |
| `CONJUGATE_FULL_AB` | `REVIEW` | `ANSWERED` for **declared transitive full A/B** |

A provided URL is syntax-checked, **not independently fetched or content-verified**. The reviewer must ensure it points to the actual proof before publishing. `ANSWERED` in a staged, unpublished checkpoint is not an update to the live board.

## Example

```python
from pathlib import Path
from research.continuity_engine import ContinuityEngine
from research.continuity_board_bridge import stage_checkpoint

engine = ContinuityEngine()
# Assume source, target are actual WindowProcess laws, with a declared invariant carrier.
record = engine.start_cyclic(source, target, carrier, 8)
record = engine.resume(record.serialize(), 9, expected_question_id=record.question_id)
proposal = stage_checkpoint(
    record.serialize(),
    question_id="CE-001",
    question="Are the two declared restricted B-actions conjugate?",
    source_board_root=Path("research/questions"),
    candidate_directory=Path("/separate/review-area/board-candidate"),
    frozen_date="2026-10-09",
    expected_question_id=record.question_id,
)
assert proposal.mathematical_status == "DISTINGUISHED_B_ACTIONS"
assert proposal.board_status == "REVIEW"  # no published witness yet
```

The candidate directory is reviewable locally by passing it as `root=` to the existing read-only board loader. No browser/UI change is required to inspect its projection. Publication is a separate explicit action that copies the reviewed new snapshot and registry update into the repository.

## What is not swallowed yet

The mathematical techniques from GAP/ORB, GAP/Digraphs, nauty, SageMath, and formal verification systems remain independent references, not installed dependencies or implemented adapters. The current integration now additionally admits *finite transitive full A/B conjugacy* using a complete path-collision certificate. It still does **not** claim general nontransitive equivalence, unrestricted dimensions without resource budgets, live autonomous research, or native ARC evaluation.

## Reproduce

Place this package's files at their corresponding repository-relative paths, then run from the repository root:

```bash
python -m unittest network.tests.test_research_continuity_engine \
    network.tests.test_research_continuity_board_bridge \
    network.tests.test_research_question_board \
    network.tests.test_arc_like_cyclic_action_engine -v
```

The board bridge has been run in a temporary clean Git worktree of the actual repository `main` and passed alongside the source board and Cyclic Action regression tests. That did not modify the live checkout or merge a change.

## Cross-scope staging

`research.scope_board_bridge.stage_scope_handoff` verifies both mathematical
records, stages a **new** child AB question, and adds machine-readable
`scope_handoff` ancestry to the candidate question row. It cannot overwrite
or silently close the parent question. The browser's current card renderer
does not render the additional ancestry fields automatically; they remain
present in the JSON projection for a later separately reviewed UI change.
