"""Verified, non-promoting B-carrier -> full A/B investigation handoff.

The child is a distinct mathematical question.  Parent observations and scope
are carried exactly, not interpreted as proofs for the larger space.  Only
pointwise B restriction is established between the two distinct domains.

This is a local research integration candidate, not a cross-domain generalizer.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json

from research.continuity_engine import (ContinuityEngine, CYCLIC, FULL_AB,
                                       SCOPE, FULL_AB_SCOPE, _hash, _wire)
from research.simultaneous_action_correspondence import _restore_law

SCHEMA = "continuity_scope_handoff.v1"
RELATION = "RESTRICTION_OF_FULL_AB_B_TO_DECLARED_INVARIANT_CARRIER"


def _link_proof(parent, child):
    """Reconstruct finite domain inclusion and all B-transition restrictions."""
    if parent.area != CYCLIC or parent.scope != SCOPE:
        raise ValueError("parent must be a verified restricted B-action record")
    if child.area != FULL_AB or child.scope != FULL_AB_SCOPE:
        raise ValueError("child must be a verified full A/B action record")
    left, right = parent.research_question, child.research_question
    if left["source"] != right["source"] or left["target"] != right["target"]:
        raise ValueError("full-action law pair differs from the B-only investigation")
    dimension = right["dimension"]
    if type(dimension) is not int or dimension < 3:
        raise ValueError("invalid child dimension")
    carrier = tuple(tuple(s) for s in left["carrier"])
    full = set(product((0, 1, 2), repeat=dimension))
    if not carrier or len(set(carrier)) != len(carrier) or any(s not in full for s in carrier):
        raise ValueError("B-only carrier does not embed into the full-action domain")
    for name in ("source", "target"):
        law = _restore_law(left[name]); broader = _restore_law(right[name])
        watched = set(carrier)
        for state in carrier:
            restricted_image = law.step(state, "B")
            if restricted_image not in watched:
                raise ValueError("B-only carrier is not invariant")
            if broader.step(state, "B") != restricted_image:
                raise ValueError("B restriction does not agree with full action")
    if parent.question_id == child.question_id:
        raise ValueError("the new question must retain a distinct mathematical identity")
    return {
        "relation": RELATION,
        "parent_area": CYCLIC,
        "child_area": FULL_AB,
        "parent_question_id": parent.question_id,
        "child_question_id": child.question_id,
        "parent_scope": SCOPE,
        "child_scope": FULL_AB_SCOPE,
        "carrier_size": len(carrier),
        "full_space_size": len(full),
        "dimension": dimension,
        "b_transition_checks": 2 * len(carrier),
        "carrier_sha256": sha256(_wire(left["carrier"]).encode("utf-8")).hexdigest(),
        "claim": "B restriction only; no conjugacy outcome is transported",
    }


def _lineage(child):
    """Derive exact nested child continuation ancestry, not a second claim."""
    entries = []
    prior = None
    for item in child.snapshots:
        reading = json.loads(item["payload"])
        entries.append({"snapshot_sha256": item["sha256"],
                        "previous_snapshot_sha256": prior,
                        "max_loops": reading["max_loops"],
                        "status": reading["status"]})
        prior = item["sha256"]
    return entries


@dataclass(frozen=True)
class ScopeHandoff:
    parent_serialized: str
    child_serialized: str
    proof: dict
    child_lineage: tuple[dict, ...]

    def serialize(self):
        return _wire({"schema": SCHEMA, "relation": RELATION,
                      "parent_serialized": self.parent_serialized,
                      "parent_sha256": _hash(self.parent_serialized),
                      "child_serialized": self.child_serialized,
                      "child_sha256": _hash(self.child_serialized),
                      "proof": self.proof,
                      "child_lineage": list(self.child_lineage)})

    @property
    def statuses(self):
        engine = ContinuityEngine()
        return (engine.verify(self.parent_serialized).status,
                engine.verify(self.child_serialized).status)


class ScopeHandoffEngine:
    def __init__(self):
        self._continuity = ContinuityEngine()

    def _assemble(self, parent_serialized, child_serialized):
        parent = self._continuity.verify(parent_serialized)
        child = self._continuity.verify(child_serialized)
        proof = _link_proof(parent, child)
        return ScopeHandoff(parent_serialized, child_serialized,
                            proof, tuple(_lineage(child)))

    def start(self, parent_serialized, max_loops, *, rooted=False, max_states=1000,
              expected_parent_question_id=None):
        parent = self._continuity.verify(
            parent_serialized, expected_question_id=expected_parent_question_id)
        if parent.area != CYCLIC:
            raise ValueError("a frozen B-only record is required for this handoff")
        q = parent.research_question
        carrier = tuple(tuple(s) for s in q["carrier"])
        if not carrier:
            raise ValueError("an explicit B-only carrier is required")
        dimension = len(carrier[0])
        for x in carrier:
            if len(x) != dimension or any(v not in (0, 1, 2) for v in x):
                raise ValueError("the B carrier has no compatible F3 full space")
        child = self._continuity.start_full_action(
            _restore_law(q["source"]), _restore_law(q["target"]),
            dimension, max_loops, rooted=rooted, max_states=max_states)
        return self._assemble(parent_serialized, child.serialize())

    def verify(self, serialized, *, expected_parent_question_id=None,
               expected_child_question_id=None):
        try:
            raw = json.loads(serialized)
        except (TypeError, json.JSONDecodeError) as exc:
            raise ValueError("invalid scope handoff envelope") from exc
        if (not isinstance(raw, dict) or
            set(raw) != {"schema", "relation", "parent_serialized", "parent_sha256",
                         "child_serialized", "child_sha256", "proof", "child_lineage"} or
            raw["schema"] != SCHEMA or raw["relation"] != RELATION or
            not isinstance(raw["parent_serialized"], str) or
            not isinstance(raw["child_serialized"], str) or
            raw["parent_sha256"] != _hash(raw["parent_serialized"]) or
            raw["child_sha256"] != _hash(raw["child_serialized"])):
            raise ValueError("invalid cross-scope lineage, identity, or evidence hashes")
        result = self._assemble(raw["parent_serialized"], raw["child_serialized"])
        if raw["proof"] != result.proof or raw["child_lineage"] != list(result.child_lineage):
            raise ValueError("cross-scope proof or child observation ancestry changed")
        if (expected_parent_question_id is not None and
            result.proof["parent_question_id"] != expected_parent_question_id):
            raise ValueError("expected parent question identity changed")
        if (expected_child_question_id is not None and
            result.proof["child_question_id"] != expected_child_question_id):
            raise ValueError("expected child question identity changed")
        return result

    def continue_child(self, serialized, max_loops, *,
                       expected_parent_question_id=None, expected_child_question_id=None):
        old = self.verify(serialized,
            expected_parent_question_id=expected_parent_question_id,
            expected_child_question_id=expected_child_question_id)
        child = self._continuity.resume(old.child_serialized, max_loops,
                                         expected_question_id=old.proof["child_question_id"])
        return self._assemble(old.parent_serialized, child.serialize())

    def verify_parent_unchanged(self, before, after):
        old = self.verify(before)
        new = self.verify(after)
        if old.parent_serialized != new.parent_serialized:
            raise ValueError("scope handoff altered its frozen parent record")
        if old.proof["child_question_id"] != new.proof["child_question_id"]:
            raise ValueError("scope handoff replaced the derived question")
        return True
