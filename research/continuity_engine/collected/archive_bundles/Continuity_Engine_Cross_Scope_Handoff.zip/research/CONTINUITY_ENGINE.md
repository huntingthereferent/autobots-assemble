# Continuity Engine — prototype research entry

**Identity:** Continuity Engine is the overarching research entry, not a synonym for Cyclic Action Engine or an automated research agent. Cyclic Action Engine remains an unchanged mathematical component.

**Admitted mathematical areas:** `cyclic_action/B` for native B-only continuation, and `finite_action/AB` for finite transitive labeled A/B correspondence. These are separate mathematical contracts. No result is silently promoted from restricted B to full A/B; full A/B correspondence must be constructed and independently replayed.

**Evidence contract:** The `continuity_engine.v1` handoff stores the original question identifier, exact relation scope, serialized mathematical witnesses and an ordered chain of checkpoints. Re-entry reconstructs original laws, replays every checkpoint, verifies observation ancestry, checks the question identifier, and preserves terminal obstructions. SHA-256 digests detect incidental tampering, **not** adversarial replacement of the whole chain; external callers should anchor `question_id` separately.

**No mathematical claims added:** Underlying Cyclic Action statuses remain `UNKNOWN_BUDGET`, `DISTINGUISHED_B_ACTIONS`, and `B_ONLY_CONJUGACY_WITNESSED`. These refer only to the selected `B` action; they never prove simultaneous `A/B` conjugacy. The 81-state and 243-state experimental spaces are not physical spacetime dimensionality. The outer engine does not impose a new dimensional ceiling; the currently admitted component has its own finite-field and budget constraints.

**Entry:**

```python
from research.continuity_engine import ContinuityEngine
from work.arc_like_maze.cyclic_action_engine import CyclicActionEngine

engine = ContinuityEngine()
# source and target must be actual WindowProcess laws
carrier = CyclicActionEngine.fiber(5)
first = engine.start_cyclic(source, target, carrier, 8)
saved = first.serialize()
continued = engine.resume(saved, 9, expected_question_id=first.question_id)
assert continued.question_id == first.question_id
```

**Integration boundary:** The committed repository already has `runtime/continuity_pool.py`, a research question board, inverse construction and existing mathematical engines. This prototype does not replace their persistence mechanisms or conflate their artifacts. It does not import GAP, nauty, SageMath or ORB, nor claim their capabilities. Those are candidates for separately witnessed future admissions, not hidden runtime dependencies.

**Run:** `python -m unittest network.tests.test_research_continuity_engine -v` from the repository root.

## Full labeled A/B correspondence

`ContinuityEngine.start_full_action(source, target, dimension=5, max_loops=0,
rooted=False, max_states=1000)` uses the actual `WindowProcess.step` and
`inverse` operations. Its declared carrier is the **entire** `F3^dimension`
Cartesian state set. It verifies transitivity of both actions and computes a
source BFS tree, then its Schreier path-collision basis of exactly `N+1`
non-tree loops for a transitive two-generator action on `N` states.

Each successive collision checks which proposed target images of the source
origin preserve a source-root relation. `UNKNOWN_COLLISION_BUDGET` means a
budget ended with eligible origins still present and no completed proof.
`DISTINGUISHED_FULL_AB` means no eligible origin remains, giving a decisive
finite obstruction, even if not all basis equations were needed.
`CONJUGATE_FULL_AB` requires checking the full basis, constructing a bijection,
and verifying **both generator equations on every full state**. Rooted
comparisons admit only an origin-to-origin map; unrooted comparisons examine
all candidate origin images. Nontransitive inputs are rejected, not
misclassified as nonconjugate. Each outcome replays from the frozen law.

Two existing Continuity areas therefore share an evidence envelope but **do not
share mathematical stopping conditions**. The `continuity_engine.v1` envelope
is retained for existing Cyclic Action records and now distinguishes the
full-action area by an explicit named scope. No new dimension count is inferred
about physical reality. `max_states` is an explicit per-investigation resource
budget, not a dimensional assertion.

The underlying full-action technique is the classical Schreier path-collision
criterion for transitive labeled permutation actions; it does not claim a
novel general algorithm or replace GAP/ORB or nauty. No external packages
were incorporated or copied.

## Cross-scope witness relation — B restriction into full A/B action

`research.cross_scope_handoff.ScopeHandoffEngine` adds an explicitly *new*
full A/B question from an existing verified restricted B record. Parent scope
and all snapshots remain frozen. It checks the same laws on the same carrier
under the full action's B generator; the **new child does not inherit any
conjugacy conclusion**. Each action scope retains its own question ID and
proof rules. Example with the hard 5D pair: restricted B conjugate on 81 points,
full AB nonconjugate on 243 points. See
`docs/CROSS_SCOPE_HANDOFF_REPORT.md` in the integration package.
