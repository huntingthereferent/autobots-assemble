"""Cross-scope handoff regression on real repo modules or test-only substitutes.

The parent and child questions MUST remain distinct.  A restricted B-only
conjugacy may coexist with full AB nonconjugacy for exactly the same laws.
"""
import json
import tempfile
import unittest
from itertools import product
from pathlib import Path

from research.continuity_engine import ContinuityEngine, _wire, _hash
from research.cross_scope_handoff import (ScopeHandoffEngine, RELATION,
                                          _link_proof)
from research.scope_board_bridge import stage_scope_handoff
from runtime.research_board import load_research_board
from work.arc_like_maze.cyclic_action_engine import CyclicActionEngine
from work.arc_like_maze.window_two import WindowProcess

F3=range(3)
Z=(0,)*9
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(F3,repeat=2))

def table(a,b):
    return tuple((a[z]+b[z]*y)%3 for z,y in product(F3,repeat=2))

def rotated(q):
    t=[0]*9
    for z,y in product(F3,repeat=2):
        t[3*((z+1)%3)+(y+int(z==2))%3]=q[3*z+y]
    return tuple(t)

def process(q):
    return WindowProcess(1,(Q0,Q1,q),(Z,))

SRC=process(table((0,0,0),(1,0,1)))
NEG=process(table((0,0,1),(0,2,2)))
POS=process(rotated(table((0,0,0),(1,0,1))))
FIBER=CyclicActionEngine.fiber(5)
ROOT=Path(__file__).resolve().parents[2]/"research"/"questions"

class CrossScopeHandoffTests(unittest.TestCase):
    def setUp(self):
        self.engine=ContinuityEngine()
        self.link=ScopeHandoffEngine()
        self.parent=self.engine.start_cyclic(SRC,NEG,FIBER,27)
        self.assertEqual(self.parent.status,"B_ONLY_CONJUGACY_WITNESSED")
        self.assertEqual(len(self.parent.witness),81)

    def test_positive_B_and_negative_AB_are_separate_results(self):
        h=self.link.start(self.parent.serialize(),244,max_states=243)
        self.assertEqual(h.statuses,("B_ONLY_CONJUGACY_WITNESSED","DISTINGUISHED_FULL_AB"))
        self.assertEqual(h.proof["relation"],RELATION)
        self.assertEqual((h.proof["carrier_size"],h.proof["full_space_size"],h.proof["b_transition_checks"]),(81,243,162))
        self.assertNotEqual(h.proof["parent_question_id"],h.proof["child_question_id"])
        self.assertEqual(self.link.verify(h.serialize()).serialize(),h.serialize())
        self.assertEqual(self.engine.verify(self.parent.serialize()).witness,self.parent.witness)

    def test_unknown_child_keeps_positive_parent(self):
        h=self.link.start(self.parent.serialize(),0,max_states=243)
        self.assertEqual(h.statuses,("B_ONLY_CONJUGACY_WITNESSED","UNKNOWN_COLLISION_BUDGET"))
        self.assertEqual(len(h.child_lineage),1)
        self.assertEqual(self.link.verify(h.serialize()).statuses,h.statuses)

    def test_resume_child_does_not_overwrite_parent(self):
        early=self.link.start(self.parent.serialize(),0,max_states=243)
        done=self.link.continue_child(early.serialize(),244,
                      expected_parent_question_id=self.parent.question_id,
                      expected_child_question_id=early.proof["child_question_id"])
        self.assertEqual(done.statuses,("B_ONLY_CONJUGACY_WITNESSED","DISTINGUISHED_FULL_AB"))
        self.assertEqual(early.parent_serialized,done.parent_serialized)
        self.assertEqual(len(done.child_lineage),2)
        self.assertEqual(done.child_lineage[1]["previous_snapshot_sha256"],done.child_lineage[0]["snapshot_sha256"])
        self.assertTrue(self.link.verify_parent_unchanged(early.serialize(),done.serialize()))

    def test_positive_AB_child_constructed_not_inherited(self):
        parent=self.engine.start_cyclic(SRC,POS,FIBER,27)
        self.assertEqual(parent.status,"B_ONLY_CONJUGACY_WITNESSED")
        h=self.link.start(parent.serialize(),244,max_states=243)
        self.assertEqual(h.statuses,("B_ONLY_CONJUGACY_WITNESSED","CONJUGATE_FULL_AB"))
        self.assertEqual(len(self.engine.verify(h.child_serialized).witness),243)

    def test_parent_unknown_does_not_block_independent_negative_child(self):
        parent=self.engine.start_cyclic(SRC,NEG,FIBER,3)
        self.assertEqual(parent.status,"UNKNOWN_BUDGET")
        h=self.link.start(parent.serialize(),244,max_states=243)
        self.assertEqual(h.statuses,("UNKNOWN_BUDGET","DISTINGUISHED_FULL_AB"))

    def test_prevent_other_laws_from_being_linked(self):
        wrong=self.engine.start_full_action(SRC,POS,5,0,max_states=243)
        with self.assertRaisesRegex(ValueError,"law pair differs"):
            self.link._assemble(self.parent.serialize(),wrong.serialize())

    def test_prevent_child_scope_substitution(self):
        with self.assertRaisesRegex(ValueError,"full A/B"):
            self.link._assemble(self.parent.serialize(),self.parent.serialize())

    def test_recomputed_outer_hash_does_not_hide_forged_child(self):
        h=self.link.start(self.parent.serialize(),17,max_states=243)
        raw=json.loads(h.serialize())
        child=json.loads(raw["child_serialized"])
        payload=json.loads(child["snapshots"][0]["payload"])
        payload["status"]="CONJUGATE_FULL_AB"
        child["snapshots"][0]["payload"]=_wire(payload)
        child["snapshots"][0]["sha256"]=_hash(_wire(payload))
        raw["child_serialized"]=_wire(child)
        raw["child_sha256"]=_hash(_wire(child))
        with self.assertRaises(ValueError):
            self.link.verify(_wire(raw))

    def test_parent_replaced_with_same_scope_but_different_laws(self):
        h=self.link.start(self.parent.serialize(),0,max_states=243)
        other=self.engine.start_cyclic(SRC,POS,FIBER,27)
        raw=json.loads(h.serialize())
        raw["parent_serialized"]=other.serialize()
        raw["parent_sha256"]=_hash(other.serialize())
        with self.assertRaises(ValueError):
            self.link.verify(_wire(raw))

    def test_changed_link_proof_rejected(self):
        h=self.link.start(self.parent.serialize(),0,max_states=243)
        raw=json.loads(h.serialize()); raw["proof"]["b_transition_checks"]=164
        with self.assertRaisesRegex(ValueError,"proof"):
            self.link.verify(_wire(raw))

    def test_ancestry_reorder_rejected(self):
        early=self.link.start(self.parent.serialize(),0,max_states=243)
        later=self.link.continue_child(early.serialize(),244)
        raw=json.loads(later.serialize())
        raw["child_lineage"].reverse()
        with self.assertRaisesRegex(ValueError,"ancestry"):
            self.link.verify(_wire(raw))

    def test_wrong_anchored_parent_or_child_rejected(self):
        h=self.link.start(self.parent.serialize(),0,max_states=243)
        with self.assertRaises(ValueError):
            self.link.verify(h.serialize(),expected_parent_question_id="wrong")
        with self.assertRaises(ValueError):
            self.link.verify(h.serialize(),expected_child_question_id="wrong")

    def test_child_budget_cannot_decrease(self):
        h=self.link.start(self.parent.serialize(),3,max_states=243)
        with self.assertRaises(ValueError):
            self.link.continue_child(h.serialize(),2)

    def test_full_space_limits_explicit(self):
        with self.assertRaisesRegex(ValueError,"resource budget"):
            self.link.start(self.parent.serialize(),0,max_states=100)

    def test_parent_original_record_is_not_changed_by_child_progress(self):
        frozen=self.parent.serialize()
        h=self.link.start(frozen,0,max_states=243)
        h2=self.link.continue_child(h.serialize(),244)
        self.assertEqual(h2.parent_serialized,frozen)
        self.assertEqual(self.engine.verify(h2.parent_serialized).status,"B_ONLY_CONJUGACY_WITNESSED")

    def test_board_candidate_contains_explicit_nonpromotion_link(self):
        with tempfile.TemporaryDirectory() as t:
            before=load_research_board(root=ROOT)
            saved=(ROOT/"index.json").read_bytes()
            h=self.link.start(self.parent.serialize(),244,max_states=243)
            stage_scope_handoff(h.serialize(),question_id="CE-AB-NEW",question="Is full A/B conjugacy established?",
                    source_board_root=ROOT,candidate_directory=Path(t)/"staged",
                    frozen_date="2026-10-09", expected_parent_question_id=self.parent.question_id,
                    derived_from=(before["questions"][0]["id"],))
            current=load_research_board(root=Path(t)/"staged")
            self.assertEqual(current["questions"][:-1],before["questions"])
            row=current["questions"][-1]
            self.assertEqual(row["status"],"REVIEW")
            self.assertEqual(row["engine_status"],"DISTINGUISHED_FULL_AB")
            self.assertTrue(row["scope_handoff"]["non_promotion"])
            self.assertEqual(row["scope_handoff"]["parent_status"],"B_ONLY_CONJUGACY_WITNESSED")
            self.assertEqual(row["scope_handoff"]["child_question_id"],h.proof["child_question_id"])
            self.assertEqual((ROOT/"index.json").read_bytes(),saved)

    def test_no_automatic_answer_even_with_full_negative(self):
        with tempfile.TemporaryDirectory() as t:
            h=self.link.start(self.parent.serialize(),17,max_states=243)
            stage_scope_handoff(h.serialize(),question_id="CE-AB-NO-URL",question="Is full A/B conjugacy established?",
                source_board_root=ROOT,candidate_directory=Path(t)/"staged",frozen_date="2026-10-09")
            row=load_research_board(root=Path(t)/"staged")["questions"][-1]
            self.assertEqual(row["status"],"REVIEW")
            self.assertEqual(row["answer"],"")

    def test_reject_rehashed_tampered_b_only_observation(self):
        h=self.link.start(self.parent.serialize(),0,max_states=243)
        raw=json.loads(h.serialize());pa=json.loads(raw["parent_serialized"])
        inner=json.loads(pa["snapshots"][0]["payload"])
        inner["observations"][0]["source_fixed"]=[0]
        pa["snapshots"][0]["payload"]=_wire(inner)
        pa["snapshots"][0]["sha256"]=_hash(_wire(inner))
        raw["parent_serialized"]=_wire(pa)
        raw["parent_sha256"]=_hash(_wire(pa))
        with self.assertRaises(ValueError):
            self.link.verify(_wire(raw))

if __name__=="__main__":unittest.main()
