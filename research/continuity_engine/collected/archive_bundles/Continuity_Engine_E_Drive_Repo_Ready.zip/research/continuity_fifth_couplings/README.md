# Continuity Engine — complete F3^5 fifth-coupling family

This is a **scoped mathematical research component**, installable alongside the existing
`work/arc_like_maze/cyclic_action_engine.py` without changing that B-only contract.

The declared grammar fixes the first four coordinate updates and lets the last update use any
`q: F3^2 → F3` (9 ternary entries), giving 19,683 laws on 243 states.
The census proves **1,098** full-label-preserving A/B conjugacy classes in this family:
positive R/S transports and four exact action-linked orbit incidence invariants.

Import the classifier:

```python
from research.continuity_fifth_couplings import ContinuityFifthCouplingClassifier as C
first = C.start((0,0,0,0,0,1,0,1,1), (0,0,0,0,1,1,0,1,0), max_features=1)
later = C.resume(first.serialize(), max_features=4, expected_question_id=first.question_id)
assert C.replay(later.serialize()).status == later.status
```

Run focused repository tests from the repository root:

```bash
python -m unittest network.tests.test_continuity_fifth_couplings -v
```

Recompute the full census (can take longer):

```bash
python -m research.continuity_fifth_couplings.verify
python -m research.continuity_fifth_couplings.verify_pairs
```

**Scope boundary:** the other source branch, earlier coupling grammar, generic cyclic/B-only
watch, ARC evaluator, runtime question-board publication, and engine handoff are unchanged.
The classifier is a **research component**, not an automatic autonomous research runtime.
`UNKNOWN` is preserved if only a limited prefix of features has been admitted.

The `portable_classification.json` data is a reproducible evidence snapshot, not code.
See `CLASSIFICATION_REPORT.md` for the mathematical definitions and limitations.
