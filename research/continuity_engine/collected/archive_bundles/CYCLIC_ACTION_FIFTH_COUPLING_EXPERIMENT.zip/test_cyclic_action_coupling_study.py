"""Independent regression checks for fifth-coupling cyclic action changes."""
import unittest
from collections import Counter
from itertools import product
import numpy as np
from cyclic_action_coupling_study import (
    ZERO, F3, STATES, Q0, Q1, B, perm, cycles, signature,
    orbit_components,group_probe,scan_all_q2
)
from cyclic_action_coupling_census import _group_order, PRE,FIFTH_IDX
from cyclic_action_group_types import maps,element_order

class CouplingTests(unittest.TestCase):
    def test_zero_reference(self):
        self.assertEqual(signature(ZERO), (((27,3),),((27,3),),((1,54),(9,3))))
    def test_all_19683_and_18_signatures(self):
        low,ref,count,_=scan_all_q2()
        self.assertEqual(sum(count.values()),19683)
        self.assertEqual(len(count),18)
        self.assertEqual(count[ref],1)
    def test_fiber_zero_B_action_does_not_change_for_sample(self):
        for q in (ZERO,(0,)*8+(1,),(1,)*9, tuple(y for z,y in product(F3,repeat=2))):
            self.assertEqual(signature(q)[0],((27,3),))
            self.assertEqual(signature(q)[1],((27,3),))
    def test_complete_state_fixed_B_formula(self):
        for q in ((0,)*8+(1,),(1,)*9, tuple(z for z,y in product(F3,repeat=2))):
            actual=sum(B(u,s,q)==s for u in F3 for s in STATES)
            self.assertEqual(actual,6*q.count(0))
    def test_group_orders_and_components_independent(self):
        fixtures={ZERO:(4374,(27,27,27)), (0,)*8+(1,):(3,(81,)),
                  (0,)*6+(1,)*3:(9,(81,)),(1,)*9:(27,(81,))}
        for q,(order,sizes) in fixtures.items():
            report=group_probe(q)
            self.assertEqual(report['fiber_preserving_full_AB_automorphism_order'],order)
            self.assertEqual(tuple(map(len,report['components'])),sizes)
    def test_jit_matches_independent_graph_enumeration(self):
        for q in ((0,)*8+(1,),(0,)*6+(1,)*3,(1,)*9,(2,)*9):
            x=int(_group_order(np.array(q,dtype=np.int32),PRE,FIFTH_IDX))
            self.assertEqual(x,group_probe(q)['fiber_preserving_full_AB_automorphism_order'])
    def test_nonzero_groups_types(self):
        for q,order,dist in (
            ((0,)*8+(1,),3,{1:1,3:2}),
            ((0,)*6+(1,)*3,9,{1:1,3:8}),
            ((1,)*9,27,{1:1,3:8,9:18}),
        ):
            elements=maps(q)
            self.assertEqual(len(elements),order)
            self.assertEqual(dict(Counter(element_order(e) for e in elements)),dist)
            self.assertTrue(all(all(f[g[i]]==g[f[i]] for i in range(81)) for f in elements for g in elements))
    def test_all_24_nonconstant_z_functions_C3_squared(self):
        n=0
        for a,b,c in product(F3,repeat=3):
            if a==b==c:continue
            q=(a,)*3+(b,)*3+(c,)*3
            elements=maps(q)
            self.assertEqual(Counter(element_order(e) for e in elements),{1:1,3:8})
            n+=1
        self.assertEqual(n,24)

if __name__=='__main__':unittest.main(verbosity=2)

class ActionWordDistinctionTests(unittest.TestCase):
    def test_nonzero_pair_same_complete_B_cycle_signature(self):
        from cyclic_action_same_B_mixed_words import Q_Z,Q_Y
        self.assertEqual(signature(Q_Z),signature(Q_Y))
    def test_shorter_action_words_do_not_distinguish(self):
        from cyclic_action_same_B_mixed_words import first_fixed_count_difference
        self.assertIsNone(first_fixed_count_difference(7))
    def test_eight_operation_word_is_exact_obstruction(self):
        from cyclic_action_same_B_mixed_words import first_fixed_count_difference,word_fixed_counts
        r=first_fixed_count_difference(8)
        self.assertEqual((r['word'],r['counts']),('ABBBabbb',(27,63)))
        self.assertEqual(word_fixed_counts('ABBBabbb'),(27,63))
        self.assertEqual(r['first_distinct_point'],(0,0,0,0,0))
        self.assertEqual(r['images'],((0,0,0,0,1),(0,0,0,0,0)))
