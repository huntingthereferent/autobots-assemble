"""Compare two fifth couplings with identical full B-cycle signatures.

Tests short reduced words in the existing A, A^-1, B, B^-1 transformations.
An unequal fixed-point count is an exact invariant obstruction to any
simultaneous full-state A/B conjugacy (no fiber restriction).
"""
from __future__ import annotations
import numpy as np
from itertools import product
from cyclic_action_coupling_study import Q0,Q1,signature,group_probe,B

F3=range(3)
STATES=tuple(product(F3,repeat=5))
INDEX={s:i for i,s in enumerate(STATES)}
Q_Z=tuple(z for z,y in product(F3,repeat=2))
Q_Y=tuple(y for z,y in product(F3,repeat=2))
INVERSE={'A':'a','a':'A','B':'b','b':'B'}


def step(x,letter,q):
    """Capital action forward; lowercase action inverse."""
    u,v,z,y,t=x
    if letter=='A':return ((u+1)%3,v,z,y,t)
    if letter=='a':return ((u-1)%3,v,z,y,t)
    if letter=='B':return (u,*B(u,(v,z,y,t),q))
    if letter=='b':
        v0=(v-u-1)%3
        z0=(z-Q0[3*u+v0])%3
        y0=(y-Q1[3*v0+z0])%3
        t0=(t-q[3*z0+y0])%3
        return (u,v0,z0,y0,t0)
    raise ValueError(letter)


def word_map(word,q):
    """Letters applied in sequence from left to right."""
    out=[]
    for x in STATES:
        for letter in word:x=step(x,letter,q)
        out.append(x)
    return tuple(out)


def word_fixed_counts(word):
    return tuple(sum(a==b for a,b in zip(STATES,word_map(word,q))) for q in (Q_Z,Q_Y))


def first_fixed_count_difference(max_depth=8):
    """Search every freely reduced word until the first differing invariant."""
    actions={q:{letter:np.array([INDEX[step(x,letter,q)] for x in STATES],dtype=np.int32)
                for letter in 'AaBb'} for q in (Q_Z,Q_Y)}
    identity=np.arange(len(STATES),dtype=np.int32)
    frontier=[('', '', identity,identity)]
    checked=0
    for depth in range(1,max_depth+1):
        new=[]
        for word,last,left,right in frontier:
            for letter in 'AaBb':
                if last and letter==INVERSE[last]:continue
                w=word+letter
                l=actions[Q_Z][letter][left]
                r=actions[Q_Y][letter][right]
                checked+=1
                a=int(np.count_nonzero(l==identity))
                b=int(np.count_nonzero(r==identity))
                if a!=b:
                    first_idx=int(np.flatnonzero(l!=r)[0])
                    return {
                        'word':w,'length':depth,
                        'counts':(a,b),
                        'words_checked_including_witness':checked,
                        'first_distinct_point':STATES[first_idx],
                        'images':(STATES[int(l[first_idx])],STATES[int(r[first_idx])]),
                    }
                new.append((w,letter,l,r))
        frontier=new
    return None


def main():
    assert signature(Q_Z)==signature(Q_Y)
    found=first_fixed_count_difference(8)
    assert found and found['length']==8
    assert found['word']=='ABBBabbb'
    assert found['counts']==(27,63)
    assert word_fixed_counts(found['word'])==(27,63)
    print('B_SIGNATURE_BOTH',signature(Q_Z))
    print('FIRST_FULL_AB_WORD_OBSTRUCTION',found)
    print('GROUP_ORDERS',9,3)
    return found

if __name__=='__main__':main()
