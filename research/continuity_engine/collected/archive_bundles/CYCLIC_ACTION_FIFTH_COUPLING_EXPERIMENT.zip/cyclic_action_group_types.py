"""Independently inspect structure of all transitive centralizers found in census."""
from itertools import product
from collections import Counter,deque
from math import lcm
from cyclic_action_coupling_study import STATES,perm

qcases={'pulse':(0,)*8+(1,),
'z_only':(0,0,0,0,0,0,1,1,1),
'constant_one':(1,)*9,
'constant_two':(2,)*9,
'z_only_other':(0,0,0,1,1,1,2,2,2)}

def maps(q):
    perms=tuple(perm(u,q) for u in range(3))
    maps=[]
    for target in range(81):
        f={0:target};queue=deque([0]);ok=True
        while queue and ok:
            v=queue.popleft();fv=f[v]
            for P in perms:
                pfp=P[fv];pv=P[v]
                if pv in f:
                    if f[pv]!=pfp:ok=False;break
                else:f[pv]=pfp;queue.append(pv)
        if ok and len(f)==81 and len(set(f.values()))==81:
            maps.append(tuple(f[i] for i in range(81)))
    return maps

def element_order(p):
    seen=set();d=1
    for i in range(len(p)):
        if i in seen:continue
        j=i;n=0
        while j not in seen:
            seen.add(j);n+=1;j=p[j]
        assert j==i
        d=lcm(d,n)
    return d

if __name__=='__main__':
    for name,q in qcases.items():
        elems=maps(q)
        counts=Counter(element_order(g) for g in elems)
        commute=sum(all(x[y[i]]==y[x[i]] for i in range(81)) for x in elems for y in elems)
        print(name,'order',len(elems),'orders',dict(counts),'commuting_pairs',commute,'total_pairs',len(elems)**2)
        if name=='z_only': assert len(elems)==9
        if name.startswith('constant'): assert len(elems)==27
