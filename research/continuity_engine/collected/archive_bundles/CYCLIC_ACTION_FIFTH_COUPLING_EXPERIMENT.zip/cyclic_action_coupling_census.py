"""Fast exhaustive automorphism group census for every fifth coupling over F3.

Check the declared *fiber-preserving* full-A/B centralizer. On x0=0 the
joint transported generators are B_u = A^{-u}BA^u for u=0,1,2.
For nonzero coupling their joint action is transitive on 81 states;
the equivariant automorphisms are determined by the image of one root.
"""
from itertools import product
from collections import Counter
import json
import numpy as np
from numba import njit
from cyclic_action_coupling_study import F3, Q0, Q1, ZERO, STATES, perm,group_probe

PRE=np.empty((3,81),dtype=np.int32)
FIFTH_IDX=np.empty(81,dtype=np.int32)
for i,(v,z,y,t) in enumerate(STATES):
    FIFTH_IDX[i] = 3*z+y
    for u in F3:
        vn=(v+u+1)%3
        zn=(z+Q0[3*u+v])%3
        yn=(y+Q1[3*v+z])%3
        PRE[u,i]=((vn*3+zn)*3+yn)*3

@njit
def _group_order(q2,PRE,FIFTH_IDX):
    D=np.empty((3,81),dtype=np.int32)
    for u in range(3):
        for i in range(81):
            D[u,i]=PRE[u,i]+(i%3+q2[FIFTH_IDX[i]])%3
    good=0
    for target in range(81):
        f=np.full(81,-1,dtype=np.int32)
        queue=np.empty(81,dtype=np.int32)
        f[0]=target
        queue[0]=0
        num=1
        pos=0
        ok=True
        while pos<num and ok:
            x=queue[pos];pos+=1
            y=f[x]
            for u in range(3):
                xx=D[u,x]
                yy=D[u,y]
                if f[xx]<0:
                    f[xx]=yy
                    queue[num]=xx
                    num+=1
                elif f[xx]!=yy:
                    ok=False
                    break
        if ok and num==81:
            good+=1
    return good

def census():
    # JIT compile using a nonzero example.
    _group_order(np.array((0,)*8+(1,),dtype=np.int32),PRE,FIFTH_IDX)
    counts=Counter();examples={}
    for q2 in product(range(3),repeat=9):
        if q2==ZERO:continue
        order=int(_group_order(np.array(q2,dtype=np.int32),PRE,FIFTH_IDX))
        counts[order]+=1
        examples.setdefault(order,q2)
    assert sum(counts.values())==19682
    for order,q2 in examples.items():
        verified=group_probe(q2)['fiber_preserving_full_AB_automorphism_order']
        assert verified==order,(order,q2,verified)
    print('ALL_NONZERO_19682_GROUP_ORDERS',dict(sorted(counts.items())))
    print('EXAMPLES',examples)
    with open('/mnt/data/cyclic_action_coupling_group_census.json','w') as f:
        json.dump({'nonzero_q2_count':19682,
                   'fiber_preserving_full_AB_centralizer_orders':dict(sorted(counts.items())),
                   'example_q2_by_order':examples,
                   'full_zero_q2_order':4374,
                   'rooted_count_for_each_nonzero':1,
                   'scope':'x0-preserving full simultaneous A/B automorphisms over 243 states'},f,indent=2)
    return counts,examples

if __name__=='__main__':census()
