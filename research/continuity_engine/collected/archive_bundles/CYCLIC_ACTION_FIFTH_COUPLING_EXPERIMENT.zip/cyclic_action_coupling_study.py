"""Cyclic Action Engine: exact coupling-change witnesses and group classifications.

This independent implementation is formula-matched to the repository's
WindowProcess.step, and the all-19683 scan is also verified separately
against WindowProcess itself. Finite dimension 5 over F3; action B on each
x0 fiber, action A advances x0 by one. No GitHub modifications.
"""
from __future__ import annotations
from collections import Counter, deque
from itertools import product, permutations
from math import factorial
from typing import Sequence
import json

F3=range(3)
STATES=tuple(product(F3,repeat=4)) # (v,z,y,t), fiber x0=0
INDEX={x:i for i,x in enumerate(STATES)}
ZERO=(0,)*9
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(u==2 and v==2) for u,v in product(F3,repeat=2))


def B(u: int,s:tuple[int,...],q2:Sequence[int])->tuple[int,...]:
    v,z,y,t=s
    return ((v+(u+1))%3,(z+Q0[3*u+v])%3,
            (y+Q1[3*v+z])%3,(t+q2[3*z+y])%3)


def perm(u,q2):
    return tuple(INDEX[B(u,s,q2)] for s in STATES)


def cycles(P):
    remaining=set(range(len(P)));out=[]
    while remaining:
        i=min(remaining);cur=i;orbit=[]
        while cur not in orbit:
            assert cur in remaining
            orbit.append(cur)
            remaining.remove(cur)
            cur=P[cur]
        assert cur==i
        out.append(tuple(orbit))
    return tuple(out)


def signature(q2):
    return tuple(tuple(sorted(Counter(len(c) for c in cycles(perm(u,q2))).items())) for u in F3)


def orbit_components(perms):
    adj=[set() for _ in range(81)]
    for P in perms:
        for i,j in enumerate(P):
            adj[i].add(j);adj[j].add(i)
    unseen=set(range(81));components=[]
    while unseen:
        start=min(unseen);todo=[start];seen={start};unseen.remove(start)
        for v in todo:
            for w in sorted(adj[v]):
                if w not in seen:
                    seen.add(w);todo.append(w);unseen.remove(w)
        components.append(tuple(sorted(seen)))
    return tuple(components)


def equivariant_map_count(perms,components):
    """Count all maps commuting with the three B permutations.

    Each map between transitive components is forced by one source mark image.
    Enumerate allowed mark images (at most 81 per component), then count
    mutually exclusive component assignments using an exact permutation sum.
    """
    by_component={v:i for i,C in enumerate(components) for v in C}
    counts={}
    first_map={}
    for i,C in enumerate(components):
        origin=C[0]
        for j,D in enumerate(components):
            n_good=0
            for target in D:
                mapping={origin:target};queue=deque([origin]);good=True
                while queue and good:
                    x=queue.popleft();image=mapping[x]
                    for P in perms:
                        a,b=P[x],P[image]
                        if a in mapping:
                            if mapping[a]!=b:good=False;break
                        else:
                            mapping[a]=b;queue.append(a)
                if good and len(mapping)==len(C) and len(set(mapping.values()))==len(C) and set(mapping.values())==set(D):
                    n_good+=1
                    first_map.setdefault((i,j),mapping.copy())
            counts[i,j]=n_good
    answer=0
    for assign in permutations(range(len(components))):
        mul=1
        for i,j in enumerate(assign):mul*=counts[i,j]
        answer+=mul
    return answer,counts,first_map


def scan_all_q2():
    # The lower x0=0 and x0=1 orbit covers each pair (z,y) three times,
    # so total q2 per 27-cycle = 3*sum(q2)=0 mod 3 always.
    from collections import defaultdict
    low_states=list(product(F3,repeat=3))
    def low_orbits(u):
        remaining=set(low_states);cycles=[]
        while remaining:
            initial=min(remaining);v=initial;cycle=[]
            while v not in cycle:
                assert v in remaining
                cycle.append(v);remaining.remove(v)
                v=B(u,(*v,0),ZERO)[:3]
            assert v==initial
            cycles.append(tuple(cycle))
        return cycles
    low={u:low_orbits(u) for u in F3}
    print('LOWER_ORBIT_SIGNATURES', {u:dict(Counter(map(len,cs))) for u,cs in low.items()})
    ref=signature(ZERO)
    counts=Counter();samples={}
    for q2 in product(F3,repeat=9):
        sig=[]
        for u in F3:
            freq=Counter()
            for orb in low[u]:
                d=len(orb)
                shift=sum(q2[3*z+y] for _v,z,y in orb)%3
                if shift==0:freq[d]+=3
                else:freq[3*d]+=1
            sig.append(tuple(sorted(freq.items())))
        sig=tuple(sig)
        counts[sig]+=1
        samples.setdefault(sig,q2)
        assert sig[:2]==ref[:2]
        if q2!=ZERO:assert sig!=ref
    assert sum(counts.values())==3**9
    return low,ref,counts,samples


def group_probe(q):
    perms=tuple(perm(u,q) for u in F3)
    comps=orbit_components(perms)
    order,count_matrix,witness=equivariant_map_count(perms,comps)
    return {'coupling':q,'B_signature':signature(q),
            'component_sizes':tuple(map(len,comps)),
            'fiber_preserving_full_AB_automorphism_order':order,
            'admissible_maps_between_components':count_matrix,
            'witness':witness,'components':comps}


def main():
    low,reference,signatures,samples=scan_all_q2()
    print('REFERENCE',reference)
    print('DIFFERENT_FULL_B_CYCLE_SIGNATURES',len(signatures))
    print('NONZERO_DIFFERENT_FULL_B_COUNTS',sum(n for s,n in signatures.items() if s!=reference))
    print('MOST_COMMON',signatures.most_common(5))
    candidates={
        'zero':ZERO,
        'single_pulse_at_22':(0,0,0,0,0,0,0,0,1),
        'constant_one':(1,)*9,
        'coordinate_z':tuple(z for z,y in product(F3,repeat=2)),
        'coordinate_y':tuple(y for z,y in product(F3,repeat=2)),
        'sum_zero_variation':(0,1,2,1,2,0,2,0,1),
    }
    results={}
    for name,q in candidates.items():
        p=group_probe(q)
        result={'q2':q,'B_cycle_signature':p['B_signature'],
                'joint_component_sizes':p['component_sizes'],
                'automorphism_order':p['fiber_preserving_full_AB_automorphism_order'],
                'admissible_map_counts':{'%s,%s'%k:v for k,v in p['admissible_maps_between_components'].items()}}
        results[name]=result
        print('GROUP',name,json.dumps(result))
    with open('/mnt/data/cyclic_action_coupling_results.json','w') as f:
        json.dump({'total_fifth_couplings':3**9,
                   'reference_signature':reference,
                   'number_full_B_cycle_signatures':len(signatures),
                   'full_B_signature_counts':[
                       {'signature':s,'count':n,'example_q2':samples[s]}
                       for s,n in signatures.most_common()],
                   'examples':results,
                   'scope':'five coordinates over F3; fiber-preserving A/B automorphism groups'},f,indent=2)
    return results

if __name__=='__main__':main()
