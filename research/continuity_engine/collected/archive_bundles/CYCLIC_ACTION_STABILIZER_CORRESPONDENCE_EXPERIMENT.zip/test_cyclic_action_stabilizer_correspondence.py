"""Regression coverage for finite path-collision and joint fixed-set witnesses."""
import unittest
from collections import Counter
from cyclic_action_stabilizer_correspondence import (
    SOURCE,TARGET,TARGET_POSITIVE,STATES,INDEX,
    WORD_1,WORD_2,SOURCE_PARAMETERS,TARGET_PARAMETERS,N,
    path_tree,path_collision_basis,survivor_images,verified_correspondence,
    fixed,independent_word_fixed,independent_transition,actions,apply,report,
)
from cyclic_action_simultaneous_conjugacy import find_conjugacy,reach_count
from cyclic_action_y_rotation_theorem import R


class StabilizerCorrespondenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.basis=path_collision_basis(SOURCE)
        cls.paths=path_tree(SOURCE)

    def test_action_is_exactly_transitive(self):
        self.assertEqual((N,reach_count(SOURCE),reach_count(TARGET)),(243,243,243))
        self.assertEqual(len(self.paths),243)
        self.assertEqual(max(map(len,self.paths.values())),11)

    def test_schreier_generator_basis_size_and_root_loops(self):
        self.assertEqual(len(self.basis),244)
        self.assertEqual(len(set(self.basis)),244)
        self.assertEqual(sum(len(w)<=13 for w in self.basis),66)
        ed=actions(SOURCE)
        self.assertTrue(all(apply(ed,w,0)==0 for w in self.basis))

    def test_two_words_same_individual_counts_different_intersections(self):
        a,b=fixed(SOURCE,WORD_1),fixed(SOURCE,WORD_2)
        c,d=fixed(TARGET,WORD_1),fixed(TARGET,WORD_2)
        self.assertEqual([len(a),len(b)],[39,15])
        self.assertEqual([len(c),len(d)],[39,15])
        self.assertEqual((len(a&b),len(c&d)),(3,0))
        self.assertEqual([STATES[i] for i in sorted(a&b)],[(0,0,0,0,t) for t in range(3)])

    def test_both_evaluators_agree_on_each_word(self):
        for system in (SOURCE,TARGET,TARGET_POSITIVE):
            for w in (WORD_1,WORD_2):
                self.assertEqual(fixed(system,w),independent_word_fixed(system.q,w))

    def test_independent_generator_and_inverse_actions_on_all_states(self):
        for system in (SOURCE,TARGET):
            e=actions(system)
            for x in STATES:
                i=INDEX[x]
                for letter in 'AaBb':
                    self.assertEqual(INDEX[independent_transition(x,letter.upper(),system.q,letter.islower())],e[letter][i])

    def test_negative_exact_intersection_stops_at_fourteenth_loop_depth(self):
        short=survivor_images(TARGET,tuple(w for w in self.basis if len(w)<=13))
        longer=survivor_images(TARGET,tuple(w for w in self.basis if len(w)<=14))
        self.assertEqual([STATES[i] for i in sorted(short)],[(0,0,2,1,t) for t in range(3)])
        self.assertEqual(longer,frozenset())
        self.assertEqual(survivor_images(TARGET,self.basis),frozenset())

    def test_positive_R_transport_has_three_verified_conjugacies(self):
        survivors=survivor_images(TARGET_POSITIVE,self.basis)
        self.assertEqual([STATES[i] for i in sorted(survivors)],[(0,0,1,0,t) for t in range(3)])
        self.assertIn(INDEX[R(STATES[0])],survivors)
        for index in survivors:
            f=verified_correspondence(SOURCE,TARGET_POSITIVE,index,self.paths)
            self.assertEqual(len(set(f)),243)
            for i,x in enumerate(STATES):
                self.assertEqual(f[SOURCE.A[i]],TARGET_POSITIVE.A[f[i]])
                self.assertEqual(f[SOURCE.B[i]],TARGET_POSITIVE.B[f[i]])

    def test_same_source_recovers_all_three_root_images(self):
        survivors=survivor_images(SOURCE,self.basis)
        self.assertEqual([STATES[i] for i in sorted(survivors)],[(0,0,0,0,t) for t in range(3)])
        self.assertIn(0,survivors)

    def test_independent_complete_conjugacy_search_agrees(self):
        self.assertEqual(find_conjugacy(SOURCE,TARGET),(None,243))
        positive,_=find_conjugacy(SOURCE,TARGET_POSITIVE)
        self.assertIsNotNone(positive)

    def test_certified_record_is_reproducible(self):
        result=report()
        self.assertEqual((result['basis_size'], result['joint_certificate']['joint_source_fixed_count'],
                          result['joint_certificate']['joint_target_fixed_count']), (244,3,0))
        self.assertEqual(result['positive_target_verified_full_AB_conjugacies'],3)


if __name__=='__main__':unittest.main(verbosity=2)
