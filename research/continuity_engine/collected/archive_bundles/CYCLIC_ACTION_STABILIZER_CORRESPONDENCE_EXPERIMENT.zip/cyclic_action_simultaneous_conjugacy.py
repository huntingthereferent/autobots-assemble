"""Exact finite full-state A/B-conjugacy search for 5D F3 two-input windows.

For nonzero q, the A/B action is transitive. Every intertwiner is determined
by the image of the origin. Enumerating all 243 images is therefore complete.
For arbitrary q the routine also verifies transitiveness explicitly and would
refuse to treat a negative result as complete otherwise.

Use same q0,q1 and fifth q table as established research. Pure Python.
"""
from __future__ import annotations
from collections import deque, Counter
from itertools import product
from dataclasses import dataclass
import json
F3 = (0,1,2)
STATES = tuple(product(F3,repeat=5))
INDEX = {s:i for i,s in enumerate(STATES)}
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(F3,repeat=2))
ZERO=(0,)*9
QZ=tuple(z for z,y in product(F3,repeat=2))
QY=tuple(y for z,y in product(F3,repeat=2))

@dataclass(frozen=True)
class System:
    q: tuple[int,...]
    A: tuple[int,...]
    B: tuple[int,...]
    @staticmethod
    def construct(q):
        assert len(q)==9 and all(d in F3 for d in q)
        A=[];B=[]
        for u,v,z,y,t in STATES:
            A.append(INDEX[((u+1)%3,v,z,y,t)])
            B.append(INDEX[(u,(v+u+1)%3,(z+Q0[3*u+v])%3,(y+Q1[3*v+z])%3,(t+q[3*z+y])%3)])
        return System(tuple(q),tuple(A),tuple(B))

def reach_count(w):
    seen={0};queue=deque([0])
    while queue:
        x=queue.popleft()
        for edge in (w.A,w.B):
            y=edge[x]
            if y not in seen:seen.add(y);queue.append(y)
    return len(seen)

def find_conjugacy(src: System,dst: System,rooted=False):
    """Complete when src's A/B action is transitive. Returns H or None."""
    assert reach_count(src)==243, 'source action not transitive: cannot use 1-point search'
    assert reach_count(dst)==243, 'target action not transitive: cannot use 1-point search'
    tested=0
    for selected in ((0,) if rooted else range(243)):
        tested+=1
        mapping=[-1]*243
        mapping[0]=selected
        target_used={selected}
        queue=deque([0]);good=True
        while queue and good:
            a=queue.popleft();b=mapping[a]
            for f,g in ((src.A,dst.A),(src.B,dst.B)):
                x=f[a];y=g[b]
                prev=mapping[x]
                if prev!=-1:
                    if prev!=y:good=False;break
                else:
                    if y in target_used:good=False;break
                    mapping[x]=y;target_used.add(y);queue.append(x)
        if good:
            assert len(target_used)==243 and all(m>=0 for m in mapping)
            assert all(mapping[src.A[x]]==dst.A[mapping[x]] and mapping[src.B[x]]==dst.B[mapping[x]] for x in range(243))
            return tuple(mapping),tested
    return None,tested

def word_fixed(w,word):
    # With inverses for mixed word differences (left-to-right application)
    def inv(p):
        out=[0]*243
        for a,b in enumerate(p):out[b]=a
        return tuple(out)
    steps={'A':w.A,'B':w.B,'a':inv(w.A),'b':inv(w.B)}
    pos=list(range(243))
    for c in word:pos=[steps[c][x] for x in pos]
    return sum(x==i for i,x in enumerate(pos))

def word_signature(w):
    words=('B','BBB','BBBBBBBBB','ABBBabbb','ABBaabb','ABab','ABABabab','ABBAabba')
    return tuple(word_fixed(w,s) for s in words)

def z_only(f):return tuple(f[z] for z,y in product(F3,repeat=2))

def classify():
    systems={f:System.construct(z_only(f)) for f in product(F3,repeat=3) if any(f)}
    assert len(systems)==26
    assert all(reach_count(w)==243 for w in systems.values())
    unclassified=set(systems)
    classes=[]
    full_negative=[]
    while unclassified:
        representative=min(unclassified)
        a=systems[representative]
        group=[]
        for f in sorted(unclassified):
            m,trials=find_conjugacy(a,systems[f])
            if m is not None:group.append(f)
            else:full_negative.append((representative,f,trials))
        unclassified.difference_update(group)
        classes.append(group)
    print('Z_ONLY_NONZERO_CLASSES',len(classes),[{'size':len(c),'representative':list(c[0]),'members':[list(x) for x in c]} for c in classes])
    for c in classes:
        rep=systems[c[0]]
        print('CLASS',c[0],'WORD_SIGNATURE',word_signature(rep))
    z=System.construct(QZ);twoz=System.construct(tuple((2*x)%3 for x in QZ));y=System.construct(QY)
    M,tested=find_conjugacy(z,twoz,rooted=True)
    assert M is not None and all(STATES[M[i]]==(*s[:4],(s[4]*2)%3) for i,s in enumerate(STATES))
    negative,ntrials=find_conjugacy(z,y)
    assert negative is None and ntrials==243
    print('Z_AND_2Z_ROOTED_EQUIVALENT',len(M),'witness origin',STATES[M[0]])
    print('Z_AND_Y_UNRESTRICTED_NO_MAP',ntrials,'anchor_images_exhausted','word8_counts',(word_fixed(z,'ABBBabbb'),word_fixed(y,'ABBBabbb')))
    # Select a pair of non-conjugate z-only systems with matching 8-word selected signatures
    hard=[]
    for i,c in enumerate(classes):
      for j,d in enumerate(classes):
        if j<=i:continue
        a=systems[c[0]];b=systems[d[0]]
        if word_signature(a)==word_signature(b):
            hard.append((c[0],d[0]))
    print('INCONCLUSIVE_SELECTED_WORDS_ACROSS_CLASSES',hard[:15],'COUNT',len(hard))
    return {'classification':[{'representative':list(c[0]),'size':len(c),'members':[list(x) for x in c], 'sample_word_signature':word_signature(systems[c[0]])} for c in classes], 'negative_checks':len(full_negative), 'chosen_words_inconclusive':[[list(a),list(b)] for a,b in hard], 'z_to_2z_rooted_witness':[[list(STATES[i]),list(STATES[M[i]])] for i in range(243)],'z_vs_y_rejected_origin_images':ntrials}

if __name__=='__main__':
    report=classify()
    with open('/mnt/data/cyclic_action_simultaneous_conjugacy_results.json','w') as f:json.dump(report,f,indent=2)
