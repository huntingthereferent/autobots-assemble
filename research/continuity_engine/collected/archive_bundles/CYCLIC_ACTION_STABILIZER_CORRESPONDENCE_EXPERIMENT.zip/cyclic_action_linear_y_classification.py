"""Exact conjugacy classification: q(z,y) = a_z + b_z*y over F3, b != 0.

Covers 702 laws. Every system's full A/B action is checked transitive.
Candidate conjugacies are exhaustively tested by transporting the origin
through all 243 points of the target transitive labeled action.
"""
from itertools import product,combinations
from collections import Counter,defaultdict
import json
from time import perf_counter
from cyclic_action_simultaneous_conjugacy import System, reach_count,find_conjugacy,STATES,word_fixed
def table(p):
    a,b=p
    return tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))
params=[(a,b) for a in product(range(3),repeat=3) for b in product(range(3),repeat=3) if any(b)]
def signature(w):
    return tuple(word_fixed(w,word) for word in ('B','BBB','BBBBBBBBB','ABBBabbb'))
F3=range(3)

def transform(p,lam,k):
    a,b=p
    return (tuple(lam*(a[z]-k*b[z])%3 for z in F3),tuple(lam*b[z]%3 for z in F3))

def lift_map(p,lam,k):
    """A/B conjugacy H(u,v,z,y,t)=(u,v,z,y+k,lam*t)."""
    q1=table(p); p2=transform(p,lam,k); q2=table(p2)
    assert all(q2[3*z+(y+k)%3]==lam*q1[3*z+y]%3 for z,y in product(F3,repeat=2))
    return p2,lambda s:(*s[:3],(s[3]+k)%3,(lam*s[4])%3)

def classify():
    t0=perf_counter()
    systems={p:System.construct(table(p)) for p in params}
    print('TRANSITIVE_COUNTER',Counter(reach_count(s) for s in systems.values()))
    assert all(reach_count(s)==243 for s in systems.values())
    families=set(params);classes=[]
    while families:
        p=min(families)
        orbit=sorted({transform(p,lam,k) for lam in (1,2) for k in F3})
        assert len(orbit)==6 and set(orbit)<=families
        classes.append(tuple(orbit)); families.difference_update(orbit)
    assert len(classes)==117 and sum(len(c) for c in classes)==702
    reps=[c[0] for c in classes]
    identities=Counter()
    for i,p in enumerate(reps):
        for lam in (1,2):
            for k in F3:
                target,h=lift_map(p,lam,k)
                sw=systems[p];tw=systems[target]
                assert len({h(x) for x in STATES})==243
                assert all(h(STATES[sw.A[j]])==STATES[tw.A[STATES.index(h(x))]] for j,x in enumerate(STATES))
                # B direct check on full 243 states
                inv={x:i for i,x in enumerate(STATES)}
                assert all(h(STATES[sw.B[j]])==STATES[tw.B[inv[h(x)]]] for j,x in enumerate(STATES))
                identities['positive_action_checks']+=243*2
    signatures={p:signature(systems[p]) for p in reps}
    for c in classes:
        assert len({signature(systems[p]) for p in c})==1
    groups=defaultdict(list)
    for p in reps:groups[signatures[p]].append(p)
    parent={p:p for p in reps}
    def find(p):
        while parent[p]!=p:
            parent[p]=parent[parent[p]];p=parent[p]
        return p
    def union(p,r):
        a,b=find(p),find(r)
        if a!=b:parent[max(a,b)]=min(a,b)
    cross=0;trials=0;unexpected_positive=[]
    for sig,group in groups.items():
        for p,r in combinations(group,2):
            witness,count=find_conjugacy(systems[p],systems[r]);cross+=1;trials+=count
            if witness is not None:
                union(p,r)
                unexpected_positive.append((p,r))
    combined=defaultdict(list)
    for c in classes:
        rep=c[0]
        combined[find(rep)].extend(c)
    fullclasses=[tuple(sorted(v)) for v in combined.values()]
    fullclasses.sort()
    print('KNOWN_GAUGE_CLASSES',len(classes),'NEW_CROSS_GAUGE_POSITIVES',len(unexpected_positive))
    print('ACTUAL_UNROOTED_CLASSES',len(fullclasses),'DISTRIBUTION',Counter(map(len,fullclasses)))
    print('ROOTED_EXAMPLES_CROSS',unexpected_positive[:12])
    rooted_counts=[]
    for c in fullclasses:
        rep=c[0]
        positive=[]
        for q in c:
            m,count=find_conjugacy(systems[rep],systems[q],rooted=True)
            if m is not None:positive.append(q)
        rooted_counts.append(len(positive))
    print('ROOTED_CLASS_SIZE_DISTRIBUTION_FROM_REP',Counter(rooted_counts))
    print('CROSS_ORBIT_NEGATIVE_CHECKS',cross,'TRIALS',trials)
    firstp,secondp=((0,0,0),(1,2,1)),((0,0,1),(1,2,2))
    s1,s2=systems[firstp],systems[secondp]
    old='ABBBabbb'; new='ABBabbbb'
    observations={w:(word_fixed(s1,w),word_fixed(s2,w)) for w in ('B','BBB','BBBBBBBBB',old,new)}
    assert observations[old]==(39,39) and observations[new]==(21,12)
    assert find_conjugacy(s1,s2)[0] is None
    print('HARD_PAIR_WORD_COUNTS',observations)
    full_sizes=Counter(map(len,fullclasses))
    assert all(len(c)%6==0 for c in fullclasses)
    allpositive=sum(len(c)**2 for c in fullclasses)
    rooted_total=sum(len(c)*r for c,r in zip(fullclasses,rooted_counts))
    info={
      'family':'q(z,y)=a_z+b_z*y, b != 0 in F3^3',
      'laws':702,'transitive_orbit_size':243,
      'unrooted_classes':len(fullclasses),'unrooted_class_size_distribution':dict(full_sizes),
      'rooted_rep_class_size_distribution':dict(Counter(rooted_counts)),
      'ordered_positive':allpositive,'ordered_rooted_positive':rooted_total,
      'ordered_negative':702*702-allpositive,
      'class_representatives':[{'a':c[0][0],'b':c[0][1], 'size':len(c),'fingerprint':signature(systems[c[0]])} for c in fullclasses],
      'coarse_signatures':len(groups),'cross_orbit_searches':cross,
      'cross_orbit_unexpected_positive':len(unexpected_positive),
      'cross_orbit_origin_trials':trials,
      'positive_action_checks':identities['positive_action_checks'],
      'hard_negative':{'source':{'a':firstp[0],'b':firstp[1]},'target':{'a':secondp[0],'b':secondp[1]},'observations':observations,'origin_images_rejected':243},
      'runtime_seconds':round(perf_counter()-t0,3)
    }
    with open('/mnt/data/CYCLIC_ACTION_LINEAR_Y_RESULTS.json','w') as f:json.dump(info,f,indent=2)
    print('POSITIVES',info['ordered_positive'],'ROOTED',info['ordered_rooted_positive'],
          'NEGATIVES',info['ordered_negative'], 'TIME',info['runtime_seconds'])
    return info
if __name__=='__main__':classify()
