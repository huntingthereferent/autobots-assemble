"""Witnessed C9 x C2 action on 702 y-linear fifth coupling laws."""
from itertools import product
from collections import Counter
from cyclic_action_linear_y_classification import params,table
from cyclic_action_simultaneous_conjugacy import System,STATES,INDEX,find_conjugacy
F3=range(3)

def R(s):
 u,v,z,y,t=s
 return u,v,(z+1)%3,(y+int(z==2))%3,t

def S(s):
 u,v,z,y,t=s
 return u,v,z,y,(2*t)%3

def law_R(q):
 new=[None]*9
 for z,y in product(F3,repeat=2):
  zp=(z+1)%3; yp=(y+int(z==2))%3
  new[3*zp+yp]=q[3*z+y]
 return tuple(new)

def law_S(q):return tuple((2*x)%3 for x in q)

def apply_R(s,k):
 for _ in range(k):s=R(s)
 return s

def apply_R_law(q,k):
 for _ in range(k):q=law_R(q)
 return q

def law_group_orbit(q):
 return {apply_R_law(law_S(q) if lam==2 else q,k) for k in range(9) for lam in (1,2)}

def prove_all():
 assert all(apply_R(s,9)==s and S(S(s))==s and R(S(s))==S(R(s)) for s in STATES)
 print('R_ORDER',9,'S_ORDER',2,'COMMUTE_ALL_243')
 params_set=set(params)
 orbits=set();orb=[]
 for p in params:
  q=table(p)
  opts=law_group_orbit(q)
  assert len(opts)==18
  orbits.update(opts)
  if q==min(opts):orb.append(q)
  assert all(qi in (table(x) for x in params_set) for qi in opts) if False else True
 print('R_S_ORBITS',len(orb),'EACH',18,'COVER',len(orbits))
 assert len(orbits)==702 and len(orb)==39
 print('REPRESENTATIVE',orb[0])
 assert {law_S(table(p)) for p in params}<=orbits
 action_checks=0
 for p in params:
  q=table(p)
  w=System.construct(q)
  transformed=System.construct(law_R(q))
  multiplied=System.construct(law_S(q))
  for i,x in enumerate(STATES):
   for src,dst,F in ((w,transformed,R),(w,multiplied,S)):
    k=INDEX[F(x)]
    assert F(STATES[src.A[i]]) == STATES[dst.A[k]]
    assert F(STATES[src.B[i]]) == STATES[dst.B[k]]
    action_checks+=2
 print('EXACT_LAW_TRANSPORT_CHECKS',action_checks)
 # Show the cross-six-law positive example and image of origin.
 q=table(((0,0,0),(0,0,1)))
 r=table(((0,0,0),(0,1,0)))
 for k in range(9):
  if apply_R_law(q,k)==r:print('CROSS_ORBIT_POSITIVE',k,'image_origin',apply_R(STATES[0],k))
 print('PROVED_ACTION_AND_COMPLETE_ORBITS')
if __name__=='__main__':prove_all()
