"""Witness-preserving transport of A- or B-invariant subsets along full conjugacies."""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from hashlib import sha256

from research.continuity_engine import ContinuityEngine, FULL_AB, _wire
from research.simultaneous_action_correspondence import _restore_law

@dataclass(frozen=True)
class InvariantTransport:
    proof: dict

    def serialize(self):
        return _wire(self.proof)


def transport_invariant(full_action_record, carrier, *, generator, named_target=None):
    """Construct H(C) and certify T'(H(C))=H(C) and H T=T' H on C.

    The image is not assumed equal to the chosen target carrier.  If a target
    subset is supplied, membership is compared explicitly and reported.
    """
    if generator not in ("A", "B"):
        raise ValueError("generator must be A or B")
    result = ContinuityEngine().verify(full_action_record)
    if result.area != FULL_AB or result.status != "CONJUGATE_FULL_AB":
        raise ValueError("an independently proved full A/B conjugacy is required")
    question = result.research_question
    dim = question["dimension"]
    states = tuple(product(range(3), repeat=dim))
    n = len(states)
    source_law, target_law = _restore_law(question["source"]), _restore_law(question["target"])
    mapping = result.witness
    if (not isinstance(mapping, list) or len(mapping) != n or
        any(not isinstance(p, list) or len(p) != 2 or p[0] != i or
            type(p[1]) is not int or not 0 <= p[1] < n
            for i, p in enumerate(mapping)) or
        len({p[1] for p in mapping}) != n):
        raise ValueError("full conjugacy bijection missing or noncanonical")
    index = {s: i for i, s in enumerate(states)}
    src = tuple(tuple(s) for s in carrier)
    if (not src or tuple(sorted(src)) != src or len(set(src)) != len(src)
        or any(s not in index for s in src)):
        raise ValueError("source carrier must be canonical, nonempty and in the full domain")
    srcset = set(src)
    dst = tuple(sorted(states[mapping[index[s]][1]] for s in src))
    dstset = set(dst)
    for s in src:
        a = source_law.step(s, generator)
        if a not in srcset:
            raise ValueError("selected source carrier is not invariant")
        image_a = states[mapping[index[a]][1]]
        image_s = states[mapping[index[s]][1]]
        b = target_law.step(image_s, generator)
        if b not in dstset or b != image_a:
            raise ValueError("full correspondence does not transport invariance")
    same_named = None
    named_digest = None
    if named_target is not None:
        named = tuple(tuple(s) for s in named_target)
        if (len(named) != len(dst) or len(set(named)) != len(named)
            or named != tuple(sorted(named)) or any(s not in index for s in named)):
            raise ValueError("named target must be canonical with same carrier size")
        if any(target_law.step(s, generator) not in set(named) for s in named):
            raise ValueError("named target is not invariant")
        same_named = named == dst
        named_digest = sha256(_wire(named).encode()).hexdigest()
    return InvariantTransport({
        "schema": "transport_invariant.v1", "full_question_id": result.question_id,
        "snapshot_digest": result.snapshots[-1]["sha256"],
        "generator": generator, "source_carrier": [list(s) for s in src],
        "transported_carrier": [list(s) for s in dst],
        "source_size": len(src), "image_size": len(dst),
        "source_transition_checks": len(src), "target_transition_checks": len(dst),
        "intertwining_checks": len(src),
        "named_target_matches_image": same_named,
        "named_target_sha256": named_digest,
        "claim": "transported invariant subset under separately verified full A/B conjugacy",
    })


def verify_invariant_transport(serialized, full_action_record, *, named_target=None):
    """Replay an invariance transport against an independently verified full map.

    A digest is record identity, not a cryptographic attestation of authorship.
    The original full action and (if used) named target must be provided.
    """
    import json
    try:
        raw = json.loads(serialized)
        if (not isinstance(raw, dict) or raw.get("schema") != "transport_invariant.v1"
            or raw.get("generator") not in ("A", "B")
            or not isinstance(raw.get("source_carrier"), list)):
            raise ValueError("invalid invariant transport record")
        observed = transport_invariant(full_action_record,
            raw["source_carrier"], generator=raw["generator"],
            named_target=named_target)
        if observed.serialize() != _wire(raw):
            raise ValueError("transport witness failed exact mathematical replay")
        return observed
    except (TypeError, KeyError, IndexError, json.JSONDecodeError) as exc:
        raise ValueError("invalid transport record") from exc
