"""Stage a cross-scope question without rewriting the B-only source question."""
from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path

from research.cross_scope_handoff import ScopeHandoffEngine
from research.continuity_board_bridge import stage_checkpoint
from runtime.research_board import load_research_board


def stage_scope_handoff(handoff, *, question_id, question, source_board_root,
                        candidate_directory, frozen_date, witness_url=None,
                        witness_label="Full A/B correspondence witness", derived_from=(),
                        expected_parent_question_id=None,
                        expected_child_question_id=None):
    pair = ScopeHandoffEngine().verify(
        handoff, expected_parent_question_id=expected_parent_question_id,
        expected_child_question_id=expected_child_question_id)
    proposal = stage_checkpoint(
        pair.child_serialized, question_id=question_id, question=question,
        source_board_root=source_board_root, candidate_directory=candidate_directory,
        frozen_date=frozen_date, witness_url=witness_url,
        witness_label=witness_label, derived_from=derived_from,
        expected_question_id=pair.proof["child_question_id"])
    folder = Path(proposal.directory)
    index = json.loads((folder / "index.json").read_text(encoding="utf-8"))
    entry = next(i for i in index["checkpoints"] if i["id"] == proposal.checkpoint_id)
    source = folder / entry["file"]
    snap = json.loads(source.read_text(encoding="utf-8"))
    row = snap["questions"][-1]
    if row["id"] != question_id:
        raise AssertionError("unexpected board question identity")
    row["scope_handoff"] = {
        "relation": pair.proof["relation"],
        "parent_question_id": pair.proof["parent_question_id"],
        "parent_area": pair.proof["parent_area"],
        "parent_scope": pair.proof["parent_scope"],
        "parent_status": pair.statuses[0],
        "child_question_id": pair.proof["child_question_id"],
        "child_status": pair.statuses[1],
        "parent_frozen_digest": sha256(pair.parent_serialized.encode()).hexdigest(),
        "handoff_digest": sha256(handoff.encode()).hexdigest(),
        "generator_transition_checks": pair.proof.get("a_transition_checks", pair.proof.get("b_transition_checks")),
        "b_transition_checks": pair.proof.get("b_transition_checks"),
        "a_transition_checks": pair.proof.get("a_transition_checks"),
        "non_promotion": True,
    }
    source.write_text(json.dumps(snap, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    visible = load_research_board(root=folder)
    assert visible["questions"][-1] == row
    return proposal
