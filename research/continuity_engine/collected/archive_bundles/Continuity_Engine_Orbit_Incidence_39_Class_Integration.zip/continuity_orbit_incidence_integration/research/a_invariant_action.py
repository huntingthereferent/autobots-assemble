"""Native finite A-invariant WATCH; separate from established B-only research.

Not a symmetry discovery for the supplied WindowProcess grammar: A always
increments coordinate zero, independently of the coupling law.  The WATCH
records this limited fact, never an assertion of simultaneous A/B conjugacy.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from itertools import product

from work.arc_like_maze.window_two import WindowProcess
from research.simultaneous_action_correspondence import _law_data, _restore_law

RELATION = "A_ONLY_ON_DECLARED_INVARIANT_CARRIER"

def _wire(data):
    return json.dumps(data, separators=(",", ":"), sort_keys=True)

@dataclass(frozen=True)
class AActionResult:
    record: dict

    @property
    def status(self):
        return self.record["status"]

    def serialize(self):
        return _wire(self.record)

class AInvariantAction:
    """Exact, finite, replayable A-only periodic action witness."""

    @staticmethod
    def orbit_fiber(tail):
        """Three states with same remaining coordinates and all first coordinates."""
        if not isinstance(tail, (tuple, list)) or len(tail) < 2 or any(type(t) is not int or t not in (0, 1, 2) for t in tail):
            raise ValueError("tail requires >=2 finite-field coordinates")
        return tuple((u, *tail) for u in range(3))

    @staticmethod
    def carrier_for_dimension(dimension, *, max_states=10000):
        if type(dimension) is not int or dimension < 3 or 3**dimension > max_states:
            raise ValueError("invalid dimension or state budget")
        return tuple(product(range(3), repeat=dimension))

    def start(self, source, target, carrier, max_power):
        if not isinstance(source, WindowProcess) or not isinstance(target, WindowProcess):
            raise TypeError("actual WindowProcess laws required")
        if type(max_power) is not int or max_power < 1:
            raise ValueError("positive A continuation budget required")
        if not isinstance(carrier, (tuple, list)) or not carrier:
            raise ValueError("nonempty A carrier required")
        states = tuple(tuple(s) for s in carrier)
        dimension = len(states[0])
        if (dimension < 3 or len(set(states)) != len(states) or
            states != tuple(sorted(states)) or
            any(len(s) != dimension or any(type(t) is not int or t not in (0, 1, 2) for t in s) for s in states)):
            raise ValueError("carrier must be a canonical nonempty finite-field set")
        indexes = {s: i for i, s in enumerate(states)}
        edges = []
        for law in (source, target):
            permutation = []
            for state in states:
                target_state = law.step(state, "A")
                if target_state not in indexes:
                    raise ValueError("carrier is not invariant under both A actions")
                permutation.append(indexes[target_state])
            if len(set(permutation)) != len(states):
                raise ValueError("restricted A is not bijective")
            edges.append(tuple(permutation))
        # Every input law must be checked independently; do not rely on a
        # presumed equality of the couplings to infer anything about A/B.
        question = {"relation": RELATION, "operation": "A_SUCCESSIVE_COMPOSITION",
                    "source": _law_data(source), "target": _law_data(target),
                    "carrier": [list(s) for s in states]}
        question_id = sha256(_wire(question).encode()).hexdigest()
        original = list(range(len(states)))
        images = [original[:], original[:]]
        observations = []
        status = "UNKNOWN_A_BUDGET"
        bijection = []
        for power in range(1, max_power + 1):
            for j in range(2):
                images[j] = [edges[j][x] for x in images[j]]
            fixed = [[i for i,x in enumerate(img) if x == i] for img in images]
            observations.append({"power": power, "source_fixed": fixed[0],
                                 "target_fixed": fixed[1]})
            if len(fixed[0]) != len(fixed[1]):
                status = "DISTINGUISHED_A_ACTIONS"
                break
            if len(fixed[0]) == len(states):
                # Construct an explicit bijection in complete generality by
                # matching cycles; here the two A actions are pointwise equal.
                if edges[0] != edges[1]:
                    raise AssertionError("A actions differ despite WindowProcess A law")
                bijection = [[i, i] for i in range(len(states))]
                for i in range(len(states)):
                    if bijection[edges[0][i]][1] != edges[1][bijection[i][1]]:
                        raise AssertionError("A intertwiner failed")
                status = "A_ONLY_CONJUGACY_WITNESSED"
                break
        return AActionResult({"schema": 1, "question": question,
                              "question_id": question_id, "max_power": max_power,
                              "observations": observations,
                              "status": status, "A_bijection": bijection,
                              "simultaneous_A_B": "UNKNOWN_NOT_WATCHED"})

    def replay(self, serialized, *, expected_question_id=None):
        try:
            raw = json.loads(serialized)
            if (not isinstance(raw, dict) or set(raw) != {
                    "schema", "question", "question_id", "max_power", "observations",
                    "status", "A_bijection", "simultaneous_A_B"} or raw["schema"] != 1):
                raise ValueError("unsupported A witness schema")
            q = raw["question"]
            if (not isinstance(q, dict) or set(q) != {"relation", "operation", "source", "target", "carrier"}
                or q["relation"] != RELATION or q["operation"] != "A_SUCCESSIVE_COMPOSITION"
                or sha256(_wire(q).encode()).hexdigest() != raw["question_id"]
                or (expected_question_id is not None and raw["question_id"] != expected_question_id)):
                raise ValueError("A research question identity or scope changed")
            calculated = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
                                    tuple(tuple(s) for s in q["carrier"]), raw["max_power"])
            if calculated.serialize() != _wire(raw):
                raise ValueError("record failed native A witness replay")
            return calculated
        except (KeyError, TypeError, IndexError, OverflowError, json.JSONDecodeError) as exc:
            raise ValueError("invalid A witness") from exc

    def resume(self, serialized, max_power, *, expected_question_id=None):
        previous = self.replay(serialized, expected_question_id=expected_question_id)
        old = previous.record
        if type(max_power) is not int or max_power < old["max_power"]:
            raise ValueError("A continuation budget decreased")
        if old["status"] != "UNKNOWN_A_BUDGET":
            return previous
        q = old["question"]
        result = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
                            tuple(tuple(s) for s in q["carrier"]), max_power)
        if result.record["observations"][:len(old["observations"])] != old["observations"]:
            raise AssertionError("A observations changed during continuation")
        return result
