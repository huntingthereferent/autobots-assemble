"""Exact finite A/B orbit-intersection invariants; necessary, never sufficient.

Words apply left-to-right. Lowercase uses the original WindowProcess inverse.
All 243 roots are evaluated without sampling; the source law is not replaced.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from work.arc_like_maze.window_two import WindowProcess
from research.simultaneous_action_correspondence import _law_data, _restore_law

AREA = "finite_action/AB_orbit_incidence"
RELATION = "FINITE_AB_WORD_ORBIT_INCIDENCE"
UNKNOWN = "UNKNOWN_ORBIT_INCIDENCE_BUDGET"
DISTINGUISHED = "DISTINGUISHED_FULL_AB_BY_ORBIT_INCIDENCE"
# Four necessary invariants, selected on the 39 already established classes.
FEATURES = (
    {"kind": "closure", "words": ["A", "B", "A"]},
    {"kind": "closure", "words": ["BA", "ABBabbbb"]},
    {"kind": "closure", "words": ["ABab", "BABa"]},
    {"kind": "linked_intersection", "from": "BAB", "to": "Ab", "shift": "A"},
)

def _wire(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"))

def _perm(p):
    return len(set(p)) == len(p) and set(p) == set(range(len(p)))

def _word_map(action, inverse, word, count):
    positions = list(range(count))
    for char in word:
        edge = action[char] if char.isupper() else inverse[char.upper()]
        positions = [edge[x] for x in positions]
    return tuple(positions)

def _orbit_masks(p):
    n = len(p)
    output = [0] * n
    for root in range(n):
        if output[root]:
            continue
        seen = []; x = root
        while not output[x] and x not in seen:
            seen.append(x)
            x = p[x]
        if x != root:
            raise ValueError("word action did not form cycles")
        mask = sum(1 << k for k in seen)
        for k in seen:
            output[k] = mask
    return tuple(output)

def _closure(mask, orbits):
    result = 0
    while mask:
        low = mask & -mask
        mask ^= low
        result |= orbits[low.bit_length() - 1]
    return result

def _hist(values):
    return [[size, count] for size, count in sorted(Counter(values).items())]

def all_features(law, dimension=5, max_states=1000):
    """Evaluate the complete finite universe; feature prefix may be selected later."""
    if not isinstance(law, WindowProcess) or type(dimension) is not int or dimension < 3:
        raise ValueError("admitted finite-field law and dimension required")
    if type(max_states) is not int or max_states < 1 or 3**dimension > max_states:
        raise ValueError("explicit full-domain budget exceeded")
    states = tuple(product(range(3), repeat=dimension))
    lookup = {s: i for i, s in enumerate(states)}
    n = len(states)
    action = {g: tuple(lookup[law.step(s, g)] for s in states) for g in "AB"}
    inverse = {g: tuple(lookup[law.inverse(s, g)] for s in states) for g in "AB"}
    for g in "AB":
        if not _perm(action[g]) or not _perm(inverse[g]):
            raise ValueError("generator is not a permutation")
        if any(inverse[g][action[g][i]] != i for i in range(n)):
            raise ValueError("generator inverse check failed")
    words = sorted({w for f in FEATURES for w in
                    (f["words"] if f["kind"] == "closure" else
                     (f["from"], f["to"], f["shift"]))})
    perm = {w: _word_map(action, inverse, w, n) for w in words}
    orbit = {w: _orbit_masks(perm[w]) for w in words}
    results = []
    for j, f in enumerate(FEATURES):
        if f["kind"] == "closure":
            current = [1 << i for i in range(n)]
            for word in f["words"]:
                current = [_closure(mask, orbit[word]) for mask in current]
            values = [mask.bit_count() for mask in current]
        else:
            left = orbit[f["from"]]
            right = orbit[f["to"]]
            shift = perm[f["shift"]]
            values = [(left[x] & right[shift[x]]).bit_count() for x in range(n)]
        results.append({"feature": j + 1, "definition": f, "histogram": _hist(values)})
    return results

@dataclass(frozen=True)
class IncidenceResult:
    record: dict
    @property
    def status(self):
        return self.record["status"]
    def serialize(self):
        return _wire(self.record)

class ActionOrbitIncidence:
    def start(self, source, target, dimension=5, max_features=4, *, max_states=1000):
        if type(max_features) is not int or not 1 <= max_features <= len(FEATURES):
            raise ValueError("admitted feature budget 1..4 required")
        left = all_features(source, dimension, max_states)
        right = all_features(target, dimension, max_states)
        question = {"operation": "FINITE_AB_WORD_ORBIT_INCIDENCE", "relation": RELATION,
                    "source": _law_data(source), "target": _law_data(target),
                    "dimension": dimension, "max_states": max_states,
                    "feature_catalog": list(FEATURES)}
        qid = sha256(_wire(question).encode()).hexdigest()
        observations = []
        status = UNKNOWN
        obstruction = None
        for a, b in zip(left[:max_features], right[:max_features]):
            observations.append({"feature": a["feature"], "definition": a["definition"],
                                "source_histogram": a["histogram"],
                                "target_histogram": b["histogram"]})
            if a["histogram"] != b["histogram"]:
                status = DISTINGUISHED
                obstruction = a["feature"]
                break
        return IncidenceResult({"schema": 1, "question": question, "question_id": qid,
            "max_features": max_features, "observations": observations, "status": status,
            "first_obstruction_feature": obstruction,
            "positive_full_AB_conjugacy": "NOT_ESTABLISHED_BY_MATCHING_INVARIANTS"})

    def replay(self, serialized, *, expected_question_id=None):
        try:
            raw = json.loads(serialized)
            if not isinstance(raw, dict) or set(raw) != {
                "schema", "question", "question_id", "max_features", "observations",
                "status", "first_obstruction_feature", "positive_full_AB_conjugacy"}:
                raise ValueError("invalid orbit incidence record")
            q = raw["question"]
            if (raw["schema"] != 1 or type(q) is not dict or
                set(q) != {"operation", "relation", "source", "target", "dimension",
                           "max_states", "feature_catalog"} or
                q["operation"] != "FINITE_AB_WORD_ORBIT_INCIDENCE" or
                q["relation"] != RELATION or q["feature_catalog"] != list(FEATURES) or
                sha256(_wire(q).encode()).hexdigest() != raw["question_id"] or
                (expected_question_id is not None and raw["question_id"] != expected_question_id)):
                raise ValueError("orbit incidence question changed")
            rebuilt = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
                                 q["dimension"], raw["max_features"], max_states=q["max_states"])
            if rebuilt.serialize() != _wire(raw):
                raise ValueError("orbit incidence mathematical replay failed")
            return rebuilt
        except (KeyError, TypeError, OverflowError, json.JSONDecodeError) as exc:
            raise ValueError("invalid saved orbit incidence record") from exc

    def resume(self, serialized, max_features, *, expected_question_id=None):
        prior = self.replay(serialized, expected_question_id=expected_question_id)
        old = prior.record
        if type(max_features) is not int or max_features < old["max_features"]:
            raise ValueError("feature continuation budget decreased")
        if old["status"] != UNKNOWN:
            return prior
        q = old["question"]
        later = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
            q["dimension"], max_features, max_states=q["max_states"])
        if later.record["observations"][:len(old["observations"])] != old["observations"]:
            raise AssertionError("observation ancestry did not survive")
        return later
