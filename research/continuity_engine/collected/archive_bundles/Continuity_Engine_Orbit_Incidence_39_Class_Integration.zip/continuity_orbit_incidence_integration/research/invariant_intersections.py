"""Exact intersections of distinct A-invariant and B-invariant carriers.

An intersection need not be invariant under either generator. The orbit-closure
operators generally do not commute. Only a separately verified full A/B map
can transport both selected invariant carriers and their intersection.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from hashlib import sha256
import json
from work.arc_like_maze.window_two import WindowProcess
from research.alternating_saturation import _validated_action, _orbit_masks, _close_bitset
from research.simultaneous_action_correspondence import _law_data, _restore_law
from research.invariant_transport import transport_invariant
from research.continuity_engine import ContinuityEngine, FULL_AB


def _wire(x):
    return json.dumps(x, separators=(",", ":"), sort_keys=True)


def _canonical_carrier(raw, universe):
    try:
        carrier = tuple(tuple(x) for x in raw)
        if (not carrier or any(type(t) is not int or t not in (0, 1, 2)
                               for x in carrier for t in x)
            or carrier != tuple(sorted(set(carrier)))
            or any(x not in universe for x in carrier)):
            raise ValueError("carrier must be a canonical nonempty subset")
        return carrier
    except (TypeError, KeyError) as exc:
        raise ValueError("invalid carrier") from exc


def _members(mask, states):
    return [list(s) for i, s in enumerate(states) if mask & (1 << i)]


def _all_reachability_layers(initial_mask, orbits, order, state_count):
    """Stop on full domain or genuine no-growth after a complete A/B round."""
    mask = initial_mask
    steps = []
    for i in range(2 * state_count + 2):
        generator = order[i % 2]
        new = _close_bitset(mask, orbits[generator])
        steps.append({"generator": generator, "size": new.bit_count()})
        if new.bit_count() == state_count:
            return steps, new
        # If two successive generators cannot enlarge the set, it is joint
        # invariant and further alternation cannot enlarge it either.
        if i >= 1 and steps[-1]["size"] == steps[-2]["size"]:
            return steps, new
        mask = new
    raise AssertionError("finite saturation failed to stabilize under resource bound")


@dataclass(frozen=True)
class IntersectionWitness:
    record: dict
    def serialize(self):
        return _wire(self.record)


def analyze_intersection(source, a_carrier, b_carrier, dimension=5, *, max_states=1000):
    """Exact source-carrier intersection and noncommuting saturation checks."""
    if not isinstance(source, WindowProcess):
        raise TypeError("native WindowProcess required")
    if type(dimension) is not int or dimension < 3 or type(max_states) is not int or max_states < 1 or 3**dimension > max_states:
        raise ValueError("full finite universe exceeds declared state budget")
    states = tuple(product(range(3), repeat=dimension))
    lookup = {x: i for i, x in enumerate(states)}
    ca = _canonical_carrier(a_carrier, lookup)
    cb = _canonical_carrier(b_carrier, lookup)
    action = _validated_action(source, states, lookup)
    for g, carrier in (("A", ca), ("B", cb)):
        members = set(carrier)
        if any(states[action[g][lookup[s]]] not in members for s in carrier):
            raise ValueError(f"selected {g}-carrier is not invariant")
    intersection = set(ca) & set(cb)
    initial = sum(1 << lookup[s] for s in intersection)
    orbits = {g: _orbit_masks(action[g]) for g in "AB"}
    first_A = _close_bitset(initial, orbits["A"])
    first_B = _close_bitset(initial, orbits["B"])
    then_AB = _close_bitset(first_A, orbits["B"])
    then_BA = _close_bitset(first_B, orbits["A"])
    escape = {}
    for g in "AB":
        escape[g] = [[list(s), list(states[action[g][lookup[s]]])]
                     for s in sorted(intersection)
                     if states[action[g][lookup[s]]] not in intersection]
    layers_AB, limit_AB = _all_reachability_layers(initial, orbits, "AB", len(states))
    layers_BA, limit_BA = _all_reachability_layers(initial, orbits, "BA", len(states))
    question = {"source": _law_data(source), "dimension": dimension,
                "relation": "INTERSECTION_OF_SELECTED_A_AND_B_INVARIANT_CARRIERS",
                "a_carrier": [list(x) for x in ca],
                "b_carrier": [list(x) for x in cb], "max_states": max_states}
    record = {
        "schema": "invariant_intersections.v1",
        "question": question,
        "question_id": sha256(_wire(question).encode()).hexdigest(),
        "intersection": [list(x) for x in sorted(intersection)],
        "intersection_size": len(intersection),
        "intersection_invariant_under_A": not escape["A"],
        "intersection_invariant_under_B": not escape["B"],
        "escaping_A_edges": escape["A"], "escaping_B_edges": escape["B"],
        "closure_A_size": first_A.bit_count(),
        "closure_B_size": first_B.bit_count(),
        "closure_A_then_B": _members(then_AB, states),
        "closure_B_then_A": _members(then_BA, states),
        "two_closures_commute_on_intersection": then_AB == then_BA,
        "AB_alternation": layers_AB,
        "BA_alternation": layers_BA,
        "joint_reachable_AB": _members(limit_AB, states),
        "joint_reachable_BA": _members(limit_BA, states),
        "source_A_transition_checks": len(ca),
        "source_B_transition_checks": len(cb),
    }
    return IntersectionWitness(record)


def replay_intersection(serialized, *, expected_question_id=None):
    try:
        raw = json.loads(serialized)
        if (type(raw) is not dict or raw.get("schema") != "invariant_intersections.v1"
            or not isinstance(raw.get("question"), dict)):
            raise ValueError("invalid intersection record")
        q = raw["question"]
        if (set(q) != {"source", "dimension", "relation", "a_carrier", "b_carrier", "max_states"}
            or q["relation"] != "INTERSECTION_OF_SELECTED_A_AND_B_INVARIANT_CARRIERS"
            or sha256(_wire(q).encode()).hexdigest() != raw["question_id"]
            or (expected_question_id is not None and expected_question_id != raw["question_id"])):
            raise ValueError("changed intersection scope or question identity")
        rebuilt = analyze_intersection(_restore_law(q["source"]),
            q["a_carrier"], q["b_carrier"], q["dimension"], max_states=q["max_states"])
        if rebuilt.serialize() != _wire(raw):
            raise ValueError("intersection mathematical replay mismatch")
        return rebuilt
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid intersection witness") from exc


@dataclass(frozen=True)
class IntersectionTransportWitness:
    record: dict
    def serialize(self):
        return _wire(self.record)


def transport_intersection(full_action_record, a_carrier, b_carrier, *,
                           named_target_a=None, named_target_b=None):
    """H(C_A ∩ C_B) = H(C_A) ∩ H(C_B), with independently verified full H."""
    full = ContinuityEngine().verify(full_action_record)
    if full.area != FULL_AB or full.status != "CONJUGATE_FULL_AB":
        raise ValueError("full A/B conjugacy witness is required for transport")
    observed_A = transport_invariant(full_action_record, a_carrier,
        generator="A", named_target=named_target_a)
    observed_B = transport_invariant(full_action_record, b_carrier,
        generator="B", named_target=named_target_b)
    q = full.research_question
    states = tuple(product(range(3), repeat=q["dimension"]))
    lookup = {x: i for i, x in enumerate(states)}
    H = {states[i]: states[j] for i, j in full.witness}
    sa = set(map(tuple, observed_A.proof["source_carrier"]))
    sb = set(map(tuple, observed_B.proof["source_carrier"]))
    meet = sa & sb
    ha = set(map(tuple, observed_A.proof["transported_carrier"]))
    hb = set(map(tuple, observed_B.proof["transported_carrier"]))
    exact_image = {H[x] for x in meet}
    intersection_images = ha & hb
    if exact_image != intersection_images:
        raise AssertionError("verified bijection failed set intersection transport")
    named_match = None
    if named_target_a is not None and named_target_b is not None:
        named_a = set(map(tuple, named_target_a))
        named_b = set(map(tuple, named_target_b))
        named_match = named_a & named_b == exact_image
    record = {
        "schema": "invariant_intersection_transport.v1",
        "full_question_id": full.question_id,
        "full_last_snapshot_sha256": full.snapshots[-1]["sha256"],
        "a_parent_transport_sha256": sha256(observed_A.serialize().encode()).hexdigest(),
        "b_parent_transport_sha256": sha256(observed_B.serialize().encode()).hexdigest(),
        "source_a_carrier": observed_A.proof["source_carrier"],
        "source_b_carrier": observed_B.proof["source_carrier"],
        "source_intersection": [list(x) for x in sorted(meet)],
        "transported_a_carrier": observed_A.proof["transported_carrier"],
        "transported_b_carrier": observed_B.proof["transported_carrier"],
        "actual_intersection_image": [list(x) for x in sorted(exact_image)],
        "transported_carrier_intersection": [list(x) for x in sorted(intersection_images)],
        "intersection_transport_verified": True,
        "named_target_intersection_matches": named_match,
        "named_target_a_matches": observed_A.proof["named_target_matches_image"],
        "named_target_b_matches": observed_B.proof["named_target_matches_image"],
        "note": "Chosen full conjugacy only; no claim about all possible correspondences",
    }
    return IntersectionTransportWitness(record)


def replay_intersection_transport(serialized, full_action_record, *,
                                  named_target_a=None, named_target_b=None):
    try:
        raw = json.loads(serialized)
        if type(raw) is not dict or raw.get("schema") != "invariant_intersection_transport.v1":
            raise ValueError("invalid transported intersection record")
        rebuilt = transport_intersection(full_action_record,
            raw["source_a_carrier"], raw["source_b_carrier"],
            named_target_a=named_target_a, named_target_b=named_target_b)
        if rebuilt.serialize() != _wire(raw):
            raise ValueError("transported intersection failed replay")
        return rebuilt
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid transported intersection witness") from exc
