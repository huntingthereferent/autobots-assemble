"""Exact finite orbit-closure profiles for two labeled permutation generators.

This is a *necessary* invariant of full A/B conjugacy, not a sufficient
criterion. A different multiset proves nonconjugacy; agreement stays UNKNOWN.
The underlying A/B generators are taken from WindowProcess.step/inverse.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from work.arc_like_maze.window_two import WindowProcess
from research.simultaneous_action_correspondence import _law_data, _restore_law

RELATION = "FINITE_AB_ALTERNATING_ORBIT_SATURATION"
AREA = "finite_action/AB_saturation"
DISTINGUISHED = "DISTINGUISHED_FULL_AB_BY_SATURATION"
UNKNOWN = "UNKNOWN_SATURATION_BUDGET"


def _wire(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"))


def _validated_action(law, states, lookup):
    n = len(states)
    edges = {}
    for g in "AB":
        forward = tuple(lookup[law.step(state, g)] for state in states)
        if len(set(forward)) != n:
            raise ValueError("declared generator is not a permutation")
        if any(states[next_index] != law.inverse(states[forward[next_index]], g)
               for next_index in range(n)):
            raise ValueError("generator inverse failed independent check")
        edges[g] = forward
    return edges


def _orbit_masks(permutation):
    n = len(permutation)
    visited = set()
    masks = [0] * n
    for start in range(n):
        if start in visited:
            continue
        members = []
        cursor = start
        while cursor not in visited:
            visited.add(cursor)
            members.append(cursor)
            cursor = permutation[cursor]
        if cursor != start:
            raise ValueError("generator is not a disjoint cycle permutation")
        mask = sum(1 << k for k in members)
        for index in members:
            masks[index] = mask
    return tuple(masks)


def _close_bitset(mask, orbits):
    closed = 0
    while mask:
        lowest = mask & -mask
        mask ^= lowest
        closed |= orbits[lowest.bit_length() - 1]
    return closed


def _histogram(lengths):
    return [[length, frequency] for length, frequency in sorted(Counter(lengths).items())]


def compute_profiles(law, dimension, sequence="AB", max_steps=3, *, max_states=1000):
    """Every starting point, every closure layer, with no sampling/truncation."""
    if not isinstance(law, WindowProcess):
        raise TypeError("actual WindowProcess law required")
    if type(dimension) is not int or dimension < 3 or type(max_states) is not int or max_states < 1:
        raise ValueError("invalid dimension or state budget")
    if 3 ** dimension > max_states:
        raise ValueError("explicit full-state budget exceeded")
    if sequence not in ("AB", "BA"):
        raise ValueError("only explicitly ordered alternating A/B closures admitted")
    if type(max_steps) is not int or max_steps < 1 or max_steps > 2 * 3**dimension:
        raise ValueError("invalid or excessive closure budget")
    states = tuple(product(range(3), repeat=dimension))
    indexes = {x: i for i, x in enumerate(states)}
    edges = _validated_action(law, states, indexes)
    orbit_masks = {g: _orbit_masks(edges[g]) for g in "AB"}
    masks = [1 << i for i in range(len(states))]
    observations = []
    for i in range(max_steps):
        g = sequence[i % 2]
        masks = [_close_bitset(mask, orbit_masks[g]) for mask in masks]
        sizes = [x.bit_count() for x in masks]
        observations.append({"step": i + 1, "generator": g,
                             "counts_by_origin": sizes,
                             "histogram": _histogram(sizes)})
    return observations


@dataclass(frozen=True)
class SaturationResult:
    record: dict
    @property
    def status(self):
        return self.record["status"]
    def serialize(self):
        return _wire(self.record)


class AlternatingSaturation:
    def start(self, source, target, dimension, max_steps, *, sequence="AB", max_states=1000):
        left = compute_profiles(source, dimension, sequence, max_steps, max_states=max_states)
        right = compute_profiles(target, dimension, sequence, max_steps, max_states=max_states)
        question = {"operation": "FINITE_ALTERNATING_ORBIT_CLOSURE",
                    "relation": RELATION, "source": _law_data(source),
                    "target": _law_data(target), "dimension": dimension,
                    "sequence": sequence, "max_states": max_states}
        qid = sha256(_wire(question).encode()).hexdigest()
        observations = []
        status = UNKNOWN
        first_obstruction = None
        for l, r in zip(left, right):
            observations.append({"step": l["step"], "generator": l["generator"],
                "source_counts_by_origin": l["counts_by_origin"],
                "target_counts_by_origin": r["counts_by_origin"],
                "source_histogram": l["histogram"],
                "target_histogram": r["histogram"]})
            if l["histogram"] != r["histogram"]:
                status = DISTINGUISHED
                ldict, rdict = dict(l["histogram"]), dict(r["histogram"])
                first_obstruction = {"step": l["step"], "sequence_prefix":
                    "".join(sequence[i % 2] for i in range(l["step"])),
                    "source_exclusive_lengths": [[k, v] for k, v in sorted(ldict.items()) if k not in rdict],
                    "target_exclusive_lengths": [[k, v] for k, v in sorted(rdict.items()) if k not in ldict]}
                break
        return SaturationResult({"schema": 1, "question": question, "question_id": qid,
                                  "max_steps": max_steps, "observations": observations,
                                  "status": status, "first_obstruction": first_obstruction,
                                  "full_AB_conjugacy": "NOT_ESTABLISHED_BY_MATCHING_PROFILES"})

    def replay(self, serialized, *, expected_question_id=None):
        try:
            record = json.loads(serialized)
            if (type(record) is not dict or set(record) != {
                "schema", "question", "question_id", "max_steps", "observations",
                "status", "first_obstruction", "full_AB_conjugacy"} or
                type(record["schema"]) is not int or record["schema"] != 1):
                raise ValueError("invalid saturation schema")
            q = record["question"]
            if (type(q) is not dict or set(q) != {
                "operation", "relation", "source", "target", "dimension", "sequence", "max_states"}
                or q["relation"] != RELATION or q["operation"] != "FINITE_ALTERNATING_ORBIT_CLOSURE" or
                sha256(_wire(q).encode()).hexdigest() != record["question_id"] or
                (expected_question_id is not None and expected_question_id != record["question_id"])):
                raise ValueError("saturation mathematical scope or identity changed")
            rebuilt = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
                                 q["dimension"], record["max_steps"],
                                 sequence=q["sequence"], max_states=q["max_states"])
            if rebuilt.serialize() != _wire(record):
                raise ValueError("saturation witness failed full mathematical replay")
            return rebuilt
        except (KeyError, TypeError, OverflowError, RecursionError, json.JSONDecodeError) as exc:
            raise ValueError("invalid saved saturation record") from exc

    def resume(self, serialized, max_steps, *, expected_question_id=None):
        earlier = self.replay(serialized, expected_question_id=expected_question_id)
        old = earlier.record
        if type(max_steps) is not int or max_steps < old["max_steps"]:
            raise ValueError("continuation budget decreased")
        if old["status"] != UNKNOWN:
            return earlier
        q = old["question"]
        later = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
            q["dimension"], max_steps, sequence=q["sequence"], max_states=q["max_states"])
        if later.record["observations"][:len(old["observations"])] != old["observations"]:
            raise AssertionError("observed saturation ancestry changed")
        return later
