"""Exact orbit-incidence regression, separation and preserved research contracts."""
from __future__ import annotations
from itertools import product
from pathlib import Path
from tempfile import TemporaryDirectory
from collections import Counter
import json
import unittest
from research.action_orbit_incidence import (
    ActionOrbitIncidence, all_features, FEATURES, UNKNOWN, DISTINGUISHED)
from research.continuity_engine import ContinuityEngine
from research.continuity_board_bridge import stage_checkpoint
from runtime.research_board import load_research_board
from work.arc_like_maze.window_two import WindowProcess

Z=(0,)*9
Q0=tuple(int(v==2) for u,v in product(range(3),repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(range(3),repeat=2))
def table(a,b): return tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))
def process(a,b): return WindowProcess(1,(Q0,Q1,table(a,b)),(Z,))
def rotated(p):
    a,b=p; ao=[0]*3;bo=[0]*3
    for z in range(3):
        z1=(z+1)%3
        ao[z1]=(a[z]-(z==2)*b[z])%3
        bo[z1]=b[z]
    return tuple(ao),tuple(bo)

SOURCE=process((0,0,0),(1,1,2))  # class 6
TARGET=process((0,0,0),(1,2,2))  # class 8: first three features equal
HARD=process((0,0,0),(1,0,1))
HARD_TARGET=process((0,0,1),(0,2,2))
POS=process(*rotated(((0,0,0),(1,1,2))))
BOARD=Path(__file__).resolve().parents[2]/'research'/'questions'

class OrbitIncidenceTests(unittest.TestCase):
    def setUp(self):
        self.engine=ContinuityEngine()
        self.kernel=ActionOrbitIncidence()
    def test_hard_class_pair_first_three_unknown(self):
        record=self.engine.start_orbit_incidence(SOURCE,TARGET,5,3,max_states=243)
        self.assertEqual(record.status, UNKNOWN)
        self.assertEqual(len(record.snapshots),1)
        self.assertEqual(self.engine.verify(record.serialize()).serialize(),record.serialize())
    def test_fourth_feature_closes_hard_class_pair(self):
        earlier=self.engine.start_orbit_incidence(SOURCE,TARGET,5,3,max_states=243)
        later=self.engine.resume(earlier.serialize(),4)
        self.assertEqual(later.status,DISTINGUISHED)
        self.assertEqual(len(later.snapshots),2)
        reading=json.loads(later.snapshots[-1]['payload'])
        self.assertEqual(reading['first_obstruction_feature'],4)
        left=dict(reading['observations'][-1]['source_histogram'])
        right=dict(reading['observations'][-1]['target_histogram'])
        self.assertNotEqual(left,right)
        self.assertEqual(sum(left.values()),243)
        self.assertEqual(sum(right.values()),243)
        self.assertEqual(self.engine.verify(later.serialize()).serialize(),later.serialize())
    def test_transported_positive_never_promoted_from_matching_fingerprints(self):
        result=self.engine.start_orbit_incidence(SOURCE,POS,5,4,max_states=243)
        self.assertEqual(result.status,UNKNOWN)
        self.assertEqual(result.snapshots[-1]['payload'],self.kernel.replay(result.snapshots[-1]['payload']).serialize())
        self.assertEqual(self.engine.resume(result.serialize(),4).serialize(),result.serialize())
        full=self.engine.start_full_action(SOURCE,POS,5,244,max_states=243)
        self.assertEqual(full.status,'CONJUGATE_FULL_AB')
    def test_hard_original_pair_distinguished(self):
        result=self.kernel.start(HARD,HARD_TARGET,5,4,max_states=243)
        self.assertEqual(result.status,DISTINGUISHED)
        self.assertEqual(result.record['first_obstruction_feature'],1)
    def test_no_assumed_compatibility_between_AB_and_B_only(self):
        result=self.engine.start_orbit_incidence(SOURCE,TARGET,5,4,max_states=243)
        self.assertEqual(result.area,'finite_action/AB_orbit_incidence')
        with self.assertRaises(ValueError):
            _=result.witness
        self.assertEqual(result.research_question['relation'],'FINITE_AB_WORD_ORBIT_INCIDENCE')
        self.assertIn('finite_action/AB_orbit_incidence',self.engine.supported_areas())
    def test_replay_refuses_mutation_of_invariant_histogram(self):
        result=self.kernel.start(SOURCE,TARGET,5,4,max_states=243)
        raw=json.loads(result.serialize())
        raw['observations'][-1]['source_histogram'][0][1]+=1
        with self.assertRaises(ValueError):self.kernel.replay(json.dumps(raw))
    def test_continuity_replay_refuses_nested_tamper_even_if_hash_updated(self):
        result=self.engine.start_orbit_incidence(SOURCE,TARGET,5,4,max_states=243)
        raw=json.loads(result.serialize())
        obj=json.loads(raw['snapshots'][0]['payload'])
        obj['status']='UNKNOWN_ORBIT_INCIDENCE_BUDGET'
        raw['snapshots'][0]['payload']=json.dumps(obj,sort_keys=True,separators=(',',':'))
        from hashlib import sha256
        raw['snapshots'][0]['sha256']=sha256(raw['snapshots'][0]['payload'].encode()).hexdigest()
        with self.assertRaises(ValueError):self.engine.verify(json.dumps(raw))
    def test_anchored_question_cannot_change(self):
        result=self.engine.start_orbit_incidence(SOURCE,TARGET,5,3,max_states=243)
        with self.assertRaises(ValueError):self.engine.verify(result.serialize(),expected_question_id='wrong')
    def test_budget_cannot_regress_or_escape_catalog(self):
        result=self.engine.start_orbit_incidence(SOURCE,TARGET,5,3,max_states=243)
        with self.assertRaises(ValueError):self.engine.resume(result.serialize(),2)
        with self.assertRaises(ValueError):self.kernel.start(SOURCE,TARGET,5,5,max_states=243)
    def test_dimension_state_budget_exceeded(self):
        with self.assertRaises(ValueError):self.kernel.start(SOURCE,TARGET,5,2,max_states=100)
    def test_board_freeze_unchanged_and_negative_requires_witness(self):
        old=(BOARD/'freeze-2026-10-09.json').read_bytes()
        handoff=self.engine.start_orbit_incidence(SOURCE,TARGET,5,4,max_states=243)
        with TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'candidate'
            cp=stage_checkpoint(handoff.serialize(),question_id='CE-ORB-01',
                question='Are these two full A/B actions conjugate?',
                source_board_root=BOARD,candidate_directory=candidate,
                frozen_date='2026-10-09',expected_question_id=handoff.question_id)
            self.assertEqual(cp.board_status,'REVIEW')
            current=load_research_board(root=candidate)
            self.assertEqual(current['questions'][-1]['engine_status'],DISTINGUISHED)
        self.assertEqual(old,(BOARD/'freeze-2026-10-09.json').read_bytes())
    def test_board_unknown_when_invariants_agree(self):
        handoff=self.engine.start_orbit_incidence(SOURCE,POS,5,4,max_states=243)
        with TemporaryDirectory() as tmp:
            proposal=stage_checkpoint(handoff.serialize(),question_id='CE-ORB-02',
                question='Is there a simultaneous A/B correspondence?',
                source_board_root=BOARD,candidate_directory=Path(tmp)/'candidate',
                frozen_date='2026-10-09',expected_question_id=handoff.question_id)
            self.assertEqual(proposal.board_status,'UNKNOWN')
    def test_cyclic_B_contract_unchanged(self):
        self.assertEqual(FEATURES[0]['words'],['A','B','A'])
        self.assertEqual(len(FEATURES),4)
        self.assertIn('cyclic_action/B',self.engine.supported_areas())
    def test_exact_hard_pair_linked_histogram(self):
        f1=all_features(SOURCE,5,243)[3]['histogram']
        f2=all_features(TARGET,5,243)[3]['histogram']
        self.assertNotEqual(f1,f2)
        self.assertEqual(sum(x[1] for x in f1),243)
        self.assertEqual(sum(x[1] for x in f2),243)

if __name__=='__main__':unittest.main()
