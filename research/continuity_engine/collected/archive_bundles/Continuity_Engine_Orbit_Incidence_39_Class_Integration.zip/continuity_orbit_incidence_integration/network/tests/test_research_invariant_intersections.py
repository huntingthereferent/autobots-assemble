"""Exact A/B invariant intersection + orbit closure + transport regression."""
from __future__ import annotations
from itertools import product
import json
import unittest
import tempfile
from pathlib import Path
from research.continuity_engine import ContinuityEngine, _wire, _hash
from research.continuity_board_bridge import stage_checkpoint
from runtime.research_board import load_research_board
from research.alternating_saturation import compute_profiles, UNKNOWN, DISTINGUISHED
from research.invariant_intersections import (
    analyze_intersection, replay_intersection, transport_intersection,
    replay_intersection_transport,
)
from research.a_invariant_action import AInvariantAction
from work.arc_like_maze.window_two import WindowProcess

Z = (0,) * 9
Q0 = tuple(int(v == 2) for u, v in product(range(3), repeat=2))
Q1 = tuple(int(v == 2 and z == 2) for v, z in product(range(3), repeat=2))

def table(a, b):
    return tuple((a[z] + b[z] * y) % 3 for z, y in product(range(3), repeat=2))

def rotated(q):
    t = [0] * 9
    for z, y in product(range(3), repeat=2):
        t[3*((z+1)%3)+(y+int(z==2))%3] = q[3*z+y]
    return tuple(t)

def process(q):
    return WindowProcess(1, (Q0, Q1, q), (Z,))

SRC = process(table((0, 0, 0), (1, 0, 1)))
NEG = process(table((0, 0, 1), (0, 2, 2)))
POS = process(rotated(table((0, 0, 0), (1, 0, 1))))
A_CARRIER = AInvariantAction.orbit_fiber((0, 0, 0, 0))
B_CARRIER = tuple((0, *tail) for tail in product(range(3), repeat=4))
B_TWO = tuple((2, *tail) for tail in product(range(3), repeat=4))
STATES = tuple(product(range(3), repeat=5))

class InvariantIntersectionTests(unittest.TestCase):
    def setUp(self):
        self.engine = ContinuityEngine()

    def test_meet_is_singleton_but_not_invariant_under_either(self):
        result = analyze_intersection(SRC, A_CARRIER, B_CARRIER).record
        self.assertEqual(result["intersection"], [[0, 0, 0, 0, 0]])
        self.assertEqual(result["intersection_size"], 1)
        self.assertFalse(result["intersection_invariant_under_A"])
        self.assertFalse(result["intersection_invariant_under_B"])
        self.assertEqual(len(result["escaping_A_edges"]), 1)
        self.assertEqual(len(result["escaping_B_edges"]), 1)

    def test_two_closure_operators_do_not_commute(self):
        result = analyze_intersection(SRC, A_CARRIER, B_CARRIER).record
        self.assertEqual(result["closure_A_size"], 3)
        self.assertEqual(result["closure_B_size"], 27)
        self.assertEqual(len(result["closure_A_then_B"]), 55)
        self.assertEqual(len(result["closure_B_then_A"]), 81)
        self.assertFalse(result["two_closures_commute_on_intersection"])

    def test_exact_joint_orbits_are_full_and_recorded(self):
        result = analyze_intersection(SRC, A_CARRIER, B_CARRIER).record
        self.assertEqual([d["size"] for d in result["AB_alternation"]], [3, 55, 105, 223, 243])
        self.assertEqual([d["size"] for d in result["BA_alternation"]], [27, 81, 169, 243])
        self.assertEqual(result["joint_reachable_AB"], [list(s) for s in STATES])
        self.assertEqual(result["joint_reachable_BA"], [list(s) for s in STATES])
        self.assertEqual((result["source_A_transition_checks"], result["source_B_transition_checks"]), (3, 81))

    def test_B_fixed_meet_is_not_joint_invariant(self):
        a = AInvariantAction.orbit_fiber((0, 0, 0, 0))
        result = analyze_intersection(SRC, a, B_TWO).record
        self.assertEqual(result["intersection"], [[2, 0, 0, 0, 0]])
        self.assertTrue(result["intersection_invariant_under_B"])
        self.assertFalse(result["intersection_invariant_under_A"])
        self.assertEqual(result["closure_B_size"], 1)
        self.assertEqual([d["size"] for d in result["BA_alternation"]], [1, 3, 55, 105, 223, 243])

    def test_intersection_replay_is_exact(self):
        result = analyze_intersection(SRC, A_CARRIER, B_CARRIER)
        self.assertEqual(replay_intersection(result.serialize()).serialize(), result.serialize())
        self.assertEqual(replay_intersection(result.serialize(), expected_question_id=result.record["question_id"]).serialize(), result.serialize())
        raw = json.loads(result.serialize())
        raw["intersection_invariant_under_B"] = True
        with self.assertRaises(ValueError):
            replay_intersection(json.dumps(raw))
        with self.assertRaises(ValueError):
            replay_intersection(result.serialize(), expected_question_id="wrong")

    def test_bad_carriers_and_bounds_rejected(self):
        with self.assertRaisesRegex(ValueError, "not invariant"):
            analyze_intersection(SRC, B_CARRIER, A_CARRIER)
        with self.assertRaisesRegex(ValueError, "canonical"):
            analyze_intersection(SRC, A_CARRIER[::-1], B_CARRIER)
        with self.assertRaises(ValueError):
            analyze_intersection(SRC, A_CARRIER, B_CARRIER, max_states=100)

    def test_full_conjugacy_transports_intersection_exactly(self):
        full = self.engine.start_full_action(SRC, POS, 5, 244, max_states=243)
        self.assertEqual(full.status, "CONJUGATE_FULL_AB")
        transported = transport_intersection(full.serialize(), A_CARRIER, B_CARRIER,
                                             named_target_a=A_CARRIER, named_target_b=B_CARRIER)
        proof = transported.record
        self.assertEqual(proof["source_intersection"], [[0, 0, 0, 0, 0]])
        self.assertEqual(proof["actual_intersection_image"], [[0, 0, 1, 0, 0]])
        self.assertEqual(proof["transported_carrier_intersection"], [[0, 0, 1, 0, 0]])
        self.assertTrue(proof["intersection_transport_verified"])
        self.assertFalse(proof["named_target_a_matches"])
        self.assertTrue(proof["named_target_b_matches"])
        self.assertFalse(proof["named_target_intersection_matches"])
        self.assertEqual(replay_intersection_transport(transported.serialize(), full.serialize(),
            named_target_a=A_CARRIER, named_target_b=B_CARRIER).serialize(), transported.serialize())

    def test_transport_no_full_proof_fails(self):
        neg = self.engine.start_full_action(SRC, NEG, 5, 244, max_states=243)
        with self.assertRaises(ValueError):
            transport_intersection(neg.serialize(), A_CARRIER, B_CARRIER)
        unknown = self.engine.start_full_action(SRC, POS, 5, 0, max_states=243)
        with self.assertRaises(ValueError):
            transport_intersection(unknown.serialize(), A_CARRIER, B_CARRIER)

    def test_transport_replay_blocks_mutation_or_parent_replacement(self):
        full = self.engine.start_full_action(SRC, POS, 5, 244, max_states=243)
        transport = transport_intersection(full.serialize(), A_CARRIER, B_CARRIER,
            named_target_a=A_CARRIER, named_target_b=B_CARRIER)
        raw = json.loads(transport.serialize())
        raw["actual_intersection_image"] = [[0, 0, 0, 0, 0]]
        with self.assertRaises(ValueError):
            replay_intersection_transport(json.dumps(raw), full.serialize(),
                                          named_target_a=A_CARRIER, named_target_b=B_CARRIER)
        with self.assertRaises(ValueError):
            replay_intersection_transport(transport.serialize(), full.serialize())

    def test_ABA_early_observations_match_but_third_separates(self):
        early = self.engine.start_saturation(SRC, NEG, 5, 2, sequence="AB", max_states=243)
        self.assertEqual(early.status, UNKNOWN)
        self.assertEqual(len(early.snapshots), 1)
        later = self.engine.resume(early.serialize(), 3)
        self.assertEqual(later.status, DISTINGUISHED)
        self.assertEqual(len(later.snapshots), 2)
        first = json.loads(later.snapshots[-1]["payload"])
        self.assertEqual(first["first_obstruction"]["sequence_prefix"], "ABA")
        self.assertEqual(first["first_obstruction"]["step"], 3)
        left = dict(first["observations"][-1]["source_histogram"])
        right = dict(first["observations"][-1]["target_histogram"])
        self.assertEqual(left, {105:90,156:72,120:72,129:9})
        self.assertEqual(right, {105:90,156:72,114:54,123:27})
        self.assertEqual(self.engine.verify(later.serialize()).serialize(), later.serialize())
        with self.assertRaisesRegex(ValueError, "not a conjugacy bijection"):
            _ = later.witness

    def test_BAB_third_step_also_separates(self):
        proof = self.engine.start_saturation(SRC, NEG, 5, 3, sequence="BA", max_states=243)
        self.assertEqual(proof.status, DISTINGUISHED)
        last = json.loads(proof.snapshots[-1]["payload"])["observations"][-1]
        self.assertEqual(dict(last["source_histogram"]),{55:30,165:24,169:162,171:27})
        self.assertEqual(dict(last["target_histogram"]),{55:30,117:27,160:162,165:24})

    def test_positive_pair_profile_agrees_but_not_promoted(self):
        sat = self.engine.start_saturation(SRC, POS, 5, 3, sequence="AB", max_states=243)
        self.assertEqual(sat.status, UNKNOWN)
        with self.assertRaisesRegex(ValueError, "not a conjugacy bijection"):
            _ = sat.witness
        self.assertEqual(json.loads(sat.snapshots[-1]["payload"])["full_AB_conjugacy"],
                         "NOT_ESTABLISHED_BY_MATCHING_PROFILES")
        full = self.engine.start_full_action(SRC, POS, 5, 244, max_states=243)
        self.assertEqual(full.status, "CONJUGATE_FULL_AB")

    def test_saturation_replay_rejects_counterfeit_with_matching_hash(self):
        sat = self.engine.start_saturation(SRC, NEG, 5, 3, sequence="AB", max_states=243)
        raw = json.loads(sat.serialize())
        payload = json.loads(raw["snapshots"][0]["payload"])
        payload["observations"][-1]["source_histogram"] = [[243,243]]
        raw["snapshots"][0]["payload"] = _wire(payload)
        raw["snapshots"][0]["sha256"] = _hash(raw["snapshots"][0]["payload"])
        with self.assertRaises(ValueError):
            self.engine.verify(_wire(raw))

    def test_saturation_wrong_scope_and_budget_rejected(self):
        sat = self.engine.start_saturation(SRC, NEG, 5, 2, sequence="AB", max_states=243)
        raw = json.loads(sat.serialize())
        raw["scope"] = "SIMULTANEOUS_AB_ON_FULL_TRANSITIVE_CARRIER"
        with self.assertRaises(ValueError):
            self.engine.verify(_wire(raw))
        with self.assertRaises(ValueError):
            self.engine.resume(sat.serialize(), 1)
        with self.assertRaises(ValueError):
            self.engine.start_saturation(SRC, NEG, 5, 3, sequence="AB", max_states=200)

    def test_terminal_obstruction_cannot_be_erased_by_continuation(self):
        result = self.engine.start_saturation(SRC, NEG, 5, 3, sequence="AB", max_states=243)
        unchanged = self.engine.resume(result.serialize(), 5)
        self.assertEqual(unchanged.serialize(),result.serialize())

    def test_only_distinct_proven_claims_are_transferred(self):
        a = self.engine.start_a_invariant(SRC, NEG, A_CARRIER, 3)
        b = self.engine.start_cyclic(SRC, NEG, B_CARRIER, 27)
        sat = self.engine.start_saturation(SRC, NEG, 5, 3, max_states=243)
        self.assertEqual(a.status, "A_ONLY_CONJUGACY_WITNESSED")
        self.assertEqual(b.status, "B_ONLY_CONJUGACY_WITNESSED")
        self.assertEqual(sat.status, DISTINGUISHED)
        self.assertEqual(len({a.question_id,b.question_id,sat.question_id}),3)

    def test_board_stages_saturation_obstruction_for_review(self):
        proof = self.engine.start_saturation(SRC, NEG, 5, 3, sequence="AB", max_states=243)
        root = Path(__file__).resolve().parents[2]/"research"/"questions"
        old = (root/"freeze-2026-10-09.json").read_bytes()
        with tempfile.TemporaryDirectory() as tmp:
            proposed = stage_checkpoint(proof.serialize(),question_id="SAT-NEW-001",
                question="Are these complete A/B actions conjugate?",
                source_board_root=root,candidate_directory=Path(tmp)/"board",
                frozen_date="2026-10-09")
            self.assertEqual(proposed.board_status,"REVIEW")
            row = load_research_board(root=proposed.directory)["questions"][-1]
            self.assertEqual(row["status"],"REVIEW")
            self.assertIn("necessary invariant only",row["scope"])
            self.assertEqual(row["engine_status"], DISTINGUISHED)
        self.assertEqual(old,(root/"freeze-2026-10-09.json").read_bytes())

    def test_board_can_stage_scoped_answer_with_explicit_locator(self):
        proof = self.engine.start_saturation(SRC, NEG, 5, 3, max_states=243)
        root = Path(__file__).resolve().parents[2]/"research"/"questions"
        with tempfile.TemporaryDirectory() as tmp:
            proposed = stage_checkpoint(proof.serialize(),question_id="SAT-NEW-002",
                question="Are these complete A/B actions conjugate?",
                source_board_root=root,candidate_directory=Path(tmp)/"board",
                frozen_date="2026-10-09",witness_url="https://example.org/test-only-witness")
            row = load_research_board(root=proposed.directory)["questions"][-1]
            self.assertEqual(row["status"],"ANSWERED")
            self.assertIn("saturation histograms",row["answer"])

    def test_board_never_promotes_matching_saturation_profiles(self):
        proof = self.engine.start_saturation(SRC, POS, 5, 3, max_states=243)
        root = Path(__file__).resolve().parents[2]/"research"/"questions"
        with tempfile.TemporaryDirectory() as tmp:
            proposed = stage_checkpoint(proof.serialize(),question_id="SAT-NEW-003",
                question="Are these complete A/B actions conjugate?",
                source_board_root=root,candidate_directory=Path(tmp)/"board",
                frozen_date="2026-10-09",witness_url="https://example.org/test-only-witness")
            row = load_research_board(root=proposed.directory)["questions"][-1]
            self.assertEqual((row["status"],row["answer"]),("UNKNOWN",""))

if __name__ == "__main__":
    unittest.main()
