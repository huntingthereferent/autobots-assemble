"""A-only research and A->full handoff with transport; B evidence untouched."""
import json
import tempfile
import unittest
from pathlib import Path
from itertools import product

from research.continuity_engine import ContinuityEngine, _wire, _hash
from research.cross_scope_handoff import ScopeHandoffEngine, RELATION_A, RELATION
from research.invariant_transport import transport_invariant, verify_invariant_transport
from research.a_invariant_action import AInvariantAction
from research.scope_board_bridge import stage_scope_handoff
from runtime.research_board import load_research_board
from work.arc_like_maze.window_two import WindowProcess

Z = (0,)*9
Q0 = tuple(int(v==2) for u,v in product(range(3),repeat=2))
Q1 = tuple(int(v==2 and z==2) for v,z in product(range(3),repeat=2))

def table(a,b):
    return tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))

def rotated(q):
    t=[0]*9
    for z,y in product(range(3),repeat=2):
        t[3*((z+1)%3)+(y+int(z==2))%3]=q[3*z+y]
    return tuple(t)

def process(q):
    return WindowProcess(1,(Q0,Q1,q),(Z,))

SRC = process(table((0,0,0),(1,0,1)))
NEG = process(table((0,0,1),(0,2,2)))
POS = process(rotated(table((0,0,0),(1,0,1))))
AFIBER = AInvariantAction.orbit_fiber((0,0,0,0))
BFIBER = tuple((0, *tail) for tail in product(range(3),repeat=4))
ROOT = Path(__file__).resolve().parents[2] / "research" / "questions"

class AInvariantTests(unittest.TestCase):
    def setUp(self):
        self.engine = ContinuityEngine()
        self.bridge = ScopeHandoffEngine()

    def test_a_invariant_orbit_shape(self):
        self.assertEqual(AFIBER,((0,0,0,0,0),(1,0,0,0,0),(2,0,0,0,0)))
        self.assertEqual(len(AInvariantAction.carrier_for_dimension(5)),243)

    def test_a_watch_budget_and_verified_correspondence(self):
        early=self.engine.start_a_invariant(SRC,NEG,AFIBER,2)
        self.assertEqual(early.status,"UNKNOWN_A_BUDGET")
        result=self.engine.resume(early.serialize(),3)
        self.assertEqual(result.status,"A_ONLY_CONJUGACY_WITNESSED")
        self.assertEqual(result.powers_examined,3)
        self.assertEqual(result.witness,[[0,0],[1,1],[2,2]])
        self.assertEqual(len(result.snapshots),2)
        self.assertEqual(self.engine.verify(result.serialize()).serialize(),result.serialize())
        self.assertEqual(json.loads(result.snapshots[-1]["payload"])["simultaneous_A_B"],"UNKNOWN_NOT_WATCHED")
        self.assertEqual(early.serialize(),self.engine.verify(early.serialize()).serialize())

    def test_a_invariant_failure_on_b_fiber(self):
        with self.assertRaisesRegex(ValueError,"invariant"):
            self.engine.start_a_invariant(SRC,NEG,BFIBER,1)

    def test_noncanonical_and_singletons_rejected(self):
        a = self.engine
        for carrier in (AFIBER[::-1],AFIBER[:2],((0,0),),((0,0,0,0,0),)*3):
            with self.subTest(carrier=carrier),self.assertRaises(ValueError):
                a.start_a_invariant(SRC,NEG,carrier,3)

    def test_a_positive_plus_ab_negative_coexist(self):
        parent=self.engine.start_a_invariant(SRC,NEG,AFIBER,3)
        child=self.bridge.start(parent.serialize(),244,max_states=243)
        self.assertEqual(child.statuses,("A_ONLY_CONJUGACY_WITNESSED","DISTINGUISHED_FULL_AB"))
        self.assertEqual(child.proof["relation"],RELATION_A)
        self.assertEqual(child.proof["a_transition_checks"],6)
        self.assertNotIn("b_transition_checks",child.proof)
        self.assertEqual(self.bridge.verify(child.serialize()).serialize(),child.serialize())
        self.assertEqual(self.engine.verify(child.parent_serialized).status,"A_ONLY_CONJUGACY_WITNESSED")

    def test_a_positive_child_unknown_then_negative(self):
        parent=self.engine.start_a_invariant(SRC,NEG,AFIBER,3)
        early=self.bridge.start(parent.serialize(),0,max_states=243)
        self.assertEqual(early.statuses,("A_ONLY_CONJUGACY_WITNESSED","UNKNOWN_COLLISION_BUDGET"))
        later=self.bridge.continue_child(early.serialize(),244)
        self.assertEqual(early.parent_serialized,later.parent_serialized)
        self.assertTrue(self.bridge.verify_parent_unchanged(early.serialize(),later.serialize()))
        self.assertEqual(later.statuses[1],"DISTINGUISHED_FULL_AB")

    def test_a_positive_plus_ab_positive(self):
        parent=self.engine.start_a_invariant(SRC,POS,AFIBER,3)
        paired=self.bridge.start(parent.serialize(),244,max_states=243)
        self.assertEqual(paired.statuses,("A_ONLY_CONJUGACY_WITNESSED","CONJUGATE_FULL_AB"))
        self.assertEqual(paired.proof["a_transition_checks"],6)
        self.assertNotEqual(paired.proof["parent_question_id"],paired.proof["child_question_id"])

    def test_forged_a_observation_with_recomputed_hash_rejected(self):
        record=self.engine.start_a_invariant(SRC,NEG,AFIBER,3)
        envelope=json.loads(record.serialize())
        inner=json.loads(envelope["snapshots"][0]["payload"])
        inner["status"]="DISTINGUISHED_A_ACTIONS"
        envelope["snapshots"][0]["payload"]=_wire(inner)
        envelope["snapshots"][0]["sha256"]=_hash(_wire(inner))
        with self.assertRaises(ValueError):
            self.engine.verify(_wire(envelope))

    def test_b_handoff_stays_compatible(self):
        record=self.engine.start_cyclic(SRC,NEG,BFIBER,27)
        pair=self.bridge.start(record.serialize(),244,max_states=243)
        self.assertEqual(pair.proof["relation"],RELATION)
        self.assertEqual(pair.proof["b_transition_checks"],162)
        self.assertNotIn("a_transition_checks",pair.proof)
        self.assertEqual(self.bridge.verify(pair.serialize()).serialize(),pair.serialize())

    def test_board_stages_a_parent_without_promoting(self):
        parent=self.engine.start_a_invariant(SRC,NEG,AFIBER,3)
        pair=self.bridge.start(parent.serialize(),244,max_states=243)
        with tempfile.TemporaryDirectory() as temp:
            stage_scope_handoff(pair.serialize(),question_id="A-NEW-001",
                question="Does the full A/B correspondence exist?",
                source_board_root=ROOT,candidate_directory=Path(temp)/"board",
                frozen_date="2026-10-09")
            row=load_research_board(root=Path(temp)/"board")["questions"][-1]
            self.assertEqual(row["scope_handoff"]["a_transition_checks"],6)
            self.assertTrue(row["scope_handoff"]["non_promotion"])
            self.assertEqual(row["scope_handoff"]["parent_area"],"cyclic_action/A")
            self.assertEqual(row["status"],"REVIEW")

    def test_full_conjugacy_transports_A_invariant_carrier(self):
        full=self.engine.start_full_action(SRC,POS,5,244,max_states=243)
        result=transport_invariant(full.serialize(),AFIBER,generator="A",named_target=AFIBER)
        self.assertEqual(result.proof["source_size"],3)
        self.assertEqual(result.proof["image_size"],3)
        self.assertEqual(result.proof["intertwining_checks"],3)
        self.assertIsInstance(result.proof["named_target_matches_image"],bool)
        self.assertEqual(result.proof["generator"],"A")

    def test_full_conjugacy_transports_B_invariant_carrier(self):
        full=self.engine.start_full_action(SRC,POS,5,244,max_states=243)
        result=transport_invariant(full.serialize(),BFIBER,generator="B",named_target=BFIBER)
        self.assertEqual(result.proof["source_size"],81)
        self.assertEqual(result.proof["intertwining_checks"],81)

    def test_transport_fails_without_full_conjugacy(self):
        full=self.engine.start_full_action(SRC,NEG,5,244,max_states=243)
        with self.assertRaisesRegex(ValueError,"independently proved"):
            transport_invariant(full.serialize(),AFIBER,generator="A")
        unknown=self.engine.start_full_action(SRC,POS,5,0,max_states=243)
        with self.assertRaises(ValueError):
            transport_invariant(unknown.serialize(),AFIBER,generator="A")

    def test_transport_replay_rejects_modified_image_and_changed_parent(self):
        full=self.engine.start_full_action(SRC,POS,5,244,max_states=243)
        transport=transport_invariant(full.serialize(),AFIBER,generator="A",named_target=AFIBER)
        self.assertEqual(verify_invariant_transport(transport.serialize(),full.serialize(),named_target=AFIBER).serialize(),transport.serialize())
        fake=json.loads(transport.serialize())
        fake["transported_carrier"][0][0]=(fake["transported_carrier"][0][0]+1)%3
        with self.assertRaises(ValueError):
            verify_invariant_transport(_wire(fake),full.serialize(),named_target=AFIBER)
        with self.assertRaises(ValueError):
            verify_invariant_transport(transport.serialize(),full.serialize(),named_target=AInvariantAction.orbit_fiber((1,0,0,0)))

    def test_multiple_A_orbits_replay(self):
        carrier=tuple(sorted(AInvariantAction.orbit_fiber((0,0,0,0)) + AInvariantAction.orbit_fiber((1,0,0,0))))
        record=self.engine.start_a_invariant(SRC,NEG,carrier,3)
        self.assertEqual(record.status,"A_ONLY_CONJUGACY_WITNESSED")
        self.assertEqual(len(record.witness),6)
        self.assertEqual(self.engine.verify(record.serialize()).serialize(),record.serialize())

    def test_no_A_B_common_proper_invariant_subset_for_transitive_action(self):
        # From the independently tested full action's 243-state transitivity:
        # any nonempty set closed under both generators is the entire orbit.
        from collections import deque
        whole=set(product(range(3),repeat=5))
        seen={AFIBER[0]}
        queue=deque(seen)
        while queue:
            x=queue.popleft()
            for g in ("A","B"):
                y=SRC.step(x,g)
                if y not in seen:
                    seen.add(y);queue.append(y)
        self.assertEqual(seen,whole)

    def test_transport_rejects_bad_invariant_carrier(self):
        full=self.engine.start_full_action(SRC,POS,5,244,max_states=243)
        with self.assertRaisesRegex(ValueError,"invariant"):
            transport_invariant(full.serialize(),BFIBER,generator="A")
        with self.assertRaisesRegex(ValueError,"invariant"):
            transport_invariant(full.serialize(),AFIBER,generator="B")

    def test_a_only_board_question_scoped(self):
        from research.continuity_board_bridge import stage_checkpoint
        rec=self.engine.start_a_invariant(SRC,NEG,AFIBER,3)
        with tempfile.TemporaryDirectory() as tmp:
            stage_checkpoint(rec.serialize(),question_id="A-NEW-002",question="Are the A actions conjugate?",
                source_board_root=ROOT,candidate_directory=Path(tmp)/"board",frozen_date="2026-10-09")
            row=load_research_board(root=Path(tmp)/"board")["questions"][-1]
            self.assertIn("Restricted A-action",row["scope"])
            self.assertEqual(row["status"],"REVIEW")

if __name__ == "__main__":
    unittest.main()
