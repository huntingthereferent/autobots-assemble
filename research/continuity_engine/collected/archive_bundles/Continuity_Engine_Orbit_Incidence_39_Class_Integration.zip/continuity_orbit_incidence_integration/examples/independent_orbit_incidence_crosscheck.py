"""Independent finite arithmetic and bitset witness reproduction on all 702 laws.

Does not import WindowProcess, Continuity Engine, or its orbit-incidence math.
Comparison imports their output only after building each independent result.
"""
from collections import Counter
from itertools import product
from pathlib import Path
import json
from time import perf_counter

N=243
STATES=tuple(product(range(3),repeat=5))
INDEX={s:i for i,s in enumerate(STATES)}
PARAMS=tuple((a,b) for a in product(range(3),repeat=3)
             for b in product(range(3),repeat=3) if any(b))
FEATURES=(("A","B","A"),("BA","ABBabbbb"),("ABab","BABa"))
ALL_WORDS={"A","B","BA","ABBabbbb","ABab","BABa","BAB","Ab"}

def direct_actions(params):
    a,b=params
    edges_A=[];edges_B=[]
    for u,v,z,y,t in STATES:
        edges_A.append(INDEX[((u+1)%3,v,z,y,t)])
        edges_B.append(INDEX[(u,(v+u+1)%3,(z+int(v==2))%3,
             (y+int(v==2 and z==2))%3,(t+a[z]+b[z]*y)%3)])
    return tuple(edges_A),tuple(edges_B)

def inverse(p):
    out=[None]*len(p)
    for x,y in enumerate(p):out[y]=x
    assert None not in out
    return tuple(out)

def word_action(steps,word):
    destination=list(range(N))
    for g in word:
        p=steps[g]
        destination=[p[x] for x in destination]
    return destination

def orbit_masks(p):
    output=[0]*N
    for i in range(N):
        if output[i]:continue
        members=[];x=i
        while not output[x] and x not in members:
            members.append(x)
            x=p[x]
        assert x==i
        mask=0
        for x in members:mask |= 1<<x
        for x in members:output[x]=mask
    return output

def close_set(bitset,orbits):
    answer=0
    for i in range(N):
        if bitset>>i & 1:answer |=orbits[i]
    return answer

def histogram(nums):
    return tuple(sorted(Counter(nums).items()))

def evaluate(p):
    aa,bb=direct_actions(p)
    step={'A':aa,'B':bb,'a':inverse(aa),'b':inverse(bb)}
    orbit={w:orbit_masks(word_action(step,w)) for w in ALL_WORDS}
    histograms=[]
    for words in FEATURES:
        rows=[1<<i for i in range(N)]
        for w in words:rows=[close_set(mask,orbit[w]) for mask in rows]
        histograms.append(histogram(mask.bit_count() for mask in rows))
    linked=histogram((orbit['BAB'][x]&orbit['Ab'][aa[x]]).bit_count() for x in range(N))
    return tuple(histograms+[linked])

def main():
    from research.action_orbit_incidence import all_features
    from examples.reproduce_702_saturation_census import process
    begin=perf_counter();mismatches=[]; signs=[];observed=0
    for p in PARAMS:
        direct=evaluate(p)
        native=tuple(tuple(map(tuple,x['histogram'])) for x in all_features(process(p),5,243))
        if direct!=native:mismatches.append(p)
        signs.append(direct)
        observed+=N*2
    assert not mismatches,mismatches[:5]
    assert len(set(signs))==39
    result={"laws_checked":len(PARAMS),"independent_labeled_edges":observed,
            "full_fingerprints_checked":len(signs),"distinct_full_fingerprints":len(set(signs)),
            "direct_math_vs_windowprocess_mismatches":len(mismatches),
            "runtime_seconds":round(perf_counter()-begin,3)}
    Path(__file__).with_name('independent_orbit_incidence_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
