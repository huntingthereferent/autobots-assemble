"""Reproduce all 702 linear-in-y coupling-law three-stage A/B saturation fingerprints.

Uses the Continuity Engine's native per-law saturation operation. Does *not*
claim that equality of fingerprints is sufficient for conjugacy.
"""
from collections import Counter, defaultdict
from itertools import product
import json
from pathlib import Path
from research.alternating_saturation import compute_profiles
from work.arc_like_maze.window_two import WindowProcess

Z=(0,)*9
Q0=tuple(int(v==2) for u,v in product(range(3),repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(range(3),repeat=2))
PARAMS=tuple((a,b) for a in product(range(3), repeat=3)
             for b in product(range(3), repeat=3) if any(b))

def table(p):
    a,b=p
    return tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))

def process(p):
    return WindowProcess(1,(Q0,Q1,table(p)),(Z,))

def R(p):
    a,b=p
    ao=[0]*3;bo=[0]*3
    for z in range(3):
        next_z=(z+1)%3
        ao[next_z]=(a[z]-int(z==2)*b[z])%3
        bo[next_z]=b[z]
    return tuple(ao),tuple(bo)

def S(p):
    a,b=p
    return tuple(2*v%3 for v in a),tuple(2*v%3 for v in b)

def orbit_RS(p):
    group=set()
    item=p
    for k in range(9):
        group.add(item)
        group.add(S(item))
        item=R(item)
    assert item==p
    return frozenset(group)

def main():
    fp={}
    for p in PARAMS:
        profile=compute_profiles(process(p), 5, "AB", 3, max_states=243)
        fp[p]=tuple(tuple(x) for x in profile[-1]["histogram"])
    counts=Counter(fp.values())
    remaining=set(PARAMS)
    positive_orbits=[]
    while remaining:
        p=min(remaining)
        orbit=orbit_RS(p)
        assert len(orbit)==18 and orbit <= remaining
        remaining -= orbit
        assert len({fp[q] for q in orbit})==1
        positive_orbits.append(orbit)
    assert len(positive_orbits)==39 and len(fp)==702 and len(counts)==18
    hist_classes=Counter(fp[min(orbit)] for orbit in positive_orbits)
    assert Counter(counts.values()) == Counter({18:8,36:5,72:3,108:1,54:1})
    assert Counter(hist_classes.values()) == Counter({1:8,2:5,4:3,6:1,3:1})
    source=((0,0,0),(1,0,1))
    target=((0,0,1),(0,2,2))
    result={
       "family":"q(z,y)=a_z+b_z*y, b!=0 in F3^3",
       "laws":len(fp),
       "declared_states_per_law":243,
       "sequence":"A,B,A (successive full generator orbit saturations)",
       "positive_R_S_orbits":len(positive_orbits),
       "positive_R_S_orbit_sizes":dict(Counter(map(len,positive_orbits))),
       "distinct_three_step_histograms":len(counts),
       "histogram_law_frequency_distribution":dict(sorted(Counter(counts.values()).items())),
       "histogram_positive_orbit_frequency_distribution":dict(sorted(Counter(hist_classes.values()).items())),
       "hard_source":{"a":list(source[0]),"b":list(source[1]),"ABA_histogram":list(map(list,fp[source]))},
       "hard_target":{"a":list(target[0]),"b":list(target[1]),"ABA_histogram":list(map(list,fp[target]))},
       "hard_pair_distinguished":fp[source]!=fp[target],
       "caution":"18 fingerprints only. Equality does not establish A/B conjugacy; previous exhaustive classification has 39 classes."
    }
    dest=Path(__file__).with_name("coupling_saturation_census.json")
    dest.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    return result

if __name__=="__main__":
    main()
