"""Rebuild exact saved snapshots; no network, GitHub, or board mutations."""
from pathlib import Path
import json
from research.continuity_engine import ContinuityEngine
from research.continuity_board_bridge import stage_checkpoint
from examples.reproduce_702_saturation_census import process, R

ROOT=Path(__file__).parent
c=ContinuityEngine()
source=((0,0,0),(1,1,2))
negative=((0,0,0),(1,2,2))
positive=R(source)
s,t,p=process(source),process(negative),process(positive)
unknown=c.start_orbit_incidence(s,t,5,3,max_states=243)
distinguished=c.resume(unknown.serialize(),4,expected_question_id=unknown.question_id)
positive_observations=c.start_orbit_incidence(s,p,5,4,max_states=243)
full_positive=c.start_full_action(s,p,5,244,max_states=243)
assert unknown.status=='UNKNOWN_ORBIT_INCIDENCE_BUDGET'
assert distinguished.status=='DISTINGUISHED_FULL_AB_BY_ORBIT_INCIDENCE'
assert positive_observations.status=='UNKNOWN_ORBIT_INCIDENCE_BUDGET'
assert full_positive.status=='CONJUGATE_FULL_AB'
for name,result in [('orbit_incidence_unknown_stage3',unknown),
                    ('orbit_incidence_stage4_obstruction',distinguished),
                    ('orbit_incidence_known_conjugate_unknown',positive_observations),
                    ('orbit_incidence_known_conjugate_full_bijection',full_positive)]:
    filename=ROOT/(name+'.json')
    filename.write_text(json.dumps(json.loads(result.serialize()),indent=2)+'\n',encoding='utf-8')
    assert c.verify(result.serialize()).serialize()==result.serialize()
print(json.dumps({'saved_records':4,'negative_first_obstruction':4,
                  'positive_full_mapping_size':len(full_positive.witness)},indent=2))
