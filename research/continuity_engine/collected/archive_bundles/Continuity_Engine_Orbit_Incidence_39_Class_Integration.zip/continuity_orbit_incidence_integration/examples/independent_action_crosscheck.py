"""Independent direct generator arithmetic + bitmask closure cross-check.

For every 702 coupling laws, compare this standalone finite model to the
WindowProcess-backed saturation implementation. This test does not claim
all 702 laws are pairwise classified by the new fingerprint.
"""
from collections import Counter
from itertools import product
import json
from pathlib import Path
from research.alternating_saturation import compute_profiles
from work.arc_like_maze.window_two import WindowProcess

F3=range(3)
STATES=tuple(product(F3,repeat=5))
INDEX={x:i for i,x in enumerate(STATES)}
ZERO=(0,)*9
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(F3,repeat=2))

def orbit_masks(edge):
    result=[0]*243
    seen=set()
    for root in range(243):
        if root in seen:continue
        visited=[];x=root
        while x not in seen:
            seen.add(x);visited.append(x);x=edge[x]
        assert x==root
        mask=sum(1<<i for i in visited)
        for i in visited:result[i]=mask
    return result

def independent_hist(edge_a,edge_b,sequence="AB",depth=3):
    orbits={'A':orbit_masks(edge_a),'B':orbit_masks(edge_b)}
    roots=[1<<i for i in range(243)]
    out=[]
    for step in range(depth):
        letter=sequence[step%2]
        changed=[]
        for mask in roots:
            total=0
            while mask:
                first=mask&-mask
                mask-=first
                total |= orbits[letter][first.bit_length()-1]
            changed.append(total)
        roots=changed
        histogram=Counter(x.bit_count() for x in roots)
        out.append([[size,count] for size,count in sorted(histogram.items())])
    return out

def main():
    checks=0; fingerprints=Counter(); law_count=0
    for a in product(F3,repeat=3):
        for b in product(F3,repeat=3):
            if not any(b):continue
            law_count+=1
            q=tuple((a[z]+b[z]*y)%3 for z,y in product(F3,repeat=2))
            real=WindowProcess(1,(Q0,Q1,q),(ZERO,))
            a_edges=[];b_edges=[]
            for s in STATES:
                u,v,z,y,t=s
                expected_a=((u+1)%3,v,z,y,t)
                expected_b=(u,(v+u+1)%3,(z+int(v==2))%3,
                            (y+int(v==2 and z==2))%3,(t+q[3*z+y])%3)
                assert real.step(s,'A')==expected_a
                assert real.step(s,'B')==expected_b
                checks+=2
                a_edges.append(INDEX[expected_a]);b_edges.append(INDEX[expected_b])
            independent=independent_hist(a_edges,b_edges,'AB',3)
            native=compute_profiles(real,5,'AB',3,max_states=243)
            assert independent==[step['histogram'] for step in native], (a,b)
            fingerprints[tuple(tuple(v) for v in independent[-1])]+=1
    assert law_count==702 and checks==341172 and len(fingerprints)==18
    result={'laws':law_count,'full_state_generator_equations_checked':checks,
            'independent_ABA_histogram_series_compared':law_count,
            'histograms_at_depth3':len(fingerprints),
            'fingerprint_law_frequency_distribution':dict(sorted(Counter(fingerprints.values()).items())),
            'independent_matches_native_every_law':True}
    dest=Path(__file__).with_name('independent_action_crosscheck_results.json')
    dest.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
