"""Self-contained 702-law exact classification by four conjugacy invariants.

39 positive R,S orbits + 39 pairwise distinct exact signatures = classification.
Separates a negative invariant from a verified positive state-space transport.
"""
from collections import Counter, defaultdict
from itertools import product
import json
from pathlib import Path
from research.action_orbit_incidence import all_features
from examples.reproduce_702_saturation_census import PARAMS, process, orbit_RS, R, S, table

F3=range(3)
STATES=tuple(product(F3, repeat=5))

def transport_R(x):
    u,v,z,y,t=x
    return (u,v,(z+1)%3,(y+int(z==2))%3,t)
def transport_S(x):
    u,v,z,y,t=x
    return (u,v,z,y,2*t%3)

def verify_transport(p, transform, transport):
    source=process(p); target=process(transform(p))
    images=[transport(x) for x in STATES]
    assert len(set(images))==243
    for x in STATES:
        for generator in 'AB':
            assert transport(source.step(x,generator)) == target.step(transport(x),generator)
    return 2*len(STATES)

def main():
    signatures={}
    old_three={}
    for p in PARAMS:
        obs=all_features(process(p),5,max_states=243)
        signatures[p]=tuple(tuple(map(tuple, o['histogram'])) for o in obs)
        old_three[p]=signatures[p][0]
    assert len(signatures)==702
    assert len(set(old_three.values()))==18
    remaining=set(PARAMS)
    orbits=[]
    action_checks=0
    while remaining:
        p=min(remaining)
        orbit=orbit_RS(p)
        assert len(orbit)==18 and orbit<=remaining
        remaining-=orbit
        assert len({signatures[q] for q in orbit})==1
        orbits.append(sorted(orbit))
    assert len(orbits)==39
    labels=[signatures[c[0]] for c in orbits]
    assert len(set(labels))==39
    for p in PARAMS:
        action_checks += verify_transport(p, R, transport_R)
        action_checks += verify_transport(p, S, transport_S)
    assert action_checks==702*243*4
    increments=[]
    for i in range(1,5):
        signatures_k=[tuple(label[:i]) for label in labels]
        increments.append(len(set(signatures_k)))
    assert increments==[18,30,33,39],increments
    class_reps=[{'a':list(c[0][0]),'b':list(c[0][1]),'class_size':len(c),
        'features':[list(map(list, hist)) for hist in signatures[c[0]]]} for c in orbits]
    hard_a=((0,0,0),(1,1,2)); hard_b=((0,0,0),(1,2,2))
    assert signatures[hard_a][:3]==signatures[hard_b][:3]
    assert signatures[hard_a][3]!=signatures[hard_b][3]
    result={
        'family':'q(z,y)=a_z+b_z*y; a,b in F3^3, b != 0',
        'states':243,'laws':len(PARAMS),'positive_transport_group':'C9 x C2',
        'positive_transport_orbits':len(orbits),
        'laws_per_orbit':18,
        'distinct_fingerprints_after_each_feature':increments,
        'proved_unrooted_classes':len(set(labels)),
        'ordered_conjugate_pairs':sum(len(c)**2 for c in orbits),
        'ordered_nonconjugate_pairs':702*702-sum(len(c)**2 for c in orbits),
        'transported_generator_equations_verified':action_checks,
        'independent_of_prior_negative_conjugacy_search':True,
        'hard_pair':{
            'source':{'a':list(hard_a[0]),'b':list(hard_a[1])},
            'target':{'a':list(hard_b[0]),'b':list(hard_b[1])},
            'matching_first_three':True,
            'source_linked_histogram':list(map(list,signatures[hard_a][3])),
            'target_linked_histogram':list(map(list,signatures[hard_b][3]))},
        'representatives':class_reps,
        'limits':'Classification only for this 702-law finite family; not arbitrary A/B systems, ARC execution, or physical dimensions.'}
    path=Path(__file__).with_name('orbit_incidence_702_results.json')
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='representatives'},indent=2))
    return result

if __name__=='__main__':main()
