"""Regenerate exact mathematical witness JSON for the extension.

Use only the package's admitted WindowProcess grammar; local test harness
reproduces the native generator semantics but does not run GitHub modules.
"""
from itertools import product
from pathlib import Path
from research.continuity_engine import ContinuityEngine
from research.a_invariant_action import AInvariantAction
from research.invariant_intersections import analyze_intersection, transport_intersection
from work.arc_like_maze.window_two import WindowProcess

OUT=Path(__file__).resolve().parent
Z=(0,)*9
Q0=tuple(int(v==2) for u,v in product(range(3),repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(range(3),repeat=2))
def t(a,b):return tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))
def rotate(q):
 out=[0]*9
 for z,y in product(range(3),repeat=2):
  out[3*((z+1)%3)+(y+int(z==2))%3]=q[3*z+y]
 return tuple(out)
def law(q):return WindowProcess(1,(Q0,Q1,q),(Z,))
source=law(t((0,0,0),(1,0,1)))
negative=law(t((0,0,1),(0,2,2)))
positive=law(rotate(t((0,0,0),(1,0,1))))
A=AInvariantAction.orbit_fiber((0,0,0,0))
B=tuple((0,*tail) for tail in product(range(3),repeat=4))

eng=ContinuityEngine()
full=eng.start_full_action(source,positive,5,244,max_states=243)
assert full.status=='CONJUGATE_FULL_AB'
items={
 'hard_pair_ABA_first_two_unknown.json':eng.start_saturation(source,negative,5,2,sequence='AB',max_states=243).serialize(),
 'hard_pair_ABA_third_step_obstruction.json':eng.start_saturation(source,negative,5,3,sequence='AB',max_states=243).serialize(),
 'hard_pair_BAB_third_step_obstruction.json':eng.start_saturation(source,negative,5,3,sequence='BA',max_states=243).serialize(),
 'positive_pair_ABA_unknown.json':eng.start_saturation(source,positive,5,3,sequence='AB',max_states=243).serialize(),
 'chosen_carrier_intersection.json':analyze_intersection(source,A,B).serialize(),
 'full_positive_correspondence_parent.json':full.serialize(),
 'positive_full_intersection_transport.json':transport_intersection(full.serialize(),A,B,named_target_a=A,named_target_b=B).serialize(),
}
for name,content in items.items():
 (OUT/name).write_text(content+'\n')
 print(name, len(content))
