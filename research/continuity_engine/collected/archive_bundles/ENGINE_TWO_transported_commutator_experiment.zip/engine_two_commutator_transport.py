"""Engine 2, local parallel experiment: transport a noncommuting selected pair.

Works only for the gain-one, fixed-q0, k=0, q2=0, zero-tail quotient
family implemented in engine_two_quotient_conjugacy.py. It is neither a
repo patch nor a universal centralizer classifier.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from collections import deque
from engine_two_quotient_conjugacy import (
    F3, Q0, ALPHA, QSPACE, research, step, PotentialConjugacy,
)
from engine_two_symmetry_transport_watch import canonical_symmetry

STATES = tuple(product(F3, repeat=5))
LOWER_STATES = tuple(product(F3, repeat=3))
SOURCE = (1,0,2)
TARGET = (0,2,1)


def lower_B(Q, s, u):
    v,z,y = s
    w = (z + ALPHA[v]) % 3
    return ((v+u+1)%3, (z + Q0[3*u+v])%3, (y + Q[w])%3)


def components(Q):
    labels = {}
    for root in LOWER_STATES:
        if root in labels:
            continue
        component = len(set(labels.values()))
        labels[root] = component
        todo = deque([root])
        # E_u is invertible; undirected graph is more general and exact.
        while todo:
            p = todo.popleft()
            for u in F3:
                nxt = lower_B(Q,p,u)
                prv = next(s for s in LOWER_STATES if lower_B(Q,s,u)==p)
                for neighbor in (nxt,prv):
                    if neighbor not in labels:
                        labels[neighbor] = component
                        todo.append(neighbor)
    return labels


def apply_centralizer(Q, c, x):
    labels = components_cached(Q)
    if len(c) != len(set(labels.values())):
        raise ValueError("incorrect component constants")
    u,v,z,y,t = x
    cval = c[labels[(v,z,y)]]
    mid = canonical_symmetry(x,Q)
    return mid[:4] + ((t + cval)%3,)


_COMPONENTS = {}
def components_cached(Q):
    if Q not in _COMPONENTS:
        _COMPONENTS[Q] = components(Q)
    return _COMPONENTS[Q]


def fourth_shift(x, d):
    return x[:3] + ((x[3]+d)%3,) + x[4:]


def fifth_gauge(Q,c,x):
    t=(x[4]+c[components_cached(Q)[x[1:4]]])%3
    return x[:4] + (t,)


def transport(H, f, x):
    return H.map(f(H.inverse_map(x)))


def composition(f,g,x):
    return f(g(x))


def iterate(f,x,n):
    for _ in range(n):x=f(x)
    return x


def inverse_power(f,x):
    # Both selected symmetries have order dividing nine in the source case.
    return iterate(f,x,8)


def commutator(f,g,x):
    return f(g(inverse_power(f,inverse_power(g,x))))


def transported_constants(H,c):
    src=components_cached(H.source)
    dst=components_cached(H.target)
    mapping={}
    for s in LOWER_STATES:
        x=(0,)+s+(0,)
        src_point=H.inverse_map(x)[1:4]
        k=dst[s]; value=c[src[src_point]]
        if k in mapping and mapping[k]!=value:
            raise AssertionError("law conjugacy did not transport component gauges")
        mapping[k]=value
    return tuple(mapping[i] for i in range(len(set(dst.values()))))


def permute_components(Q,action):
    labels=components_cached(Q)
    found={}
    for s in LOWER_STATES:
        x=(0,)+s+(0,)
        image=action(x)[1:4]
        i,j=labels[s],labels[image]
        if i in found and found[i]!=j:
            raise AssertionError("map not acting on whole graph components")
        found[i]=j
    return tuple(found[i] for i in range(len(set(labels.values()))))


@dataclass(frozen=True)
class Result:
    source:tuple[int,...]
    target:tuple[int,...]
    h_scale:int
    h_potential:tuple[int,...]
    fourth_correction:int
    source_components:int
    target_components:int
    source_component_permutation:tuple[int,...]
    target_canonical_permutation:tuple[int,...]
    target_corrected_permutation:tuple[int,...]
    source_pair_constants:tuple[tuple[int,...],tuple[int,...]]
    target_gauge_constants:tuple[tuple[int,...],tuple[int,...]]
    noncommuting_states:int
    noncommuting_states_after_transport:int
    commutator_transport_failures:int
    decomposition_failures:int
    original_generators_failures:int
    witness:dict


def run_case(Q=SOURCE,P=TARGET):
    result=research(Q,P)
    H=result.witness
    if not isinstance(H,PotentialConjugacy):
        raise ValueError("a proven law conjugacy is required")
    a=(0,)*len(set(components_cached(Q).values()))
    b=(0,)*(len(a)-1)+(1,)
    F=lambda x:apply_centralizer(Q,a,x)
    G=lambda x:apply_centralizer(Q,b,x)
    Fp=lambda x:transport(H,F,x)
    Gp=lambda x:transport(H,G,x)
    delta=(P[0]-H.scale*Q[0])%3
    A=transported_constants(H,a)
    B=transported_constants(H,b)
    def lower_corrected(x):
        return fourth_shift(canonical_symmetry(x,P),delta)
    def factored(c,x):
        # H(F_c)H^-1 = (D_delta C_P) T_{transported_component_constants}
        return lower_corrected(fifth_gauge(P,c,x))
    source_perm=permute_components(Q,lambda x:canonical_symmetry(x,Q))
    target_perm=permute_components(P,lambda x:canonical_symmetry(x,P))
    corrected_perm=permute_components(P,lower_corrected)
    counts=dict(noncommuting=0,transport_noncommuting=0,transport_failed=0,
                decomposition_failed=0,original_generators_failed=0)
    example=None
    for x in STATES:
        left,right=F(G(x)),G(F(x))
        if left!=right:counts['noncommuting']+=1
        moved=H.map(x)
        target_left,target_right=Fp(Gp(moved)),Gp(Fp(moved))
        if target_left!=target_right:counts['transport_noncommuting']+=1
        if target_left!=H.map(left) or target_right!=H.map(right):
            counts['transport_failed']+=1
        if Fp(moved)!=factored(A,moved) or Gp(moved)!=factored(B,moved):
            counts['decomposition_failed']+=1
        for f in (Fp,Gp):
            for generator in 'AB':
                if f(step(moved,generator,P))!=step(f(moved),generator,P):
                    counts['original_generators_failed']+=1
        if left!=right and example is None:
            example={'state_source':x,'state_target':moved,
                     'first_after_second_source':left,'second_after_first_source':right,
                     'first_after_second_target':target_left,'second_after_first_target':target_right,
                     'commutator_source':commutator(F,G,x),
                     'transported_commutator':commutator(Fp,Gp,moved)}
        if commutator(Fp,Gp,moved)!=H.map(commutator(F,G,x)):
            counts['transport_failed']+=1
    return Result(Q,P,H.scale,H.potential,delta,len(a),len(A),source_perm,
                  target_perm,corrected_perm,(a,b),(A,B),
                  counts['noncommuting'],counts['transport_noncommuting'],
                  counts['transport_failed'],counts['decomposition_failed'],
                  counts['original_generators_failed'],example)


if __name__=='__main__':
    from dataclasses import asdict
    import json
    print(json.dumps(asdict(run_case()),indent=2))
