"""Local regression tests for Engine 2 cross-law transport of a commutator."""
import unittest
from itertools import product
from dataclasses import asdict

from engine_two_quotient_conjugacy import F3,QSPACE,research,PotentialConjugacy,step
from engine_two_symmetry_transport_watch import canonical_symmetry
from engine_two_commutator_transport import (
    SOURCE,TARGET,STATES,run_case,components_cached,apply_centralizer,
    permute_components,transport,transported_constants,fourth_shift,
    fifth_gauge,iterate,commutator,
)


class WitnessedCommutatorTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.Q=SOURCE; cls.P=TARGET
        cls.H=research(cls.Q,cls.P).witness
        cls.a=(0,0,0);cls.b=(0,0,1)
        cls.F=staticmethod(lambda x:apply_centralizer(cls.Q,cls.a,x))
        cls.G=staticmethod(lambda x:apply_centralizer(cls.Q,cls.b,x))
        cls.Fp=staticmethod(lambda x:transport(cls.H,cls.F,x))
        cls.Gp=staticmethod(lambda x:transport(cls.H,cls.G,x))
        cls.ledger=run_case(cls.Q,cls.P)

    def test_01_witnessed_law_conjugacy_and_inverse_replay(self):
        self.assertIsInstance(self.H,PotentialConjugacy)
        self.assertEqual((self.H.source,self.H.target),(SOURCE,TARGET))
        self.assertEqual(self.H.scale,1)
        for x in STATES:
            y=self.H.map(x)
            self.assertEqual(self.H.inverse_map(y),x)
            for letter in 'AB':
                self.assertEqual(self.H.map(step(x,letter,self.Q)),step(y,letter,self.P))

    def test_02_components_are_preserved_by_the_map_not_by_canonical_C(self):
        self.assertEqual(len(set(components_cached(self.Q).values())),3)
        self.assertEqual(len(set(components_cached(self.P).values())),3)
        self.assertEqual(self.ledger.source_component_permutation,(2,0,1))
        self.assertEqual(self.ledger.target_canonical_permutation,(0,1,2))
        self.assertEqual(self.ledger.target_corrected_permutation,(2,0,1))
        self.assertEqual(self.ledger.fourth_correction,2)

    def test_03_selected_orders_do_not_collapse_into_underlying_law(self):
        for x in STATES:
            self.assertEqual(iterate(self.F,x,3),x)
            self.assertEqual(iterate(self.G,x,9),x)
            self.assertEqual(iterate(self.Fp,self.H.map(x),3),self.H.map(x))
            self.assertEqual(iterate(self.Gp,self.H.map(x),9),self.H.map(x))
        self.assertNotEqual(iterate(self.G,(0,0,0,0,0),3),(0,0,0,0,0))
        self.assertNotEqual(iterate(self.Gp,(0,0,0,0,0),3),(0,0,0,0,0))

    def test_04_explicit_source_ordered_witness(self):
        x=(0,0,0,0,0)
        self.assertEqual(self.F(self.G(x)),(0,0,2,2,0))
        self.assertEqual(self.G(self.F(x)),(0,0,2,2,1))
        self.assertEqual(commutator(self.F,self.G,x),(0,0,0,0,1))

    def test_05_all_243_states_transport_both_orders(self):
        for x in STATES:
            t=self.H.map(x)
            self.assertEqual(self.Fp(self.Gp(t)),self.H.map(self.F(self.G(x))))
            self.assertEqual(self.Gp(self.Fp(t)),self.H.map(self.G(self.F(x))))
            self.assertEqual(commutator(self.Fp,self.Gp,t),
                             self.H.map(commutator(self.F,self.G,x)))
        self.assertEqual((self.ledger.noncommuting_states,
                          self.ledger.noncommuting_states_after_transport),(162,162))
        self.assertEqual(self.ledger.commutator_transport_failures,0)

    def test_06_target_selected_symmetries_keep_AB(self):
        for x in STATES:
            for letter in 'AB':
                for m in (self.Fp,self.Gp):
                    self.assertEqual(m(step(x,letter,self.P)),step(m(x),letter,self.P))
        self.assertEqual(self.ledger.original_generators_failures,0)

    def test_07_transport_has_an_exact_correction_and_gauge_factorization(self):
        shift=self.ledger.fourth_correction
        a=transported_constants(self.H,self.a)
        b=transported_constants(self.H,self.b)
        self.assertEqual((a,b),((0,0,0),(0,0,1)))
        for x in STATES:
            for c,m in ((a,self.Fp),(b,self.Gp)):
                correct=fourth_shift(canonical_symmetry(fifth_gauge(self.P,c,x),self.P),shift)
                self.assertEqual(m(x),correct)
        self.assertEqual(self.ledger.decomposition_failures,0)

    def test_08_canonical_only_false_negative(self):
        # A naive comparison in P would claim commutativity, erasing the
        # *actual* transported commutator of the pair.
        canon_a=lambda x:apply_centralizer(self.P,transported_constants(self.H,self.a),x)
        canon_b=lambda x:apply_centralizer(self.P,transported_constants(self.H,self.b),x)
        self.assertTrue(all(canon_a(canon_b(x))==canon_b(canon_a(x)) for x in STATES))
        self.assertEqual(sum(self.Fp(self.Gp(x))!=self.Gp(self.Fp(x)) for x in STATES),162)

    def test_09_all_nine_target_quotients_preserve_the_full_commutator(self):
        targets=[p for p in QSPACE if sum(p)%3==0]
        self.assertEqual(len(targets),9)
        for p in targets:
            with self.subTest(target=p):
                w=run_case(SOURCE,p)
                self.assertEqual((w.source_components,w.target_components),(3,3))
                self.assertEqual((w.noncommuting_states,w.noncommuting_states_after_transport),(162,162))
                self.assertEqual((w.commutator_transport_failures,w.decomposition_failures,w.original_generators_failures),(0,0,0))
                self.assertEqual(w.target_corrected_permutation,(2,0,1))

    def test_10_fourth_coordinate_correction_is_compositional(self):
        zero_trace=[p for p in QSPACE if sum(p)%3==0]
        x=(0,0,0,0,0)
        for middle in zero_trace:
            h1=research(SOURCE,middle).witness
            for target in zero_trace:
                h2=research(middle,target).witness
                direct=research(SOURCE,target).witness
                d1=(middle[0]-h1.scale*SOURCE[0])%3
                d2=(target[0]-h2.scale*middle[0])%3
                d=(target[0]-direct.scale*SOURCE[0])%3
                self.assertEqual(d,(d2+h2.scale*d1)%3)
                self.assertEqual(direct.scale,(h2.scale*h1.scale)%3)
                self.assertEqual(h2.map(h1.map(x)),direct.map(x))
                for p in product(F3,repeat=2):
                    v,z=p
                    point=(0,v,z,1,0)
                    self.assertEqual(h2.map(h1.map(point)),direct.map(point))

    def test_11_no_cross_trace_transport_without_law_conjugacy(self):
        r=research(SOURCE,(0,0,1))
        self.assertNotIsInstance(r.witness,PotentialConjugacy)
        self.assertEqual(r.status,'FULL_STATE_OBSTRUCTED_BY_BBB')

    def test_12_the_result_has_law_symmetry_and_mark_witnesses_separately(self):
        d=asdict(self.ledger)
        self.assertNotEqual(d['source'],d['target'])
        self.assertNotEqual(d['target_canonical_permutation'],d['target_corrected_permutation'])
        self.assertNotEqual(d['witness']['first_after_second_target'],d['witness']['second_after_first_target'])
        self.assertEqual(d['witness']['commutator_source'],d['witness']['transported_commutator'])

if __name__=='__main__': unittest.main(verbosity=2)
