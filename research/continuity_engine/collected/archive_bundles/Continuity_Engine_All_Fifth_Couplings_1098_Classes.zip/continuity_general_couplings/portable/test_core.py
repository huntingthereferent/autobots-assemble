"""Regression tests: no internet, GitHub checkout or third-party packages required."""
import unittest
from collections import Counter
from itertools import product
from core import (R,S,orbit_RS,A,B,word_map,positive_transport_checks,
                  fingerprint,old_four,find_conjugacy,reach_count,inverse,STATES,
                  STATE_R,STATE_S,SELECTED_FEATURES)

ZERO=(0,)*9
Q1=(0,0,0,0,0,1,0,1,1)
Q2=(0,0,0,0,1,1,0,1,0)

class FiniteCouplingActionTests(unittest.TestCase):
    def test_generator_permutations(self):
        for q in (ZERO,Q1,Q2,tuple(range(3))*3):
            b=B(q)
            self.assertEqual(set(b),set(range(243)))
            self.assertEqual(set(A),set(range(243)))
            self.assertEqual(tuple(inverse(b)[b[i]] for i in range(243)),tuple(range(243)))

    def test_R9_and_S2_commute_on_laws(self):
        for q in (ZERO,Q1,Q2,(1,)*9):
            p=q
            for _ in range(9):p=R(p)
            self.assertEqual(p,q)
            self.assertEqual(S(S(q)),q)
            self.assertEqual(S(R(q)),R(S(q)))

    def test_R_and_S_commute_on_states(self):
        self.assertEqual(set(STATE_R),set(range(243)))
        self.assertEqual(set(STATE_S),set(range(243)))
        for i in range(243):
            self.assertEqual(STATE_R[STATE_S[i]],STATE_S[STATE_R[i]])

    def test_action_transports_are_exact(self):
        for q in (ZERO,Q1,Q2,(1,)*9):
            self.assertTrue(positive_transport_checks(q))

    def test_word_composition_and_inverse(self):
        q=Q1;b=B(q)
        step={'A':A,'B':b,'a':inverse(A),'b':inverse(b)}
        self.assertEqual(word_map(step,'AaBb'),tuple(range(243)))
        self.assertEqual(word_map(step,'BBb'),b)

    def test_nonzero_reachability_and_zero_exception(self):
        self.assertEqual(reach_count(ZERO),81)
        self.assertEqual(reach_count(Q1),243)
        self.assertEqual(reach_count(Q2),243)

    def test_known_positive_state_mapping(self):
        target=S(Q1)
        mapping,trials=find_conjugacy(Q1,target,rooted=True)
        self.assertIsNotNone(mapping)
        self.assertEqual(mapping[0],0)
        self.assertEqual(len(set(mapping)),243)

    def test_known_negative_collision_in_old_four(self):
        self.assertEqual(old_four(Q1),old_four(Q2))
        self.assertNotEqual(fingerprint(Q1),fingerprint(Q2))
        mapping,trials=find_conjugacy(Q1,Q2)
        self.assertIsNone(mapping)
        self.assertEqual(trials,243)

    def test_orbit_preserves_all_four_features(self):
        for q in (ZERO,Q1,Q2,(1,)*9):
            signature=fingerprint(q)
            for b in orbit_RS(q):
                self.assertEqual(fingerprint(b),signature)

    def test_zero_unique_singleton(self):
        self.assertEqual(len(orbit_RS(ZERO)),1)
        self.assertEqual(len(orbit_RS((1,)*9)),2)

    def test_full_law_space_partition(self):
        from verify import classify
        proof=classify()
        self.assertEqual(proof['exact_conjugacy_classes'],1098)
        self.assertEqual(proof['independent_signature_counts'],[476,1048,1082,1098])
        self.assertEqual(proof['ordered_positive_law_pairs'],353957)
        self.assertEqual(proof['ordered_negative_law_pairs'],387066532)

    def test_earlier_702_family_survives(self):
        signatures=set()
        for a in product(range(3),repeat=3):
            for b in product(range(3),repeat=3):
                if not any(b):continue
                table=tuple((a[z]+b[z]*y)%3 for z,y in product(range(3),repeat=2))
                signatures.add(fingerprint(table))
        self.assertEqual(len(signatures),39)

    def test_exact_negative_fallback_independently(self):
        from verify_pairs import main
        proof=main()
        # main prints its result and is deterministic; its assertions constitute
        # 621 independent complete negative comparisons.
        # No extra positive class mergers are admitted.

if __name__=='__main__':unittest.main(verbosity=2)
