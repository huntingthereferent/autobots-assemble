"""Area-specific Continuity question replay and evidence-bound transitions."""
import json,unittest
from core import R,S
from continuity_classifier import ContinuityFifthCouplingClassifier as C
from continuity_classifier import UNKNOWN,NEGATIVE,POSITIVE
Q1=(0,0,0,0,0,1,0,1,1)
Q2=(0,0,0,0,1,1,0,1,0)
class ReplayTests(unittest.TestCase):
    def test_unknown_to_distinct_without_changing_question(self):
        first=C.start(Q1,Q2,1)
        self.assertEqual(first.status,UNKNOWN)
        after=C.resume(first.serialize(),2,expected_question_id=first.question_id)
        self.assertEqual(after.status,NEGATIVE)
        self.assertEqual(after.record['first_obstruction_feature'],2)
        self.assertEqual(after.question_id,first.question_id)
        self.assertEqual(after.record['observations'][:1],first.record['observations'])
    def test_conjugacy_needs_verified_positive_map(self):
        positive=C.start(Q1,R(Q1),1)
        self.assertEqual(positive.status,POSITIVE)
        self.assertEqual(len(set(positive.record['positive_full_AB_witness']['mapping'])),243)
    def test_negative_cannot_turn_positive(self):
        negative=C.start(Q1,Q2,2)
        self.assertEqual(C.resume(negative.serialize(),4).status,NEGATIVE)
    def test_tampered_snapshot_does_not_replay(self):
        initial=C.start(Q1,Q2,2)
        raw=json.loads(initial.serialize())
        raw['observations'][0]['source_histogram']=[[0,243]]
        with self.assertRaises(ValueError):C.replay(json.dumps(raw))
    def test_stronger_relation_cannot_be_forged(self):
        initial=C.start(Q1,Q2,1)
        raw=json.loads(initial.serialize())
        raw['question']['relation']='B_ONLY'
        with self.assertRaises(ValueError):C.replay(json.dumps(raw))
    def test_changed_question_anchor_rejected(self):
        initial=C.start(Q1,Q2,1)
        with self.assertRaises(ValueError):C.replay(initial.serialize(),expected_question_id='x')
    def test_budget_regression_rejected(self):
        initial=C.start(Q1,Q2,2)
        with self.assertRaises(ValueError):C.resume(initial.serialize(),1)
    def test_same_law_positive_map_and_replay(self):
        initial=C.start(Q1,Q1,4)
        self.assertEqual(initial.status,POSITIVE)
        self.assertEqual(initial.serialize(),C.replay(initial.serialize()).serialize())
if __name__=='__main__':unittest.main()
