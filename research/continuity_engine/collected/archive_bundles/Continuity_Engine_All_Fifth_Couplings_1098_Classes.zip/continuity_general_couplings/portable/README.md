# Portable finite A/B coupling-family classification

The contents are **standalone**. No GitHub checkout, network, third-party Python packages, or Continuity Engine runtime is needed to reproduce the exact finite mathematical census.

```bash
python verify.py
python verify_pairs.py
python -m unittest test_core test_classifier -v
```

- `core.py`: full 243-state A/B action, R/S transports, conjugacy solver, four complete linked-orbit invariants, and previous incomplete four-feature catalog.
- `verify.py`: classifies all 19,683 nine-entry fifth-coordinate tables using positive R/S orbits and four pairwise distinct exact invariants.
- `verify_pairs.py`: independently classifies ambiguous cases using the **old incomplete features** and complete origin-image tests; does not rely on the new complete fingerprints.
- `continuity_classifier.py`: replayable, typed, family-specific classification adapter. UNKNOWN is retained until an exact negative feature or positive R/S state-map witness is established.
- `test_core.py` and `test_classifier.py`: 21 exact tests, including the earlier 702-law subfamily (39 classes).
- `portable_classification.json`: machine-readable 1,098 positive-orbit representatives, histogram witnesses, and class counts.
- `portable_pair_checks.json`: results for all 621 exhaustive negative pair tests.

The result is scoped to the declared five-coordinate finite-field action. The repository is unchanged.
