# Continuity Engine — prototype research entry

**Identity:** Continuity Engine is the overarching research entry, not a synonym for Cyclic Action Engine or an automated research agent. Cyclic Action Engine remains an unchanged mathematical component.

**Current admitted area:** `cyclic_action/B`, following `B` on the explicitly declared finite invariant carrier. Other research areas must bring their own verified mathematical contracts; this entry does not claim to implement them.

**Evidence contract:** The `continuity_engine.v1` handoff stores the original question identifier, exact relation scope, serialized mathematical witnesses and an ordered chain of checkpoints. Re-entry reconstructs original laws, replays every checkpoint, verifies observation ancestry, checks the question identifier, and preserves terminal obstructions. SHA-256 digests detect incidental tampering, **not** adversarial replacement of the whole chain; external callers should anchor `question_id` separately.

**No mathematical claims added:** Underlying Cyclic Action statuses remain `UNKNOWN_BUDGET`, `DISTINGUISHED_B_ACTIONS`, and `B_ONLY_CONJUGACY_WITNESSED`. These refer only to the selected `B` action; they never prove simultaneous `A/B` conjugacy. The 81-state and 243-state experimental spaces are not physical spacetime dimensionality. The outer engine does not impose a new dimensional ceiling; the currently admitted component has its own finite-field and budget constraints.

**Entry:**

```python
from research.continuity_engine import ContinuityEngine
from work.arc_like_maze.cyclic_action_engine import CyclicActionEngine

engine = ContinuityEngine()
# source and target must be actual WindowProcess laws
carrier = CyclicActionEngine.fiber(5)
first = engine.start_cyclic(source, target, carrier, 8)
saved = first.serialize()
continued = engine.resume(saved, 9, expected_question_id=first.question_id)
assert continued.question_id == first.question_id
```

**Integration boundary:** The committed repository already has `runtime/continuity_pool.py`, a research question board, inverse construction and existing mathematical engines. This prototype does not replace their persistence mechanisms or conflate their artifacts. It does not import GAP, nauty, SageMath or ORB, nor claim their capabilities. Those are candidates for separately witnessed future admissions, not hidden runtime dependencies.

**Run:** `python -m unittest network.tests.test_research_continuity_engine -v` from the repository root.
