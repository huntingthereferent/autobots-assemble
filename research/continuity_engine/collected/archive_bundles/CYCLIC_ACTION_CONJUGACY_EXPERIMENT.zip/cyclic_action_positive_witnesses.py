"""Rooted and unrooted A/B conjugacies within the 26 z-only nonzero laws."""
from collections import Counter
from itertools import product
import json
from cyclic_action_simultaneous_conjugacy import System,STATES,F3,z_only,find_conjugacy,word_fixed
pairs=[((0,1,2),(1,0,2)),((0,0,1),(1,0,0)),((0,1,1),(1,0,1)),((1,1,2),(1,2,1)),((1,1,1),(2,2,2))]
for f,g in pairs:
    a,b=System.construct(z_only(f)),System.construct(z_only(g))
    full,trials=find_conjugacy(a,b)
    root,rtrials=find_conjugacy(a,b,rooted=True)
    print('PAIR',f,g,'full',full is not None,'rooted',root is not None,'origin->',STATES[full[0]] if full else None)
    if root:
      count=Counter((STATES[i][:4],STATES[root[i]][:4]) for i in range(243))
      print('   rooted_image_sample',[(STATES[i],STATES[root[i]]) for i in (0,1,2,3,9,27,81,162,240)])
# Exact criterion by two already-admitted action words, all 26 nonzero f.
fs=[f for f in product(F3,repeat=3) if any(f)]
match=0;equal_and_conj=0;unequal_and_obstructed=0;bad=[];rooted=0;unrooted=0
from cyclic_action_simultaneous_conjugacy import classify
# Precompute class labels via equivalence against five representatives.
reps=((0,0,1),(0,1,1),(0,1,2),(1,1,1),(1,1,2))
class_for={}
for f in fs:
 for k,rep in enumerate(reps):
    if find_conjugacy(System.construct(z_only(f)),System.construct(z_only(rep)))[0] is not None:
       class_for[f]=k;break
assert len(class_for)==26
sig={f:(word_fixed(System.construct(z_only(f)),'B'),word_fixed(System.construct(z_only(f)),'ABBBabbb')) for f in fs}
for f in fs:
 for g in fs:
    if sig[f]==sig[g]:
       match+=1
       if class_for[f]!=class_for[g]: bad.append((f,g))
       else: equal_and_conj+=1
    elif class_for[f]!=class_for[g]: unequal_and_obstructed+=1
    else: bad.append((f,g))
assert not bad
print('EXACT_INVARIANTS_PARTITION',Counter(sig.values()),'MATCHING_ORDERED_PAIRS',match,'DISTINCT_OBSTRUCTED_ORDERED_PAIRS',unequal_and_obstructed,'TOTAL',26**2)
# investigate rooted restriction within each class, expensive only class pairs 176.
for f in fs:
 for g in fs:
    if class_for[f]!=class_for[g]:continue
    out,_=find_conjugacy(System.construct(z_only(f)),System.construct(z_only(g)),rooted=True)
    rooted+=out is not None
    unrooted+=out is None
print('ROOTED_ORDERED_EQUIVALENCES',rooted,'UNROOTED_ONLY_PAIRS',unrooted,'full_equivalent',match)
with open('/mnt/data/cyclic_action_positive_witness_results.json','w') as h:json.dump({'groups':{str(k):v for k,v in Counter(class_for.values()).items()},'signature_classes':{str(k):v for k,v in Counter(sig.values()).items()},'same_class_ordered_pairs':match,'different_class_ordered_pairs':unequal_and_obstructed,'rooted_ordered_pairs':rooted,'unrooted_only_ordered_pairs':unrooted},h,indent=2)
