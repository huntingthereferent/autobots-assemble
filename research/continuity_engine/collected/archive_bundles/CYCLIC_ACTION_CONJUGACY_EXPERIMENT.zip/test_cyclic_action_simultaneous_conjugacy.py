"""Regression: complete z-only nonzero family classification and pointed scope."""
import unittest
from itertools import product
from collections import Counter
from cyclic_action_simultaneous_conjugacy import (
    F3,STATES, System, z_only, find_conjugacy, word_fixed, reach_count
)
REPS=((0,0,1),(0,1,1),(0,1,2),(1,1,1),(1,1,2))
Q={f:System.construct(z_only(f)) for f in product(F3,repeat=3) if any(f)}

def scale(x):return (*x[:4],(2*x[4])%3)

def pair_word(w,letters):
    def invert(p):
      inv=[0]*len(p)
      for i,v in enumerate(p):inv[v]=i
      return inv
    actions={'A':w.A,'B':w.B,'a':invert(w.A),'b':invert(w.B)}
    i=0
    for c in letters:i=actions[c][i]
    return STATES[i]

class FullActionTests(unittest.TestCase):
    def test_transitive_for_all_nonzero_z_only_laws(self):
        self.assertEqual(len(Q),26)
        self.assertTrue(all(reach_count(w)==243 for w in Q.values()))

    def test_scaling_preserves_full_AB_for_all_nonzero_laws(self):
        for f,w in Q.items():
            g=tuple((2*v)%3 for v in f)
            target=Q[g]
            for x,s in enumerate(STATES):
                mapped=STATES.index(scale(s))
                self.assertEqual(STATES[target.A[mapped]],scale(STATES[w.A[x]]))
                self.assertEqual(STATES[target.B[mapped]],scale(STATES[w.B[x]]))

    def test_five_exact_classes(self):
        classes=[]
        for rep in REPS:
            group=[]
            for f in Q:
                map_,_=find_conjugacy(Q[rep],Q[f])
                if map_ is not None: group.append(f)
            classes.append(group)
        self.assertEqual([len(g) for g in classes],[6,6,6,2,6])
        self.assertEqual(len(set(f for group in classes for f in group)),26)
        self.assertEqual(sum(map(len,classes)),26)

    def test_invariants_prove_all_cross_class_obstructions(self):
        sig={f:(word_fixed(w,'B'),word_fixed(w,'ABBBabbb')) for f,w in Q.items()}
        self.assertEqual(Counter(sig.values()),Counter({(36,45):6,(18,45):6,(18,27):6,(0,81):2,(0,45):6}))
        self.assertEqual(sum(sig[f]==sig[g] for f in Q for g in Q),148)
        self.assertEqual(sum(sig[f]!=sig[g] for f in Q for g in Q),528)

    def test_every_matching_pair_has_verified_full_conjugacy(self):
        sig={f:(word_fixed(w,'B'),word_fixed(w,'ABBBabbb')) for f,w in Q.items()}
        successes=0
        for f in Q:
            for g in Q:
                if sig[f]!=sig[g]:continue
                witness,_=find_conjugacy(Q[f],Q[g])
                self.assertIsNotNone(witness,(f,g))
                self.assertEqual(len(set(witness)),243)
                for i in range(243):
                    self.assertEqual(witness[Q[f].A[i]],Q[g].A[witness[i]])
                    self.assertEqual(witness[Q[f].B[i]],Q[g].B[witness[i]])
                successes+=1
        self.assertEqual(successes,148)

    def test_rooted_equivalences_exactly_scalar_pairs(self):
        sig={f:(word_fixed(w,'B'),word_fixed(w,'ABBBabbb')) for f,w in Q.items()}
        rooted=unrooted_only=0
        for f in Q:
            for g in Q:
                if sig[f]!=sig[g]:continue
                witness,_=find_conjugacy(Q[f],Q[g],rooted=True)
                expected=g in (f,tuple((2*v)%3 for v in f))
                self.assertEqual(witness is not None,expected,(f,g))
                if witness is None:unrooted_only+=1
                else:
                    rooted+=1
                    self.assertEqual(witness[0],0)
        self.assertEqual((rooted,unrooted_only),(52,96))

    def test_short_pointed_word_but_full_unrooted_conjugacy(self):
        f=(0,1,2);g=(1,0,2)
        self.assertEqual(pair_word(Q[f],'aBA'),(0,0,0,0,0))
        self.assertEqual(pair_word(Q[g],'aBA'),(0,0,0,0,1))
        h,_=find_conjugacy(Q[f],Q[g])
        self.assertIsNotNone(h)
        self.assertEqual(STATES[h[0]],(0,0,1,0,0))
        pointed,_=find_conjugacy(Q[f],Q[g],rooted=True)
        self.assertIsNone(pointed)

if __name__=='__main__':unittest.main(verbosity=2)
