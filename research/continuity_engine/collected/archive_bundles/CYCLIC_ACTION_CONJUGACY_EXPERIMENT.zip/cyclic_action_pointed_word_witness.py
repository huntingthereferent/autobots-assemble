"""Shortest rooted distinguishing action word for unrootedly conjugate z-only laws."""
from collections import deque
from cyclic_action_simultaneous_conjugacy import System,STATES,z_only,find_conjugacy
from cyclic_action_positive_witnesses import *

f=(0,1,2);g=(1,0,2)
src=System.construct(z_only(f));dst=System.construct(z_only(g))

def inv(p):
 out=[0]*len(p)
 for a,b in enumerate(p):out[b]=a
 return tuple(out)
source=dict(zip('ABab',(src.A,src.B,inv(src.A),inv(src.B))))
target=dict(zip('ABab',(dst.A,dst.B,inv(dst.A),inv(dst.B))))
root=(0,0);queue=deque([root]);parent={root:(None,'')}
inv_letter={'A':'a','a':'A','B':'b','b':'B'}
ending=None
while queue:
 a,b=queue.popleft()
 if (a==0)!=(b==0):ending=(a,b);break
 for letter in 'ABab':
  x,y=source[letter][a],target[letter][b]
  child=(x,y)
  if child not in parent:
   parent[child]=((a,b),letter);queue.append(child)
assert ending is not None
path=[];x=ending
while parent[x][0] is not None:
 prev,letter=parent[x];path.append(letter);x=prev
word=''.join(path[::-1])
print('EARLIEST_ROOTED_OBSTRUCTION',word,'LENGTH',len(word),'SOURCE',STATES[ending[0]],'TARGET',STATES[ending[1]],'PAIRS_EXPLORED',len(parent))
print('FULL_CONJUGACY_ORIGIN_TARGET',STATES[find_conjugacy(src,dst)[0][0]])
# Compact the word into group powers for readability, maybe first 12 chars.
# Check if a shorter length than len(word) has a rooted distinguisher (BFS ensures).
