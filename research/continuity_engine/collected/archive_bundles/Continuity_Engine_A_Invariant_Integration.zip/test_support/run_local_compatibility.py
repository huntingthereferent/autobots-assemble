"""Run package regression against explicitly test-only compatibility modules.

Standalone convenience check. This is NOT verification of GitHub's exact code.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import shutil
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parents[1]
STUBS = Path(__file__).parent / "test_only_modules"
TESTS = (
    "network.tests.test_research_continuity_engine",
    "network.tests.test_research_continuity_board_bridge",
    "network.tests.test_research_full_action_correspondence",
    "network.tests.test_research_cross_scope_handoff",
    "network.tests.test_research_a_invariant_action",
)


def main():
    with TemporaryDirectory(prefix="continuity-scope-local-test-") as tmp:
        root = Path(tmp)
        shutil.copytree(STUBS, root, dirs_exist_ok=True)
        for source in (PACKAGE / "research").glob("*.py"):
            dest = root / "research" / source.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
        for source in (PACKAGE / "network" / "tests").glob("*.py"):
            dest = root / "network" / "tests" / source.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        print("Testing with test-only reproductions of WindowProcess and CyclicActionEngine", flush=True)
        print("NOT an import test against the actual GitHub repository.", flush=True)
        subprocess.run((sys.executable, "-m", "unittest", *TESTS, "-v"),
                       cwd=root, env=env, check=True)


if __name__ == "__main__":
    main()
