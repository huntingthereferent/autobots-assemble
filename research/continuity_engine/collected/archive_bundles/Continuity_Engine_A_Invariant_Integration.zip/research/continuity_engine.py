"""Continuity Engine: explicit, replay-verifiable research handoffs.

Only the existing finite cyclic B-action is admitted by this version.
This layer preserves question identity, scope, and observation ancestry; it
neither invents mathematical laws nor claims automatic cross-area research.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any

from work.arc_like_maze.cyclic_action_engine import CyclicActionEngine
from work.arc_like_maze.window_two import WindowProcess
from research.a_invariant_action import AInvariantAction, RELATION as A_SCOPE
from research.simultaneous_action_correspondence import (
    FullActionCorrespondence, RELATION as FULL_AB_SCOPE,
)

SCHEMA = "continuity_engine.v1"
CYCLIC = "cyclic_action/B"
A_ONLY = "cyclic_action/A"
SCOPE = "B_ONLY_ON_DECLARED_INVARIANT_CARRIER"
FULL_AB = "finite_action/AB"


def _wire(obj: Any) -> str:
    return json.dumps(obj, separators=(",", ":"), sort_keys=True)


def _hash(content: str) -> str:
    return sha256(content.encode("utf-8")).hexdigest()


def _entry(payload: str, parent: str | None) -> dict:
    return {"payload": payload, "sha256": _hash(payload), "previous_sha256": parent}


@dataclass(frozen=True)
class ContinuityRecord:
    """Immutable serialized handoff. Nested mathematical witnesses are replayed."""

    area: str
    question_id: str
    scope: str
    snapshots: tuple[dict, ...]

    @property
    def status(self) -> str:
        return json.loads(self.snapshots[-1]["payload"])["status"]

    @property
    def powers_examined(self) -> int:
        if self.area not in (CYCLIC, A_ONLY):
            raise ValueError("single-generator power count is undefined for a full A/B correspondence")
        return len(json.loads(self.snapshots[-1]["payload"])["observations"])

    @property
    def witness(self) -> list:
        reading = json.loads(self.snapshots[-1]["payload"])
        return (reading["B_bijection"] if self.area == CYCLIC else
                reading["A_bijection"] if self.area == A_ONLY else reading["AB_bijection"])

    @property
    def research_question(self) -> dict:
        return json.loads(self.snapshots[-1]["payload"])["question"]

    def serialize(self) -> str:
        return _wire({"schema": SCHEMA, "area": self.area,
                      "question_id": self.question_id, "scope": self.scope,
                      "snapshots": list(self.snapshots)})


class ContinuityEngine:
    """Evidence-preserving entry/continuation; no autonomous scheduling.

    New areas require separate mathematical adapters with equally strong
    replay contracts. Unsupported areas are rejected, not silently approximated.
    """

    def __init__(self) -> None:
        self._cyclic = CyclicActionEngine()
        self._a = AInvariantAction()
        self._full = FullActionCorrespondence()

    @staticmethod
    def supported_areas() -> tuple[str, ...]:
        return (CYCLIC, A_ONLY, FULL_AB)

    def start_cyclic(self, source: WindowProcess, target: WindowProcess,
                     carrier: tuple[tuple[int, ...], ...],
                     max_power: int) -> ContinuityRecord:
        result = self._cyclic.start(source, target, carrier, max_power)
        return ContinuityRecord(CYCLIC, result.record["question_id"],
                                SCOPE, (_entry(result.serialize(), None),))

    def start_a_invariant(self, source: WindowProcess, target: WindowProcess,
                          carrier: tuple[tuple[int, ...], ...],
                          max_power: int) -> ContinuityRecord:
        result = self._a.start(source, target, carrier, max_power)
        return ContinuityRecord(A_ONLY, result.record["question_id"],
                                A_SCOPE, (_entry(result.serialize(), None),))

    def start_full_action(self, source: WindowProcess, target: WindowProcess,
                          dimension: int, max_loops: int, *, rooted=False,
                          max_states=1000) -> ContinuityRecord:
        result = self._full.start(source, target, dimension, max_loops,
                                  rooted=rooted, max_states=max_states)
        return ContinuityRecord(FULL_AB, result.record["question_id"],
                                FULL_AB_SCOPE, (_entry(result.serialize(), None),))

    def verify(self, serialized: str, *,
               expected_question_id: str | None = None) -> ContinuityRecord:
        """Replay *each* recorded checkpoint against its original laws."""
        try:
            raw = json.loads(serialized)
        except (TypeError, json.JSONDecodeError) as exc:
            raise ValueError("invalid research handoff") from exc
        if (not isinstance(raw, dict) or
            set(raw) != {"schema", "area", "question_id", "scope", "snapshots"} or
            raw["schema"] != SCHEMA or
            (raw["area"], raw["scope"]) not in
              {(CYCLIC, SCOPE), (A_ONLY, A_SCOPE), (FULL_AB, FULL_AB_SCOPE)} or
            type(raw["question_id"]) is not str or
            (expected_question_id is not None and
             raw["question_id"] != expected_question_id)):
            raise ValueError("unsupported area, schema, scope, or anchored question")
        entries = raw["snapshots"]
        if not isinstance(entries, list) or not entries:
            raise ValueError("empty research history")
        previous_hash = None
        previous_payload = None
        previous_budget = 0
        for entry in entries:
            if (not isinstance(entry, dict) or
                set(entry) != {"payload", "sha256", "previous_sha256"} or
                not isinstance(entry["payload"], str) or
                entry["sha256"] != _hash(entry["payload"]) or
                entry["previous_sha256"] != previous_hash):
                raise ValueError("invalid observation ancestry")
            try:
                observed = json.loads(entry["payload"])
                key = "max_power" if raw["area"] in (CYCLIC, A_ONLY) else "max_loops"
                budget = observed[key]
                if type(budget) is not int or budget < previous_budget:
                    raise ValueError("continuation budget was reversed")
                if raw["area"] == CYCLIC:
                    replayed = self._cyclic.resume(entry["payload"], budget,
                        expected_question_id=raw["question_id"])
                elif raw["area"] == A_ONLY:
                    replayed = self._a.replay(entry["payload"],
                        expected_question_id=raw["question_id"])
                else:
                    replayed = self._full.replay(entry["payload"],
                        expected_question_id=raw["question_id"])
            except (KeyError, TypeError, json.JSONDecodeError) as exc:
                raise ValueError("invalid nested mathematical witness") from exc
            if replayed.serialize() != entry["payload"]:
                raise ValueError("saved record disagrees with replay")
            if observed["question"]["relation"] != raw["scope"]:
                raise ValueError("mathematical question scope changed")
            if previous_payload is not None:
                previous = json.loads(previous_payload)
                old = previous["observations"]
                if observed["question"] != previous["question"] or \
                   observed["observations"][:len(old)] != old or \
                   len(observed["observations"]) < len(old):
                    raise ValueError("saved mathematical ancestry was replaced")
            previous_budget = budget
            previous_payload = entry["payload"]
            previous_hash = entry["sha256"]
        return ContinuityRecord(raw["area"], raw["question_id"],
                                raw["scope"], tuple(entries))

    def resume(self, serialized: str, max_power: int, *,
               expected_question_id: str | None = None) -> ContinuityRecord:
        prior = self.verify(serialized, expected_question_id=expected_question_id)
        earlier = json.loads(prior.snapshots[-1]["payload"])
        budget_key = "max_power" if prior.area in (CYCLIC, A_ONLY) else "max_loops"
        if type(max_power) is not int or max_power < earlier[budget_key]:
            raise ValueError("new continuation budget must not decrease")
        if prior.area == CYCLIC:
            result = self._cyclic.resume(prior.snapshots[-1]["payload"], max_power,
                                         expected_question_id=prior.question_id)
        elif prior.area == A_ONLY:
            result = self._a.resume(prior.snapshots[-1]["payload"], max_power,
                                    expected_question_id=prior.question_id)
        else:
            result = self._full.resume(prior.snapshots[-1]["payload"], max_power,
                                       expected_question_id=prior.question_id)
        payload = result.serialize()
        if payload == prior.snapshots[-1]["payload"]:
            return prior
        candidate = ContinuityRecord(prior.area, prior.question_id,
                                     prior.scope, prior.snapshots +
                                     (_entry(payload, prior.snapshots[-1]["sha256"]),))
        # Fail closed if a component ever returns a witness that cannot replay.
        return self.verify(candidate.serialize(),
                           expected_question_id=prior.question_id)
