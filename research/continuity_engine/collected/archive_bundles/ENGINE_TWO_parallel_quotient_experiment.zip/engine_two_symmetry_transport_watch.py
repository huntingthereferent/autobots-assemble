"""A second WATCH over an E2-constructed law conjugacy.

Question: does a certified H mapping A/B of Q_s to those of Q_t ALSO
intertwine the *particular* canonical lower selected symmetries C_Q?

For q2=zero the canonical selected correction is zero, so
C_Q(u,v,z,y,tail)=(u,v,z+1,y+Q(z+alpha(v))-Q(0),tail).

No assumption says H C_source = C_target H. If it fails, the map
H C_source H^-1 is nevertheless a valid centralizer of the target A/B.
The failure is about the chosen symmetry selection, NOT about A/B
conjugacy, and does NOT rule out an alternative intertwiner.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from engine_two_quotient_conjugacy import (
    F3, QSPACE,ALPHA,step,research,PotentialConjugacy,State,Quotient,
)


def canonical_symmetry(x:State,Q:Quotient)->State:
    u,v,z,y,*tail=x
    w=(z+ALPHA[v])%3
    return (u,v,(z+1)%3,(y+Q[w]-Q[0])%3,*tail)


@dataclass(frozen=True)
class TransportReading:
    source:Quotient
    target:Quotient
    status:str
    total_states:int
    differences:int
    first_witness:tuple[State,State,State]|None
    omitted_claims:tuple[str,...]

    def summary(self)->dict:
        return {"source":self.source,"target":self.target,"status":self.status,
                "total_states":self.total_states,"different_states":self.differences,
                "first_witness":self.first_witness,
                "omitted_claims":self.omitted_claims}


def watch_selected_transport(H:PotentialConjugacy,depth:int=4)->TransportReading:
    """Compare an already witnessed law conjugacy with *chosen* C_Q maps."""
    if depth<4:raise ValueError("d>=4 required")
    differences=0;first=None
    for x in product(F3,repeat=depth):
        a=H.map(canonical_symmetry(x,H.source))
        b=canonical_symmetry(H.map(x),H.target)
        if a!=b:
            differences+=1
            if first is None:first=(x,a,b)
        # C_s and C_t genuinely commute with both generators.
        for g in 'AB':
            assert canonical_symmetry(step(x,g,H.source),H.source)==step(canonical_symmetry(x,H.source),g,H.source)
            y=H.map(x)
            assert canonical_symmetry(step(y,g,H.target),H.target)==step(canonical_symmetry(y,H.target),g,H.target)
            # H C_s H^-1 is also a centralizer of target A/B.
            def transported(t):return H.map(canonical_symmetry(H.inverse_map(t),H.source))
            assert transported(step(y,g,H.target))==step(transported(y),g,H.target)
    return TransportReading(H.source,H.target,
        "CHOSEN_SYMMETRIES_INTERTWINED" if not differences else "LAW_CONJUGACY_ONLY_SELECTED_SYMMETRY_NOT_INTERTWINED",
        3**depth,differences,first,
        ("a mismatch is not a failure of the underlying A/B conjugacy",
         "a mismatch does not prohibit another valid intertwiner",
         "only the canonical zero-q2 correction selection was compared"))


def audit_selected_transport()->dict:
    preserving=failing=0
    examples={}
    for src in QSPACE:
        for dst in QSPACE:
            r=research(src,dst)
            if not isinstance(r.witness,PotentialConjugacy):continue
            result=watch_selected_transport(r.witness,4)
            if result.differences:failing+=1
            else:preserving+=1
            if (src,dst) in (((0,0,0),(0,1,2)),((0,0,0),(1,0,2))):
                examples[f"{src}->{dst}"]=result.summary()
    assert (preserving,failing)==(135,270)
    return {"scoped_conjugate_pairs":405,
            "constructed_conjugacies_intertwining_chosen_C":preserving,
            "constructed_conjugacies_not_intertwining_chosen_C":failing,
            "examples":examples,
            "scope":"only normalized H_lambda,f from companion conjugacy experiment; canonical q2=0 chosen C",
            "status":"SEPARATE_SYMMETRY_SELECTION_WITNESSES"}


if __name__=='__main__':
    import json
    print(json.dumps(audit_selected_transport(),indent=2))
