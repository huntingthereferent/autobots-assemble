"""Focused exhaustive scope-gated checks: Engine 2's constructed conjugacy space."""
import unittest
from itertools import product

from engine_two_quotient_conjugacy import (
    QSPACE, F3, E, inverse, step, trace,
    solve_potential, PotentialConjugacy, EquationObstruction,
    fixed_B_power, B_power, research, classify_declared_family,
)

Q_ZERO=(0,0,0)
Q_ZERO_OTHER=(0,1,2)
Q_ONE=(0,0,1)
Q_TWO=(0,0,2)


class ConstructedResearchSpaceTests(unittest.TestCase):
    def test_01_all_27_quotients_and_trace_partition(self):
        self.assertEqual(len(QSPACE),27)
        self.assertEqual([sum(trace(Q)==i for Q in QSPACE) for i in F3],[9,9,9])

    def test_02_native_A_B_and_inverses_replay(self):
        for Q in (Q_ZERO,Q_ZERO_OTHER,Q_ONE,Q_TWO):
            for x in product(F3,repeat=5):
                for action in 'AB':
                    self.assertEqual(inverse(step(x,action,Q),action,Q),x)
                    self.assertEqual(step(inverse(x,action,Q),action,Q),x)

    def test_03_fixed_B_watch_not_promoted_to_conjugacy(self):
        self.assertEqual(fixed_B_power(Q_ZERO,1,5),fixed_B_power(Q_ONE,1,5))
        self.assertEqual(fixed_B_power(Q_ZERO,1,5),0)
        self.assertEqual(fixed_B_power(Q_ZERO,3,5),243)
        self.assertEqual(fixed_B_power(Q_ONE,3,5),0)
        r=research(Q_ZERO,Q_ONE)
        self.assertEqual(r.status,'FULL_STATE_OBSTRUCTED_BY_BBB')
        self.assertIsNone(r.witness)
        self.assertIn('Fix(B^3)',r.record[-1])

    def test_04_zero_trace_pair_constructs_rooted_full_state_map(self):
        r=research(Q_ZERO,Q_ZERO_OTHER)
        self.assertEqual(r.status,'ROOTED_FULL_CONJUGACY_CONSTRUCTED')
        self.assertEqual(r.witness.scale,1)
        self.assertEqual(r.witness.potential,(0,0,1,0,1,0,0,1,0))
        self.assertTrue(r.witness.exhaustive(4))
        self.assertTrue(r.witness.exhaustive(5))
        self.assertTrue(r.witness.exhaustive(6))

    def test_05_nonzero_different_trace_scales_instead_of_false_wall(self):
        r=research(Q_ONE,Q_TWO)
        self.assertEqual(r.status,'ROOTED_FULL_CONJUGACY_CONSTRUCTED')
        self.assertEqual(r.witness.scale,2)
        self.assertEqual(r.witness.potential,(0,)*9)
        self.assertTrue(r.witness.exhaustive(5))

    def test_06_additive_only_grammar_can_hit_real_wall_without_global_nonconjugacy(self):
        wrong=solve_potential(Q_ONE,Q_TWO,1)
        self.assertIsInstance(wrong,EquationObstruction)
        self.assertTrue(wrong.replay())
        self.assertNotEqual(wrong.summary()['first_voltage'],wrong.summary()['second_voltage'])
        self.assertIsInstance(solve_potential(Q_ONE,Q_TWO,2),PotentialConjugacy)

    def test_07_cross_trace_zero_nonzero_has_full_state_word_obstruction(self):
        for a,b in ((Q_ZERO,Q_ONE),(Q_ONE,Q_ZERO),(Q_ZERO_OTHER,Q_TWO)):
            r=research(a,b)
            self.assertEqual(r.status,'FULL_STATE_OBSTRUCTED_BY_BBB')
            self.assertNotEqual(r.bbb_fixed_before,r.bbb_fixed_after)
            self.assertEqual(r.b_fixed_before,r.b_fixed_after)

    def test_08_identical_law_gives_identity_with_earned_witness(self):
        for Q in QSPACE:
            r=research(Q,Q)
            self.assertEqual(r.status,'ROOTED_FULL_CONJUGACY_CONSTRUCTED')
            self.assertEqual(r.witness.scale,1)
            self.assertEqual(r.witness.potential,(0,)*9)

    def test_09_all_729_pairs_have_replayed_native_classification(self):
        cert=classify_declared_family()
        self.assertEqual((cert['ordered_pairs'],cert['rooted_full_conjugacies'],
                          cert['full_state_obstructed_by_BBB'],cert['unresolved_pairs']),
                         (729,405,324,0))
        self.assertEqual(cert['rooted_class_sizes'],(9,18))

    def test_10_word_B_cubed_is_identical_or_translates_y_by_native_trace(self):
        for Q in QSPACE:
            for x in product(F3,repeat=4):
                expected=x[:3]+((x[3]+trace(Q))%3,)
                self.assertEqual(B_power(x,Q,3),expected)

    def test_11_admissible_maps_compose_with_exact_normalized_potentials(self):
        a=(0,0,1);b=(0,1,0);c=(0,0,2)
        first=research(a,b).witness
        second=research(b,c).witness
        self.assertIsInstance(first,PotentialConjugacy)
        self.assertIsInstance(second,PotentialConjugacy)
        scale=(second.scale*first.scale)%3
        potential=tuple((second.scale*x+y)%3
                        for x,y in zip(first.potential,second.potential))
        composed=PotentialConjugacy(a,c,scale,potential)
        for x in product(F3,repeat=5):
            self.assertEqual(composed.map(x),second.map(first.map(x)))
        self.assertTrue(composed.exhaustive(4))

    def test_12_higher_zero_tail_projection_preserved_by_conjugacy(self):
        a=research(Q_ZERO,Q_ZERO_OTHER).witness
        for x in product(F3,repeat=6):
            self.assertEqual(a.map(x)[:-1],a.map(x[:-1]))
            for letter in 'AB':
                self.assertEqual(step(x,letter,Q_ZERO)[:-1],step(x[:-1],letter,Q_ZERO))
                self.assertEqual(step(x,letter,Q_ZERO)[4:],x[4:])

    def test_13_corrupt_potential_rejected_before_any_equivalence_claim(self):
        cert=research(Q_ZERO,Q_ZERO_OTHER).witness
        tampered=list(cert.potential)
        tampered[3]=(tampered[3]+1)%3
        with self.assertRaises(ValueError):
            PotentialConjugacy(Q_ZERO,Q_ZERO_OTHER,1,tuple(tampered))
        with self.assertRaises(ValueError):
            PotentialConjugacy(Q_ZERO,Q_ZERO_OTHER,0,cert.potential)

    def test_14_invalid_input_never_silently_changes_grammar(self):
        with self.assertRaises(ValueError):
            research((0,0,True),Q_ZERO)
        with self.assertRaises(ValueError):
            research((0,0,0,0),Q_ZERO)
        with self.assertRaises(ValueError):
            step((0,0,0),'B',Q_ZERO)
        with self.assertRaises(ValueError):
            solve_potential(Q_ZERO,Q_ZERO,3)


class SymmetryTransportTests(unittest.TestCase):
    def test_15_selected_symmetry_transport_is_a_separate_watch(self):
        from engine_two_symmetry_transport_watch import watch_selected_transport
        correct=watch_selected_transport(research((0,0,0),(0,1,2)).witness)
        self.assertEqual(correct.status,'CHOSEN_SYMMETRIES_INTERTWINED')
        mismatched=watch_selected_transport(research((0,0,0),(1,0,2)).witness)
        self.assertEqual(mismatched.status,'LAW_CONJUGACY_ONLY_SELECTED_SYMMETRY_NOT_INTERTWINED')
        self.assertEqual(mismatched.first_witness,
                         ((0,0,0,0),(0,0,1,1),(0,0,1,0)))

    def test_16_full_405_conjugacy_symmetry_transport_partition(self):
        from engine_two_symmetry_transport_watch import audit_selected_transport
        r=audit_selected_transport()
        self.assertEqual((r['scoped_conjugate_pairs'],
                          r['constructed_conjugacies_intertwining_chosen_C'],
                          r['constructed_conjugacies_not_intertwining_chosen_C']),
                         (405,135,270))

    def test_17_independent_full_graph_classifier_recovers_two_classes(self):
        from engine_two_quotient_independent_audit import audit
        report=audit()
        self.assertEqual((report['class_sizes'],report['equivalent_ordered_pairs'],
                          report['inequivalent_ordered_pairs']),((9,18),405,324))


if __name__=="__main__":
    unittest.main(verbosity=2)
