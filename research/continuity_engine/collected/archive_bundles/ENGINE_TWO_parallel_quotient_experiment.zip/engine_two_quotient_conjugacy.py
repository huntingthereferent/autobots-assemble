"""Engine 2 parallel Boundary Math: construct a space of conjugacy witnesses.

Declared scope: triangular F3 A/B systems with the *fixed* nonconstant
q0=(0,1,2,0,2,1,1,1,1), gain=1, fourth-coordinate offsets k=0,
fifth-coordinate coupling q2=0, and zero tail. Only Q:F3->F3 varies.

For a proposed map H(u,v,z,y,tail)=(u,v,z,lambda*y+f(v,z),tail),
intertwining B is equivalent to 27 equations in the nine unknown f(v,z):

 f(E_u(v,z))-f(v,z) = Q_target(z+alpha(v)) - lambda*Q_source(z+alpha(v))

where E_u(v,z)=(v+u+1,z+q0(u,v)), alpha=(0,1,1).
A commutes automatically because f is independent of u. Solutions are
normalized by f(0,0)=0; lambda is a unit in F3. A cycle inconsistency is
a WALL to this candidate-map grammar, not by itself a nonconjugacy theorem.

This is an exact finite-field construction. Once a solution is established,
its formula works for all dimensions >=4 in this *specified zero-tail family*.
It is not a general equivalence decision procedure or ARC gameplay.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from itertools import product
from typing import Literal

F3 = (0, 1, 2)
QSPACE = tuple(product(F3, repeat=3))
Q0 = (0, 1, 2, 0, 2, 1, 1, 1, 1)
ALPHA = (0, 1, 1)
LOWER = tuple(product(F3, repeat=2))
INDEX = {p: i for i, p in enumerate(LOWER)}
State = tuple[int, ...]
Point = tuple[int, int]
Quotient = tuple[int, int, int]


def check_Q(Q: Quotient) -> None:
    if type(Q) is not tuple or len(Q) != 3 or any(type(a) is not int or a not in F3 for a in Q):
        raise ValueError("Q must be a three-entry F3 table")


def trace(Q: Quotient) -> int:
    check_Q(Q)
    return sum(Q) % 3


def step(x: State, action: str, Q: Quotient) -> State:
    check_Q(Q)
    if len(x) < 4 or any(type(a) is not int or a not in F3 for a in x):
        raise ValueError("state must have at least four F3 coordinates")
    u,v,z,y,*tail=x
    if action == "A":
        return ((u+1)%3,v,z,y,*tail)
    if action != "B":
        raise ValueError("A and B only")
    return (u,(v+u+1)%3,(z+Q0[3*u+v])%3,
            (y+Q[(z+ALPHA[v])%3])%3,*tail)


def inverse(x: State, action: str, Q: Quotient) -> State:
    check_Q(Q)
    if len(x) < 4 or any(type(a) is not int or a not in F3 for a in x):
        raise ValueError("state must have at least four F3 coordinates")
    u,v,z,y,*tail=x
    if action == "A":
        return ((u-1)%3,v,z,y,*tail)
    if action != "B":
        raise ValueError("A and B only")
    v0=(v-u-1)%3
    z0=(z-Q0[3*u+v0])%3
    return (u,v0,z0,(y-Q[(z0+ALPHA[v0])%3])%3,*tail)


def E(p: Point, u: int) -> Point:
    v,z=p
    return ((v+u+1)%3,(z+Q0[3*u+v])%3)


def E_inverse(p: Point, u: int) -> Point:
    v,z=p
    before_v=(v-u-1)%3
    return before_v,(z-Q0[3*u+before_v])%3


@dataclass(frozen=True)
class Edge:
    u: int
    direction: Literal[1, -1]


def replay_path(source: Quotient, target: Quotient, scale: int,
                path: tuple[Edge, ...]) -> tuple[Point, int]:
    """Replay a signed lower-coordinate path and its exact potential voltage."""
    check_Q(source); check_Q(target)
    if scale not in (1,2):raise ValueError("scale must be a unit")
    p=(0,0)
    voltage=0
    for edge in path:
        if edge.u not in F3 or edge.direction not in (1,-1):
            raise ValueError("unadmitted path edge")
        before=p if edge.direction==1 else E_inverse(p,edge.u)
        w=(before[1]+ALPHA[before[0]])%3
        delta=(target[w]-scale*source[w])%3
        voltage=(voltage+edge.direction*delta)%3
        p=E(p,edge.u) if edge.direction==1 else before
    return p,voltage


@dataclass(frozen=True)
class EquationObstruction:
    """Two paths from (0,0) to the SAME point with conflicting voltages."""
    source: Quotient
    target: Quotient
    scale: int
    first: tuple[Edge,...]
    second: tuple[Edge,...]

    def replay(self) -> bool:
        p,a=replay_path(self.source,self.target,self.scale,self.first)
        q,b=replay_path(self.source,self.target,self.scale,self.second)
        return p==q and a!=b

    def summary(self) -> dict:
        return {"end":replay_path(self.source,self.target,self.scale,self.first)[0],
                "first_voltage":replay_path(self.source,self.target,self.scale,self.first)[1],
                "second_voltage":replay_path(self.source,self.target,self.scale,self.second)[1],
                "first_length":len(self.first),"second_length":len(self.second)}


@dataclass(frozen=True)
class PotentialConjugacy:
    source: Quotient
    target: Quotient
    scale: int
    potential: tuple[int, ...]

    def __post_init__(self) -> None:
        check_Q(self.source);check_Q(self.target)
        if self.scale not in (1,2) or len(self.potential)!=9:
            raise ValueError("unit scale and complete nine-value potential required")
        if any(type(a) is not int or a not in F3 for a in self.potential) or self.potential[0]!=0:
            raise ValueError("normalized F3 potential required")
        for p in LOWER:
            for u in F3:
                w=(p[1]+ALPHA[p[0]])%3
                if (self.potential[INDEX[E(p,u)]]-self.potential[INDEX[p]])%3 != (self.target[w]-self.scale*self.source[w])%3:
                    raise ValueError("a native compatibility equation fails")

    def map(self, x:State) -> State:
        if len(x)<4:raise ValueError("dimension >=4 required")
        u,v,z,y,*tail=x
        return (u,v,z,(self.scale*y+self.potential[INDEX[(v,z)]])%3,*tail)

    def inverse_map(self,x:State)->State:
        if len(x)<4:raise ValueError("dimension >=4 required")
        u,v,z,y,*tail=x
        inv=self.scale  # F3 units 1^-1=1, 2^-1=2
        return (u,v,z,(inv*(y-self.potential[INDEX[(v,z)]]))%3,*tail)

    def exhaustive(self,depth:int=4)->bool:
        if type(depth) is not int or depth<4:
            raise ValueError("dimension >=4 required")
        for x in product(F3,repeat=depth):
            y=self.map(x)
            if self.inverse_map(y)!=x or self.map(self.inverse_map(x))!=x:
                return False
            for a in "AB":
                if self.map(step(x,a,self.source)) != step(y,a,self.target):
                    return False
                if self.map(inverse(x,a,self.source)) != inverse(y,a,self.target):
                    return False
        return self.map((0,)*depth)==(0,)*depth

    def summary(self)->dict:
        return {"source":self.source,"target":self.target,"scale":self.scale,
                "potential_rows":[self.potential[j*3:(j+1)*3] for j in range(3)],
                "root_preserving":True,
                "all_depth_scope":"d>=4, with the stated zero fifth coupling and zero tail"}


def solve_potential(source:Quotient,target:Quotient,scale:int)->PotentialConjugacy|EquationObstruction:
    check_Q(source);check_Q(target)
    if type(scale) is not int or scale not in (1,2):
        raise ValueError("scale must be an F3 unit")
    adjacency={p:[] for p in LOWER}
    for p in LOWER:
        for u in F3:
            q=E(p,u)
            w=(p[1]+ALPHA[p[0]])%3
            d=(target[w]-scale*source[w])%3
            adjacency[p].append((q,d,Edge(u,1)))
            adjacency[q].append((p,-d%3,Edge(u,-1)))
    values={(0,0):0}
    paths={(0,0):()}
    queue=deque([(0,0)])
    while queue:
        p=queue.popleft()
        for q,d,e in adjacency[p]:
            candidate=(values[p]+d)%3
            proposal=paths[p]+(e,)
            if q in values:
                if values[q]!=candidate:
                    obstruction=EquationObstruction(source,target,scale,paths[q],proposal)
                    assert obstruction.replay()
                    return obstruction
            else:
                values[q]=candidate
                paths[q]=proposal
                queue.append(q)
    if len(values)!=9:
        raise AssertionError("lower-space connectedness assumption failed")
    return PotentialConjugacy(source,target,scale,tuple(values[p] for p in LOWER))


def B_power(x:State,Q:Quotient,n:int)->State:
    for _ in range(n):x=step(x,'B',Q)
    return x


def fixed_B_power(Q:Quotient,n:int,depth:int=4)->int:
    return sum(B_power(x,Q,n)==x for x in product(F3,repeat=depth))


@dataclass(frozen=True)
class ResearchReading:
    source: Quotient
    target: Quotient
    status: str
    b_fixed_before:int
    b_fixed_after:int
    bbb_fixed_before:int
    bbb_fixed_after:int
    witness:PotentialConjugacy|EquationObstruction|None
    record:tuple[str,...]

    def summary(self)->dict:
        return {"source":self.source,"target":self.target,"status":self.status,
                "fixed_B":(self.b_fixed_before,self.b_fixed_after),
                "fixed_BBB":(self.bbb_fixed_before,self.bbb_fixed_after),
                "watch_history":self.record,
                "witness":(self.witness.summary() if self.witness is not None else None)}


def research(source:Quotient,target:Quotient)->ResearchReading:
    """Select next supported WATCH under the question: labeled full-state conjugacy.

    An equal fixed-word count is inconclusive, not an earned equivalence.
    A differing fixed-word count is a full-state conjugacy obstruction.
    Equal counts admit a bounded construction search for a verified map.
    """
    check_Q(source);check_Q(target)
    b1=fixed_B_power(source,1);b2=fixed_B_power(target,1)
    c1=fixed_B_power(source,3);c2=fixed_B_power(target,3)
    record=["WATCH Fix(B): equal count is only a scoped zero, never equivalence"]
    if b1!=b2:
        return ResearchReading(source,target,"FULL_STATE_OBSTRUCTED_BY_B",b1,b2,c1,c2,None,tuple(record))
    record.append("WATCH Fix(B^3): period-3 is the native trace-derived next word")
    if c1!=c2:
        return ResearchReading(source,target,"FULL_STATE_OBSTRUCTED_BY_BBB",b1,b2,c1,c2,None,tuple(record))
    record.append("construct candidate bijections H_lambda,f; compatibility = 27 equations in nine values")
    s,t=trace(source),trace(target)
    scales=(1,2) if s==0 and t==0 else ((t*pow(s,-1,3))%3,) if s and t else ()
    for scale in scales:
        trial=solve_potential(source,target,scale)
        if isinstance(trial,PotentialConjugacy):
            assert trial.exhaustive(4)
            return ResearchReading(source,target,"ROOTED_FULL_CONJUGACY_CONSTRUCTED",b1,b2,c1,c2,trial,
                                   tuple(record+["verified A/B forward and inverse squares on F3^4, all-depth zero-tail argument"]))
    return ResearchReading(source,target,"UNKNOWN_BEYOND_CANDIDATE_GRAMMAR",b1,b2,c1,c2,
                          solve_potential(source,target,1),
                          tuple(record+["constructed candidate grammar exhausted; no global nonconjugacy inferred"]))


def classify_declared_family()->dict:
    rooted=obstructed=unknown=0
    representatives={}
    for s in QSPACE:
        for t in QSPACE:
            r=research(s,t)
            if r.status=="ROOTED_FULL_CONJUGACY_CONSTRUCTED":rooted+=1
            elif r.status=="FULL_STATE_OBSTRUCTED_BY_BBB":obstructed+=1
            else:unknown+=1
            if (s,t) in (((0,0,0),(0,1,2)),((0,0,0),(0,0,1)),((0,0,1),(0,0,2))):
                representatives[f"{s}->{t}"]=r.summary()
    assert (rooted,obstructed,unknown)==(405,324,0)
    return {"declared_quotients":27,"ordered_pairs":729,
            "rooted_full_conjugacies":rooted,"full_state_obstructed_by_BBB":obstructed,
            "unresolved_pairs":unknown,"rooted_class_sizes":(9,18),
            "representative_witnesses":representatives,
            "scope":"gain=1, q0 fixed, k=0, fifth q2=0, zero-tail; valid all depths >=4",
            "evidence":"native fixed-BBB invariants and explicit normalized affine-gauge conjugacies"}


if __name__=="__main__":
    import json
    print(json.dumps(classify_declared_family(),indent=2))
