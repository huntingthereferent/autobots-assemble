"""Independent finite-state rooted-conjugacy audit for the 27-Q family.

Does not import the research kernel or its potential solver. Each A/B graph
is constructed directly on F3^4 and classified as a rooted, labeled graph;
all components off the distinguished root must also match. This is a
separate finite-depth check, not an all-depth theorem by itself.
"""
from collections import Counter
from itertools import product

FIELD=(0,1,2)
LOWER=(0,1,2,0,2,1,1,1,1)
ALPHA=(0,1,1)
ZERO=(0,0,0,0)
STATES=tuple(product(FIELD,repeat=4))
QS=tuple(product(FIELD,repeat=3))


def act(x,a,Q):
    u,v,z,y=x
    if a=='A':return ((u+1)%3,v,z,y)
    if a=='B':return (u,(v+u+1)%3,(z+LOWER[3*u+v])%3,(y+Q[(z+ALPHA[v])%3])%3)
    raise ValueError(a)


def bfs(Q,root):
    positions={root:0};queue=[root];edges=[]
    for p in queue:
        for a in 'AB':
            next_point=act(p,a,Q)
            if next_point not in positions:
                positions[next_point]=len(queue)
                queue.append(next_point)
            edges.append(positions[next_point])
    return (tuple(edges),tuple(queue))


def signature(Q):
    """Rooted component first, unmarked components canonically sorted."""
    seen=set();components=[];root_signature=None
    for x in STATES:
        if x in seen:continue
        _,orbit=bfs(Q,x)
        seen.update(orbit)
        if ZERO in orbit:
            root_signature=bfs(Q,ZERO)[0]
        else:
            components.append(min(bfs(Q,start)[0] for start in orbit))
    assert root_signature is not None and len(seen)==81
    return root_signature,tuple(sorted(components))


def audit():
    signatures={Q:signature(Q) for Q in QS}
    classes={}
    for Q,s in signatures.items():classes.setdefault(s,[]).append(Q)
    distribution=tuple(sorted((len(v) for v in classes.values())))
    rooted=sum(signatures[a]==signatures[b] for a in QS for b in QS)
    obstructed=27**2-rooted
    orb_dist=Counter(len(bfs(Q,ZERO)[1]) for Q in QS)
    expected=(distribution,rooted,obstructed,dict(orb_dist))
    assert expected==((9,18),405,324,{27:9,81:18}), expected
    return {"status":"INDEPENDENT_ROOTED_FULL_GRAPH_PARTITION",
            "quotients":27,"classes":len(classes),"class_sizes":distribution,
            "equivalent_ordered_pairs":rooted,"inequivalent_ordered_pairs":obstructed,
            "root_orbit_size_distribution":dict(sorted(orb_dist.items())),
            "scope":"F3^4, declared gain=1/q0 fixed/k=0/q2=0/zero tail; finite-depth check",
            "note":"All-depth witness comes separately from explicit affine coordinate formulas"}


if __name__=='__main__':
    import json
    print(json.dumps(audit(),indent=2))
