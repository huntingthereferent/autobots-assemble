"""Complete finite transitive A/B action correspondence via Schreier path collisions.

This is *not* cyclic B-only conjugacy. Mathematically separate admission,
question identity, observations, proof scope and replay. Generator semantics
are sourced exclusively from repository WindowProcess.step/inverse.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json

from work.arc_like_maze.window_two import WindowProcess

RELATION = "SIMULTANEOUS_AB_ON_FULL_TRANSITIVE_CARRIER"
INV = {"A": "a", "a": "A", "B": "b", "b": "B"}
F3 = (0, 1, 2)


def _wire(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"))


def _law_data(w):
    if not isinstance(w, WindowProcess):
        raise TypeError("actual WindowProcess law required")
    return {"gain": w.gain, "stem": [list(v) for v in w.stem],
            "period": [list(v) for v in w.period]}


def _restore_law(d):
    if not isinstance(d, dict) or set(d) != {"gain", "stem", "period"}:
        raise ValueError("invalid frozen action law")
    try:
        law = WindowProcess(d["gain"], tuple(tuple(v) for v in d["stem"]),
                            tuple(tuple(v) for v in d["period"]))
    except (TypeError, ValueError, KeyError) as exc:
        raise ValueError("invalid frozen action law") from exc
    if _law_data(law) != d:
        raise ValueError("noncanonical action law")
    return law


def _reverse(word):
    return "".join(INV[c] for c in reversed(word))


def _reduce(word):
    stack = []
    for c in word:
        if stack and INV[c] == stack[-1]:
            stack.pop()
        else:
            stack.append(c)
    return "".join(stack)


def _make_action(law, states, state_index):
    forward = {g: tuple(state_index[law.step(x, g)] for x in states)
               for g in "AB"}
    inverse = {}
    for g in "AB":
        p = forward[g]
        if len(set(p)) != len(states):
            raise ValueError("source law is not a permutation")
        backwards = [-1] * len(states)
        for x, target in enumerate(p):
            backwards[target] = x
        if any(states[backwards[i]] != law.inverse(states[i], g)
               for i in range(len(states))):
            raise ValueError("generator inverse failed independent replay")
        inverse[g.lower()] = tuple(backwards)
    return {**forward, **inverse}


def _paths_and_loops(edges, size):
    paths = {0: ""}
    queue = deque((0,))
    while queue:
        x = queue.popleft()
        for g in "AB":
            y = edges[g][x]
            if y not in paths:
                paths[y] = paths[x] + g
                queue.append(y)
    if len(paths) != size:
        raise ValueError("full A/B correspondence requires transitive source")
    loops = []
    for x, path in paths.items():
        for g in "AB":
            word = _reduce(path + g + _reverse(paths[edges[g][x]]))
            if word:
                loops.append(word)
    if len(loops) != size + 1:
        raise AssertionError("labeled action graph collision rank changed")
    return paths, tuple(loops)


def _act(edges, word, root):
    for g in word:
        root = edges[g][root]
    return root


def _is_transitive(edges, n):
    seen, queue = {0}, deque([0])
    while queue:
        x = queue.popleft()
        for g in "AB":
            y = edges[g][x]
            if y not in seen:
                seen.add(y)
                queue.append(y)
    return len(seen) == n


def _verified_map(source, target, paths, origin_image, n):
    mapping = tuple(_act(target, paths[x], origin_image) for x in range(n))
    if len(set(mapping)) != n:
        raise AssertionError("Schreier candidate is not a bijection")
    for x in range(n):
        for g in "AB":
            if mapping[source[g][x]] != target[g][mapping[x]]:
                raise AssertionError("Schreier candidate failed generator equation")
    return [[x, mapping[x]] for x in range(n)]


@dataclass(frozen=True)
class CorrespondenceResult:
    record: dict

    @property
    def status(self):
        return self.record["status"]

    def serialize(self):
        return _wire(self.record)


class FullActionCorrespondence:
    """Finite transitive A/B, no cyclic B-only scope promotion."""

    def start(self, source, target, dimension, max_loops, *, rooted=False,
              max_states=1000):
        if type(dimension) is not int or dimension < 3:
            raise ValueError("dimension must be >=3")
        if type(max_states) is not int or max_states < 1 or dimension > max_states or 3 ** dimension > max_states:
            raise ValueError("explicit state resource budget exceeded")
        if type(max_loops) is not int or max_loops < 0:
            raise ValueError("collision budget must be nonnegative")
        if type(rooted) is not bool:
            raise ValueError("root-preservation flag must be boolean")
        states = tuple(product(F3, repeat=dimension))
        index = {s: i for i, s in enumerate(states)}
        source_edges = _make_action(source, states, index)
        target_edges = _make_action(target, states, index)
        paths, loops = _paths_and_loops(source_edges, len(states))
        if not _is_transitive(target_edges, len(states)):
            raise ValueError("full A/B correspondence requires transitive target")
        question = {"relation": RELATION, "operation": "SCHREIER_PATH_COLLISIONS",
                    "source": _law_data(source), "target": _law_data(target),
                    "dimension": dimension, "rooted": rooted,
                    "domain": "FULL_CARTESIAN_F3", "max_states": max_states}
        qid = sha256(_wire(question).encode()).hexdigest()
        candidates = set((0,)) if rooted else set(range(len(states)))
        observations = []
        for i, word in enumerate(loops[:max_loops], 1):
            if not candidates:
                break
            removed = sorted(y for y in candidates if _act(target_edges, word, y) != y)
            candidates.difference_update(removed)
            observations.append({"index": i, "word": word, "removed": removed,
                                 "remaining": len(candidates)})
        if not candidates:
            status, witness = "DISTINGUISHED_FULL_AB", []
        elif len(observations) < len(loops):
            status, witness = "UNKNOWN_COLLISION_BUDGET", []
        else:
            witness = _verified_map(source_edges, target_edges, paths,
                                    min(candidates), len(states))
            status = "CONJUGATE_FULL_AB"
        return CorrespondenceResult({
            "schema": 1, "question": question, "question_id": qid,
            "max_loops": max_loops, "total_schreier_loops": len(loops),
            "observations": observations, "candidate_origins": sorted(candidates),
            "status": status, "AB_bijection": witness,
        })

    def replay(self, serialized, *, expected_question_id=None):
        try:
            raw = json.loads(serialized)
            if not isinstance(raw, dict) or set(raw) != {
                "schema", "question", "question_id", "max_loops",
                "total_schreier_loops", "observations", "candidate_origins",
                "status", "AB_bijection"} or raw["schema"] != 1:
                raise ValueError("invalid correspondence schema")
            q = raw["question"]
            if (not isinstance(q, dict) or set(q) != {
                    "relation", "operation", "source", "target", "dimension",
                    "rooted", "domain", "max_states"} or
                q["relation"] != RELATION or
                q["operation"] != "SCHREIER_PATH_COLLISIONS" or
                q["domain"] != "FULL_CARTESIAN_F3"):
                raise ValueError("mathematical referent changed")
            if sha256(_wire(q).encode()).hexdigest() != raw["question_id"] or (
                expected_question_id is not None and expected_question_id != raw["question_id"]):
                raise ValueError("question identity changed")
            result = self.start(_restore_law(q["source"]), _restore_law(q["target"]),
                                q["dimension"], raw["max_loops"], rooted=q["rooted"],
                                max_states=q["max_states"])
            if result.serialize() != _wire(raw):
                raise ValueError("saved collision witness failed full replay")
            return result
        except (TypeError, KeyError, OverflowError, RecursionError, json.JSONDecodeError) as exc:
            raise ValueError("invalid saved collision record") from exc

    def resume(self, serialized, max_loops, *, expected_question_id=None):
        previous = self.replay(serialized, expected_question_id=expected_question_id)
        old = previous.record
        if type(max_loops) is not int or max_loops < old["max_loops"]:
            raise ValueError("continuation collision budget may not decrease")
        if old["status"] != "UNKNOWN_COLLISION_BUDGET":
            return previous
        question = old["question"]
        new = self.start(_restore_law(question["source"]),
                         _restore_law(question["target"]), question["dimension"],
                         max_loops, rooted=question["rooted"],
                         max_states=question["max_states"])
        if new.record["observations"][:len(old["observations"])] != old["observations"]:
            raise AssertionError("collision observation ancestry changed")
        return new
