"""Cross-check full A/B transport against real WindowProcess generator laws."""
import json
import tempfile
import unittest
from itertools import product
from pathlib import Path
from research.continuity_engine import ContinuityEngine, FULL_AB, FULL_AB_SCOPE
from research.continuity_board_bridge import stage_checkpoint
from research.simultaneous_action_correspondence import FullActionCorrespondence
from runtime.research_board import load_research_board
from work.arc_like_maze.window_two import WindowProcess

F3=range(3)
Z=(0,)*9
Q0=tuple(int(v==2) for u,v in product(F3,repeat=2))
Q1=tuple(int(v==2 and z==2) for v,z in product(F3,repeat=2))

def table(a,b):
    return tuple((a[z]+b[z]*y)%3 for z,y in product(F3,repeat=2))

def rotated(q):
    t=[0]*9
    for z,y in product(F3,repeat=2):
        t[3*((z+1)%3)+(y+int(z==2))%3]=q[3*z+y]
    return tuple(t)

def process(q):
    return WindowProcess(1,(Q0,Q1,q),(Z,))

SOURCE=process(table((0,0,0),(1,0,1)))
NEGATIVE=process(table((0,0,1),(0,2,2)))
POSITIVE=process(rotated(table((0,0,0),(1,0,1))))
ORIGIN=(0,0,0,0,0)
ALL=tuple(product(F3,repeat=5))

class FullActionCorrespondenceTests(unittest.TestCase):
    def setUp(self):
        self.engine=ContinuityEngine()

    def test_unknown_to_full_obstruction_and_reentry(self):
        a=self.engine.start_full_action(SOURCE,NEGATIVE,5,0)
        self.assertEqual((a.area,a.scope,a.status),
            (FULL_AB,FULL_AB_SCOPE,"UNKNOWN_COLLISION_BUDGET"))
        b=self.engine.resume(a.serialize(),244,expected_question_id=a.question_id)
        self.assertEqual(b.status,"DISTINGUISHED_FULL_AB")
        self.assertEqual(len(b.witness),0)
        self.assertEqual(len(b.snapshots),2)
        self.assertEqual(b.research_question,a.research_question)
        self.assertEqual(self.engine.verify(b.serialize()).status,b.status)
        self.assertEqual(self.engine.resume(b.serialize(),300).serialize(),b.serialize())
        self.assertEqual(json.loads(b.snapshots[-1]["payload"])["candidate_origins"],[])

    def test_full_positive_produces_bijection(self):
        result=self.engine.start_full_action(SOURCE,POSITIVE,5,244)
        self.assertEqual(result.status,"CONJUGATE_FULL_AB")
        pairs=result.witness
        self.assertEqual(len(pairs),243)
        f={ALL[x]:ALL[y] for x,y in pairs}
        self.assertEqual(len(set(f.values())),243)
        for x in ALL:
            for g in "AB":
                self.assertEqual(f[SOURCE.step(x,g)],POSITIVE.step(f[x],g))
        self.assertEqual(self.engine.verify(result.serialize()).witness,result.witness)
        self.assertNotEqual(f[ORIGIN],ORIGIN)

    def test_rooted_negative_and_self_positive(self):
        fails=self.engine.start_full_action(SOURCE,POSITIVE,5,244,rooted=True)
        self.assertEqual(fails.status,"DISTINGUISHED_FULL_AB")
        good=self.engine.start_full_action(SOURCE,SOURCE,5,244,rooted=True)
        self.assertEqual(good.status,"CONJUGATE_FULL_AB")
        self.assertEqual(good.witness[0],[0,0])

    def test_short_budget_cannot_promote_matching_data(self):
        short=self.engine.start_full_action(SOURCE,POSITIVE,5,1)
        self.assertEqual(short.status,"UNKNOWN_COLLISION_BUDGET")
        self.assertEqual(short.witness,[])
        done=self.engine.resume(short.serialize(),244)
        self.assertEqual(done.status,"CONJUGATE_FULL_AB")
        self.assertEqual(done.snapshots[0],short.snapshots[0])
        self.assertEqual(len(done.snapshots),2)

    def test_rejects_rehashed_false_collision_observation(self):
        from research.continuity_engine import _hash,_wire
        full=self.engine.start_full_action(SOURCE,NEGATIVE,5,244)
        forged=json.loads(full.serialize())
        inner=json.loads(forged["snapshots"][0]["payload"])
        inner["observations"][0]["remaining"]+=1
        forged["snapshots"][0]["payload"]=_wire(inner)
        forged["snapshots"][0]["sha256"]=_hash(_wire(inner))
        with self.assertRaises(ValueError):
            self.engine.verify(_wire(forged))

    def test_no_cross_scope_substitution(self):
        record=self.engine.start_full_action(SOURCE,POSITIVE,5,244)
        raw=json.loads(record.serialize())
        for field,new in (("area","cyclic_action/B"),
                          ("scope","B_ONLY_ON_DECLARED_INVARIANT_CARRIER"),
                          ("question_id","spoofed")):
            bad=json.loads(record.serialize());bad[field]=new
            with self.subTest(field=field),self.assertRaises(ValueError):
                self.engine.verify(json.dumps(bad))
        with self.assertRaises(ValueError):
            _=record.powers_examined

    def test_rejects_nontransitive_source_without_false_negative(self):
        low=WindowProcess(1,(Z,Z,Z),(Z,))
        with self.assertRaisesRegex(ValueError,"transitive source"):
            self.engine.start_full_action(low,SOURCE,5,244)

    def test_explicit_resource_budget(self):
        with self.assertRaisesRegex(ValueError,"resource budget"):
            self.engine.start_full_action(SOURCE,NEGATIVE,6,0,max_states=243)

    def test_board_staging_verified_full_action_requires_public_witness(self):
        with tempfile.TemporaryDirectory() as temp:
            t=Path(temp)
            source_board=Path(__file__).resolve().parents[2]/"research"/"questions"
            original=load_research_board(root=source_board)
            saved=(source_board/"freeze-2026-10-09.json").read_bytes()
            result=self.engine.start_full_action(SOURCE,POSITIVE,5,244)
            stage_checkpoint(result.serialize(), question_id="CE-AB-001",
                question="Are these A/B actions conjugate?",
                source_board_root=source_board,candidate_directory=t/"candidate",
                frozen_date="2026-10-09",
                expected_question_id=result.question_id)
            displayed=load_research_board(root=t/"candidate")
            self.assertEqual(displayed["questions"][:-1],original["questions"])
            last=displayed["questions"][-1]
            self.assertEqual((last["status"],last["engine_status"]),
                ("REVIEW","CONJUGATE_FULL_AB"))
            self.assertIn("full",last["scope"].lower())
            self.assertEqual((source_board/"freeze-2026-10-09.json").read_bytes(),saved)

    def test_unknown_full_action_board_remains_unknown(self):
        with tempfile.TemporaryDirectory() as temp:
            rec=self.engine.start_full_action(SOURCE,POSITIVE,5,0)
            stage_checkpoint(rec.serialize(),question_id="CE-AB-002",
                question="Can paths give a bijection?",
                source_board_root=Path(__file__).resolve().parents[2]/"research"/"questions",
                candidate_directory=Path(temp)/"proposal",frozen_date="2026-10-09",
                witness_url="https://example.org/reference")
            row=load_research_board(root=Path(temp)/"proposal")["questions"][-1]
            self.assertEqual((row["status"],row["answer"]),("UNKNOWN",""))

if __name__=="__main__": unittest.main()
