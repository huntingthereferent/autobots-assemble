"""Evidence-gated artifact -> offer -> paid-order -> delivery bridge.

Standalone reference prototype. Does not call payment APIs, does not run
A/B, and does not claim to be connected to the Continuity factory runtime.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Callable
import json
import os
import shutil


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


@dataclass(frozen=True)
class ProductionOutput:
    source_ref: str
    artifact_path: str
    artifact_hash: str
    evidence_ref: str
    evidence_status: str          # 'validated', not just 'tested' or 'simulated'
    release_approved: bool        # may be sold publicly; checked out of band
    public_title: str
    price_cents: int
    artifact_kind: str = 'digital_file'
    # No original A/B relations or confidential research in this record.


@dataclass(frozen=True)
class Listing:
    sku: str
    title: str
    price_cents: int
    release_hash: str
    release_path: str
    evidence_ref: str
    source_ref: str              # Internal ledger only, not exported publicly


@dataclass(frozen=True)
class Order:
    order_id: str
    sku: str
    payment_reference: str = ''
    status: str = 'PAYMENT_PENDING'
    delivered_path: str = ''


class StoreBridge:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.releases = self.root / 'releases'
        self.deliveries = self.root / 'deliveries'
        self.releases.mkdir(exist_ok=True)
        self.deliveries.mkdir(exist_ok=True)
        self.ledger = self.root / 'state.json'
        if self.ledger.exists():
            data = json.loads(self.ledger.read_text())
            self.listings = {k: Listing(**v) for k, v in data['listings'].items()}
            self.orders = {k: Order(**v) for k, v in data['orders'].items()}
            self.held = data['held']
        else:
            self.listings = {}
            self.orders = {}
            self.held = []

    def _save(self):
        data = {'listings': {k: asdict(v) for k, v in self.listings.items()},
                'orders': {k: asdict(v) for k, v in self.orders.items()},
                'held': self.held}
        tmp = self.ledger.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, indent=2, sort_keys=True))
        os.replace(tmp, self.ledger)

    def admit_output(self, output: ProductionOutput) -> Listing | None:
        """Attempt productization without silently promoting evidence or rights."""
        source = Path(output.artifact_path)
        problems = []
        if not source.is_file() or source.is_symlink():
            problems.append('artifact unavailable or unsupported')
        elif digest(source) != output.artifact_hash:
            problems.append('artifact digest mismatch')
        if output.evidence_status != 'validated' or not output.evidence_ref:
            problems.append('validation evidence absent')
        if not output.release_approved:
            problems.append('public release not approved')
        if output.price_cents < 1:
            problems.append('no positive configured price')
        if output.artifact_kind != 'digital_file':
            problems.append('prototype supports only digital files')
        if not output.public_title.strip():
            problems.append('public title missing')
        if problems:
            self.held.append({'source_ref': output.source_ref,
                              'reasons': problems})
            self._save()
            return None
        sku = f"file-{output.artifact_hash[:16]}"
        if sku in self.listings:
            return self.listings[sku]
        target = self.releases / f"{sku}{source.suffix}"
        shutil.copyfile(source, target)
        if digest(target) != output.artifact_hash:
            raise OSError('release copy failed integrity check')
        listing = Listing(sku, output.public_title, output.price_cents,
                          output.artifact_hash, str(target),
                          output.evidence_ref, output.source_ref)
        self.listings[sku] = listing
        self._save()
        return listing

    def public_catalog(self) -> list[dict]:
        """No private source references, validation internals or methods exposed."""
        return [{'sku': l.sku, 'title': l.title, 'price_cents': l.price_cents,
                 'format': Path(l.release_path).suffix.lstrip('.')}
                for l in self.listings.values()]

    def place_order(self, order_id: str, sku: str) -> Order:
        if sku not in self.listings:
            raise ValueError('no released product with that sku')
        if order_id in self.orders:
            if self.orders[order_id].sku != sku:
                raise ValueError('order id reused for a different product')
            return self.orders[order_id]
        order = Order(order_id, sku)
        self.orders[order_id] = order
        self._save()
        return order

    def confirm_payment(self, order_id: str, provider_reference: str,
                        verify_payment: Callable[[str, str, int], bool]) -> Order:
        """Production requires external provider verification, not a client flag."""
        order = self.orders[order_id]
        if order.status == 'DELIVERED':
            return order
        listing = self.listings[order.sku]
        if not provider_reference or not verify_payment(provider_reference, order_id, listing.price_cents):
            raise PermissionError('payment not independently verified')
        order = Order(order.order_id, order.sku, provider_reference, 'PAID')
        self.orders[order_id] = order
        self._save()
        return order

    def deliver(self, order_id: str) -> Order:
        order = self.orders[order_id]
        if order.status == 'DELIVERED':
            return order
        if order.status != 'PAID':
            raise PermissionError('no verified payment: release withheld')
        listing = self.listings[order.sku]
        source = Path(listing.release_path)
        if digest(source) != listing.release_hash:
            raise ValueError('release package integrity failed')
        out = self.deliveries / order_id
        out.mkdir(exist_ok=True)
        dest = out / source.name
        if not dest.exists():
            shutil.copyfile(source, dest)
        if digest(dest) != listing.release_hash:
            raise ValueError('delivery package integrity failed')
        receipt = {'order_id': order_id, 'sku': order.sku,
                   'sha256': listing.release_hash, 'kind': 'digital_file'}
        (out / 'manifest.json').write_text(json.dumps(receipt, indent=2))
        order = Order(order.order_id, order.sku, order.payment_reference,
                      'DELIVERED', str(dest))
        self.orders[order_id] = order
        self._save()
        return order
