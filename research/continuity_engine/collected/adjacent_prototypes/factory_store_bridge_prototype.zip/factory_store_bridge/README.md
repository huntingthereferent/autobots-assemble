# Production → Store: bounded reference prototype

## Purpose

An external producer emits a tested artifact. This bridge admits an immutable
public release **only after** external evidence validation, explicit release
approval, known price, and file-integrity checking. It derives a customer-visible
catalog without exposing internal source/evidence references. A customer may
create an order without a handoff to James. Delivery is impossible until an
**independent payment-verification function** approves the payment. Delivery
checks hashes and is idempotent on replay. New versions preserve prior releases.

## Run

```bash
cd factory_store_bridge
python -m unittest discover -v
```

## Current scope / boundaries

- **Local proof, not committed to GitHub**. It is not yet integrated into
  `systems.factory`, the existing orchestrator, or the HTTP site.
- `ProductionOutput` is a typed admission boundary for already produced
  artifacts. A real connector from artifact/evidence records is still required.
- Validation and release authorization are *inputs*, not proven by a supplied
  string. Production source must verify them before invoking `admit_output`.
- Payment verifier is injected; tests use a fake. There is **no** live
  processor, checkout, financial transaction, payout or real customer order.
- Delivery is only a digital-file copy for this bounded proof; physical
  manufacturing and shipping are not claimed.
- It does not implement A/B, automatically author new products, detect
  customers, or make an AI agent execute source-code changes.
- For real deployment: use authenticated ingestion, restrictive file/URL
  validation, verified provider webhook signatures and amounts/currency,
  safe customer access controls, idempotent webhook/event records, secure
  delivery links, refunds/chargebacks, and tenant separation.

## Intended integration

```
Repository artifact + native proof
     -> verified release adapter
     -> ProductOutput admission
     -> versioned factory catalog
     -> store order
     -> provider-verified payment
     -> existing factory execution/fulfillment or digital package delivery
     -> evidence + receipt
```

The critical distinction is that **the store can be produced by the existing
work**, rather than requiring James to manually author each listing. Product
admission remains evidence-gated and public exposure requires approval.
