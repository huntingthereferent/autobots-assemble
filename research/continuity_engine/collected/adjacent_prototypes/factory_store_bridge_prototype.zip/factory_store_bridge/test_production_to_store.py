from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from dataclasses import replace
from production_to_store import StoreBridge, ProductionOutput, digest

class StoreBridgeTests(unittest.TestCase):
    def setUp(self):
        self.t = TemporaryDirectory()
        self.root = Path(self.t.name)
        self.file = self.root / 'candidate.txt'
        self.file.write_text('Working artifact, independently validated.\n')
        self.bridge = StoreBridge(self.root / 'store')
        self.output = ProductionOutput('repository:sample', str(self.file), digest(self.file),
                                       'test:validation-1', 'validated', True,
                                       'Reusable sample output', 2500)
    def tearDown(self):
        self.t.cleanup()
    def test_unverified_and_unapproved_are_held(self):
        self.assertIsNone(self.bridge.admit_output(replace(self.output,evidence_status='simulated')))
        self.assertIsNone(self.bridge.admit_output(replace(self.output,release_approved=False)))
        self.assertFalse(self.bridge.public_catalog())
    def test_tampering_prevents_listing(self):
        self.file.write_text('changed')
        self.assertIsNone(self.bridge.admit_output(self.output))
    def test_automatic_catalog_hides_internal_refs(self):
        l = self.bridge.admit_output(self.output)
        self.assertEqual(len(self.bridge.public_catalog()), 1)
        public = self.bridge.public_catalog()[0]
        self.assertEqual(public['sku'], l.sku)
        self.assertNotIn('source_ref', public)
        self.assertNotIn('evidence_ref', public)
        self.assertEqual(self.bridge.admit_output(self.output), l)
    def test_payment_gate_and_idempotent_delivery(self):
        l = self.bridge.admit_output(self.output)
        self.bridge.place_order('ORDER-1', l.sku)
        with self.assertRaises(PermissionError):
            self.bridge.deliver('ORDER-1')
        with self.assertRaises(PermissionError):
            self.bridge.confirm_payment('ORDER-1', 'test-1', lambda *args:False)
        self.bridge.confirm_payment('ORDER-1','test-1',lambda ref, oid, cents: (ref,oid,cents)==('test-1','ORDER-1',2500))
        first=self.bridge.deliver('ORDER-1')
        self.assertEqual(first.status,'DELIVERED')
        self.assertEqual(self.bridge.deliver('ORDER-1'),first)
        self.assertEqual(digest(Path(first.delivered_path)), self.output.artifact_hash)
        reload = StoreBridge(self.root/'store')
        self.assertEqual(reload.orders['ORDER-1'],first)
    def test_new_version_adds_not_overwrites(self):
        old = self.bridge.admit_output(self.output)
        self.file.write_text('Improved artifact')
        new=self.bridge.admit_output(replace(self.output,artifact_hash=digest(self.file),evidence_ref='test:validation-2'))
        self.assertNotEqual(old.sku,new.sku)
        self.assertEqual(len(self.bridge.public_catalog()),2)
    def test_order_id_cannot_select_different_sku(self):
        a=self.bridge.admit_output(self.output)
        self.file.write_text('v2')
        b=self.bridge.admit_output(replace(self.output,artifact_hash=digest(self.file),evidence_ref='test:validation-2'))
        self.bridge.place_order('O1',a.sku)
        with self.assertRaises(ValueError):
            self.bridge.place_order('O1',b.sku)

if __name__=='__main__':unittest.main()
